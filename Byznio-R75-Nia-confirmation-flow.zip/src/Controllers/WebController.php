<?php
namespace App\Controllers;
use PDO;
use App\Core\{Auth,View,Response,Env};
use App\Services\{AresService,MatcherService,AiService,PdfService,FioService,DocumentService,MailerService,OcrService,TaxService,SaltEdgeService,GoPayService,BackupService,BankTokenService,BankCsvParser,AccountingExportService,EmailTemplateService,CnbRateService,InboundMailService,MailboxService};
final class WebController {
    public function __construct(private PDO $db){}
    private function scope(string $sql,array $params=[]):array{$s=$this->db->prepare($sql);$s->execute([Auth::workspaceId(),...$params]);return $s->fetchAll();}
    private function isSuperAdmin():bool{ $emails=array_filter(array_map('trim',explode(',',(string)Env::get('SUPER_ADMIN_EMAILS','')))); return in_array(strtolower((string)(Auth::user()['email']??'')),array_map('strtolower',$emails),true); }
    public function landing():void{ if(Auth::check()) { Response::redirect('/'); } View::render('landing',['title'=>'Byznio','settings'=>$this->saasSettings()]); }
    public function publicLegal(string $page):void{
        $allowed=['terms','recurring','contact','privacy'];
        if(!in_array($page,$allowed,true)) Response::abort(404,'Stránka nebyla nalezena.');
        View::renderStandalone('legal/'.$page,['title'=>match($page){'terms'=>'Obchodní podmínky','recurring'=>'Podmínky opakovaných plateb','contact'=>'Kontakt a podpora','privacy'=>'Ochrana osobních údajů'},'settings'=>$this->saasSettings(),'supportEmail'=>Env::get('SUPPORT_EMAIL','help@byznio.cz')]);
    }
    public function dashboard():void{
        Auth::require();$wid=Auth::workspaceId();$k=[];
        $queries=['customers'=>'SELECT COUNT(*) FROM customers WHERE workspace_id=? AND active=1','invoices'=>'SELECT COUNT(*) FROM documents WHERE workspace_id=? AND doc_type="invoice"','overdue'=>'SELECT COUNT(*) FROM documents WHERE workspace_id=? AND doc_type="invoice" AND payment_status!="paid" AND due_date<date("now")','jobs'=>'SELECT COUNT(*) FROM jobs WHERE workspace_id=? AND status NOT IN ("done","cancelled")'];
        foreach($queries as $key=>$q){$st=$this->db->prepare($q);$st->execute([$wid]);$k[$key]=(int)$st->fetchColumn();}
        foreach(['revenue'=>'SELECT COALESCE(SUM(total_with_vat),0) FROM documents WHERE workspace_id=? AND doc_type="invoice" AND issue_date>=date("now","start of month")','expenses'=>'SELECT COALESCE(SUM(amount),0) FROM expenses WHERE workspace_id=? AND expense_date>=date("now","start of month")','paid'=>'SELECT COALESCE(SUM(amount),0) FROM payments WHERE workspace_id=? AND paid_at>=date("now","start of month")','receivables'=>'SELECT COALESCE(SUM(total_with_vat),0) FROM documents WHERE workspace_id=? AND doc_type IN ("invoice","proforma") AND payment_status!="paid"','new_invoice_count'=>'SELECT COUNT(*) FROM documents WHERE workspace_id=? AND doc_type="invoice" AND issue_date>=date("now","start of month")'] as $key=>$q){$st=$this->db->prepare($q);$st->execute([$wid]);$k[$key]=in_array($key,['new_invoice_count'],true)?(int)$st->fetchColumn():(float)$st->fetchColumn();}
        $k['invoice_count']=$k['invoices'];$k['cashflow']=$k['paid']-$k['expenses'];$st=$this->db->prepare('SELECT COALESCE(SUM(stock*purchase_price),0) FROM products WHERE workspace_id=? AND active=1');$st->execute([$wid]);$k['stock']=(float)$st->fetchColumn();
        $alerts=$this->scope('SELECT id,doc_number,total_with_vat,due_date FROM documents WHERE workspace_id=? AND doc_type="invoice" AND payment_status!="paid" AND due_date<date("now") ORDER BY due_date LIMIT 8');
        $events=$this->scope('SELECT * FROM calendar_events WHERE workspace_id=? AND start_at>=datetime("now") ORDER BY start_at LIMIT 6');
        $tasks=$this->scope('SELECT * FROM tasks WHERE workspace_id=? AND status="open" ORDER BY CASE WHEN due_at IS NULL THEN 1 ELSE 0 END,due_at LIMIT 8');
        $todayTasks=$this->scope('SELECT * FROM tasks WHERE workspace_id=? AND status="open" AND due_at IS NOT NULL AND date(due_at)=date("now") ORDER BY priority DESC,due_at LIMIT 8');
        $low=$this->scope('SELECT * FROM products WHERE workspace_id=? AND active=1 AND stock<=min_stock ORDER BY name LIMIT 8');
        $recentPayments=$this->scope('SELECT p.*,d.doc_number,c.company_name,c.first_name,c.last_name FROM payments p JOIN documents d ON d.id=p.document_id LEFT JOIN customers c ON c.id=d.customer_id WHERE p.workspace_id=? ORDER BY p.paid_at DESC,p.id DESC LIMIT 8');
        $monthly=[];$monthCursor=new \DateTimeImmutable('first day of this month');for($i=5;$i>=0;$i--){$m=$monthCursor->modify('-'.$i.' months');$start=$m->format('Y-m-01');$end=$m->modify('last day of this month')->format('Y-m-d');$q=$this->db->prepare('SELECT COALESCE(SUM(total_with_vat),0) FROM documents WHERE workspace_id=? AND doc_type="invoice" AND issue_date BETWEEN ? AND ?');$q->execute([$wid,$start,$end]);$rev=(float)$q->fetchColumn();$q=$this->db->prepare('SELECT COALESCE(SUM(amount),0) FROM expenses WHERE workspace_id=? AND expense_date BETWEEN ? AND ?');$q->execute([$wid,$start,$end]);$exp=(float)$q->fetchColumn();$monthly[]=['label'=>$m->format('m/Y'),'revenue'=>$rev,'expenses'=>$exp];}
        $recommendations=[];if($k['overdue'])$recommendations[]='Máte '.$k['overdue'].' faktur po splatnosti – zkontrolujte upomínky.';if($low)$recommendations[]='Sklad: '.count($low).' položek je na minimální zásobě.';if($k['cashflow']<0)$recommendations[]='Cashflow za aktuální měsíc je záporné.';if(!$recommendations)$recommendations[]='Vše důležité je zatím pod kontrolou.';
        View::render('dashboard/index',['title'=>'Přehled','k'=>$k,'alerts'=>$alerts,'events'=>$events,'tasks'=>$tasks,'todayTasks'=>$todayTasks,'low'=>$low,'recentPayments'=>$recentPayments,'monthly'=>$monthly,'recommendations'=>$recommendations]);
    }
    public function login():void{if(Auth::check())Response::redirect('/');View::render('auth/login',['title'=>'Přihlášení']);}
    public function loginPost():void{Auth::verifyCsrf();$email=strtolower(trim($_POST['email']??''));$ip=$_SERVER['REMOTE_ADDR']??'0.0.0.0';$ih=hash_hmac('sha256',$ip,Env::get('APP_KEY','fallback'));$eh=hash_hmac('sha256',$email,Env::get('APP_KEY','fallback'));$s=$this->db->prepare('SELECT COUNT(*) FROM login_attempts WHERE (ip_hash=? OR email_hash=?) AND attempted_at>?');$s->execute([$ih,$eh,time()-900]);if((int)$s->fetchColumn()>=8){View::render('auth/login',['title'=>'Přihlášení','error'=>'Příliš mnoho neúspěšných pokusů. Zkuste to později.']);return;}$s=$this->db->prepare('SELECT * FROM users WHERE email=? AND active=1');$s->execute([$email]);$u=$s->fetch();if(!$u||!password_verify($_POST['password']??'',$u['password_hash'])){$this->db->prepare('INSERT INTO login_attempts(ip_hash,email_hash,attempted_at) VALUES(?,?,?)')->execute([$ih,$eh,time()]);View::render('auth/login',['title'=>'Přihlášení','error'=>'Neplatný e-mail nebo heslo.']);return;}if(empty($u['email_verified_at'])){$_SESSION['byznio_pending_verification_email']=$u['email'];View::render('auth/login',['title'=>'Přihlášení','error'=>'Nejdříve potvrďte svůj e-mail. Poslali jsme vám aktivační odkaz.','verification_email'=>$u['email']]);return;}$this->db->prepare('DELETE FROM login_attempts WHERE ip_hash=? OR email_hash=?')->execute([$ih,$eh]);$this->db->prepare('UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?')->execute([(int)$u['id']]);Auth::login($u);Response::redirect('/');}
    public function register():void{if(Auth::check())Response::redirect('/');View::render('auth/register',['title'=>'Začít zdarma']);}
    public function registerPost():void{
        Auth::verifyCsrf();$name=trim($_POST['name']??'');$email=strtolower(trim($_POST['email']??''));$pass=$_POST['password']??'';$company=trim($_POST['company']??$name);
        if(strlen($pass)<10){View::render('auth/register',['title'=>'Začít zdarma','error'=>'Heslo musí mít alespoň 10 znaků.']);return;}
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){View::render('auth/register',['title'=>'Začít zdarma','error'=>'Zadejte platnou e-mailovou adresu.']);return;}
        $token=bin2hex(random_bytes(32));$hash=hash('sha256',$token);$expires=(new \DateTimeImmutable('+24 hours'))->format('Y-m-d H:i:s');
        try{$this->db->beginTransaction();$local=$this->makeEmailLocalpart($company);$this->db->prepare('INSERT INTO workspaces(name,plan,status,email_localpart) VALUES(?,?,?,?)')->execute([$company,'all','trial',$local]);
            $wid=(int)$this->db->lastInsertId();MailboxService::ensureWorkspace($this->db,$wid);$this->db->prepare('INSERT INTO users(workspace_id,name,email,password_hash,role,email_verification_token_hash,email_verification_expires_at) VALUES(?,?,?,?,?,?,?)')->execute([$wid,$name,$email,password_hash($pass,PASSWORD_DEFAULT),'owner',$hash,$expires]);$uid=(int)$this->db->lastInsertId();
            $trialDays=(int)$this->saasSettings()['trial_days'];$this->db->prepare('INSERT INTO subscriptions(workspace_id,plan,status,trial_ends_at,billing_interval) VALUES(?,?,?,datetime("now",?||" days"),?)')->execute([$wid,'all','trial',$trialDays,'month']);$this->db->commit();
            $url=rtrim(Env::get('APP_URL',''),'/').'/verify-email?token='.urlencode($token);$subject='Potvrďte e-mail a aktivujte Byznio';$body="Dobrý den,\n\nvítejte v Byzniu. Pro dokončení registrace prosím potvrďte svou e-mailovou adresu kliknutím na aktivační tlačítko.\n\nOdkaz je platný 24 hodin. Pokud jste registraci neprováděli vy, tento e-mail ignorujte.\n\nS pozdravem,\nByznio";$ok=MailerService::send($email,$subject,$body,null,null,'Byznio',$url,null,null,null);
            $_SESSION['byznio_pending_verification_email']=$email;$_SESSION['byznio_verification_mail_sent']=$ok;$_SESSION['byznio_new_registration']=1;View::render('auth/verify-email',['title'=>'Potvrďte e-mail','email'=>$email,'sent'=>$ok]);
        }catch(\Throwable $e){if($this->db->inTransaction())$this->db->rollBack();View::render('auth/register',['title'=>'Začít zdarma','error'=>'Účet se nepodařilo vytvořit. E-mail může být již použit.']);}
    }
    public function verifyEmail():void{
        $token=(string)($_GET['token']??'');if($token===''){View::render('auth/verify-email',['title'=>'Potvrďte e-mail','error'=>'Aktivační odkaz není platný.']);return;}
        $hash=hash('sha256',$token);$s=$this->db->prepare('SELECT * FROM users WHERE email_verification_token_hash=? AND active=1 LIMIT 1');$s->execute([$hash]);$u=$s->fetch();
        if(!$u){View::render('auth/verify-email',['title'=>'Potvrďte e-mail','error'=>'Aktivační odkaz je neplatný nebo už byl použit.']);return;}
        if(empty($u['email_verification_expires_at'])||strtotime($u['email_verification_expires_at'])<time()){$_SESSION['byznio_pending_verification_email']=$u['email'];View::render('auth/verify-email',['title'=>'Odkaz vypršel','email'=>$u['email'],'error'=>'Aktivační odkaz už vypršel. Požádejte o nový odkaz.']);return;}
        $this->db->prepare('UPDATE users SET email_verified_at=CURRENT_TIMESTAMP,email_verification_token_hash=NULL,email_verification_expires_at=NULL WHERE id=?')->execute([(int)$u['id']]);Auth::login($u);$_SESSION['byznio_new_registration']=1;unset($_SESSION['byznio_pending_verification_email']);Response::redirect('/uvod');
    }
    public function resendVerification():void{
        Auth::verifyCsrf();$email=strtolower(trim($_POST['email']??($_SESSION['byznio_pending_verification_email']??'')));if(!filter_var($email,FILTER_VALIDATE_EMAIL)){View::render('auth/verify-email',['title'=>'Potvrďte e-mail','error'=>'Zadejte platný e-mail.']);return;}
        $s=$this->db->prepare('SELECT id,name,email FROM users WHERE email=? AND active=1 LIMIT 1');$s->execute([$email]);$u=$s->fetch();if(!$u||!empty($u['email_verified_at'])){View::render('auth/verify-email',['title'=>'Potvrďte e-mail','email'=>$email,'sent'=>true]);return;}
        $token=bin2hex(random_bytes(32));$this->db->prepare('UPDATE users SET email_verification_token_hash=?,email_verification_expires_at=? WHERE id=?')->execute([hash('sha256',$token),(new \DateTimeImmutable('+24 hours'))->format('Y-m-d H:i:s'),(int)$u['id']]);$url=rtrim(Env::get('APP_URL',''),'/').'/verify-email?token='.urlencode($token);$body="Dobrý den,\n\npožádali jste o nový aktivační odkaz pro Byznio. Kliknutím na tlačítko potvrďte svou e-mailovou adresu.\n\nOdkaz je platný 24 hodin.\n\nS pozdravem,\nByznio";$ok=MailerService::send($email,'Nový aktivační odkaz pro Byznio',$body,null,null,'Byznio',$url,null,null,null);$_SESSION['byznio_pending_verification_email']=$email;View::render('auth/verify-email',['title'=>'Potvrďte e-mail','email'=>$email,'sent'=>$ok,'resent'=>true]);
    }
    public function logout():void{Auth::require();Auth::logout();Response::redirect('/login');}
    private function needsOnboarding():bool{
        $s=$this->db->prepare('SELECT onboarding_completed_at FROM workspaces WHERE id=?');$s->execute([Auth::workspaceId()]);
        return $s->fetchColumn()===null;
    }
    public function onboarding():void{
        Auth::require();
        // R29: onboarding is determined by the workspace state, not a fragile session flag.
        // This also keeps the wizard available after a session renewal/reload during registration.
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
        header('X-Byznio-Onboarding: 2026.09.22-r31');
        if(!$this->needsOnboarding()){ Response::redirect('/'); }
        $step=max(1,min(7,(int)($_GET['step']??1)));
        $company=$this->company();
        // R28: company and final onboarding steps have dedicated server-rendered views.
        // This removes any ambiguity from conditional markup in the shared step template.
        if($step===2){
            View::renderStandalone('onboarding/standalone',['title'=>'Nastavme tvoji firmu','step'=>2,'company'=>$company]);
            return;
        }
        if($step===7){
            View::renderStandalone('onboarding/standalone',['title'=>'Nia je součástí Byznia','step'=>7,'company'=>$company]);
            return;
        }
        View::render('onboarding/index',['title'=>'Vítejte v Byzniu','step'=>$step,'company'=>$company]);
    }
    public function onboardingAres():void{
        Auth::require();
        Auth::verifyCsrf();
        $ico=preg_replace('/\D/','',(string)($_POST['ico']??''));
        if(strlen($ico)!==8){ Response::json(['ok'=>false,'error'=>'IČO musí mít 8 číslic.'],422); }
        try{
            $data=AresService::lookup($ico);
            if(!$data){ Response::json(['ok'=>false,'error'=>'Firma podle tohoto IČO nebyla v ARES nalezena.'],404); }
            Response::json(['ok'=>true,'data'=>$data]);
        }catch(\Throwable $e){
            Response::json(['ok'=>false,'error'=>'ARES je momentálně nedostupný. Zkus to prosím za chvíli.'],502);
        }
    }
    public function onboardingCompany():void{
        Auth::require();Auth::verifyCsrf();
        $ico=preg_replace('/\D/','',(string)($_POST['ico']??''));$d=['name'=>trim((string)($_POST['company_name']??'')),'ico'=>$ico,'dic'=>trim((string)($_POST['dic']??'')),'street'=>trim((string)($_POST['street']??'')),'city'=>trim((string)($_POST['city']??'')),'zip'=>trim((string)($_POST['zip']??'')),'phone'=>trim((string)($_POST['phone']??''))];
        if($ico!=='' && !empty($_POST['ares'])){try{$a=AresService::lookup($ico);if($a)$d=array_merge($d,$a);}catch(\Throwable $e){}}
        if($d['name']==='')$d['name']=$this->company()['name']??'Byznio';
        $this->db->prepare('UPDATE workspaces SET name=?,ico=?,dic=?,street=?,city=?,zip=?,phone=?,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$d['name'],$d['ico']?:null,$d['dic']?:null,$d['street']?:null,$d['city']?:null,$d['zip']?:null,$d['phone']?:null,Auth::workspaceId()]);
        Response::redirect('/uvod?step=3');
    }
    public function onboardingComplete():void{Auth::require();Auth::verifyCsrf();$this->db->prepare('UPDATE workspaces SET onboarding_completed_at=CURRENT_TIMESTAMP WHERE id=?')->execute([Auth::workspaceId()]);unset($_SESSION['byznio_new_registration']);Response::redirect('/');}
    public function onboardingSkip():void{Auth::require();Auth::verifyCsrf();$this->db->prepare('UPDATE workspaces SET onboarding_completed_at=CURRENT_TIMESTAMP WHERE id=?')->execute([Auth::workspaceId()]);unset($_SESSION['byznio_new_registration']);Response::redirect('/');}
    public function customers():void{
        Auth::require();
        $q=trim((string)($_GET['q']??''));
        $wid=(int)Auth::workspaceId();
        $sql='SELECT *, COALESCE(active,1) AS crm_active FROM customers WHERE workspace_id=?';
        $p=[$wid];
        if($q!==''){
            $sql.=' AND (company_name LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR ico LIKE ? OR email LIKE ? OR phone LIKE ?)';
            $like="%$q%";
            array_push($p,$like,$like,$like,$like,$like,$like);
        }
        $sql.=' ORDER BY CASE WHEN COALESCE(active,1)=1 THEN 0 ELSE 1 END, COALESCE(company_name,\'\'), COALESCE(last_name,\'\'), id DESC';
        $s=$this->db->prepare($sql);
        $s->execute($p);
        $customers=$s->fetchAll();
        View::render('customers/index',[
            'title'=>'Zákazníci',
            'customers'=>$customers,
            'q'=>$q,
            'customerCount'=>count($customers),
        ]);
    }
    public function customerForm():void{Auth::require();View::render('customers/form',['title'=>'Nový zákazník','customer'=>[]]);}
    public function customerAres():void{
        Auth::require(); Auth::verifyCsrf();
        $ico=preg_replace('/\D/','',(string)($_POST['ico']??''));
        if(strlen($ico)!==8) Response::json(['ok'=>false,'error'=>'IČO musí mít 8 číslic.'],422);
        try{
            $data=AresService::lookup($ico);
            if(!$data) Response::json(['ok'=>false,'error'=>'Firma podle tohoto IČO nebyla v ARES nalezena.'],404);
            Response::json(['ok'=>true,'data'=>$data]);
        }catch(\Throwable $e){ Response::json(['ok'=>false,'error'=>'ARES je momentálně nedostupný. Zkus to prosím za chvíli.'],502); }
    }
    public function customerSave():void{Auth::require();Auth::verifyCsrf();$d=$_POST;if(!empty($d['ico']) && !empty($_POST['ares'])){$a=AresService::lookup($d['ico']);if($a)$d=array_merge($d,$a);} $s=$this->db->prepare('INSERT INTO customers(workspace_id,type,company_name,first_name,last_name,ico,dic,street,city,zip,delivery_street,delivery_city,delivery_zip,email,phone,web,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$s->execute([Auth::workspaceId(),$d['type']??'company',$d['company_name']??null,$d['first_name']??null,$d['last_name']??null,$d['ico']??null,$d['dic']??null,$d['street']??null,$d['city']??null,$d['zip']??null,$d['delivery_street']??null,$d['delivery_city']??null,$d['delivery_zip']??null,$d['email']??null,$d['phone']??null,$d['web']??null,$d['note']??null]);$id=(int)$this->db->lastInsertId();$this->audit('create','customer',$id,$d);Response::redirect('/customers');}
    private function customersList():array{$s=$this->db->prepare('SELECT id,company_name,first_name,last_name FROM customers WHERE workspace_id=? AND COALESCE(active,1)=1 ORDER BY company_name,last_name');$s->execute([Auth::workspaceId()]);return $s->fetchAll();}
    public function documents():void{Auth::require();$type=$_GET['type']??'';$q=trim($_GET['q']??'');$sql='SELECT d.*,c.company_name,c.first_name,c.last_name,c.email FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.workspace_id=?';$p=[Auth::workspaceId()];if($type){$sql.=' AND d.doc_type=?';$p[]=$type;}if($q){$sql.=' AND (d.doc_number LIKE ? OR c.company_name LIKE ? OR c.last_name LIKE ?)';$l="%$q%";array_push($p,$l,$l,$l);}$sql.=' ORDER BY d.issue_date DESC,d.id DESC';$s=$this->db->prepare($sql);$s->execute($p);View::render('documents/index',['title'=>'Doklady','documents'=>$s->fetchAll(),'type'=>$type]);}
    public function documentForm():void{Auth::require();$type=(string)($_GET['type']??'invoice');$allowed=['invoice','proforma','offer','order','credit','delivery'];if(!in_array($type,$allowed,true))$type='invoice';$tp=$this->db->prepare('SELECT * FROM tax_profiles WHERE workspace_id=?');$tp->execute([Auth::workspaceId()]);$tax=$tp->fetch()?:['vat_payer'=>0];View::render('documents/form',['title'=>'Nový doklad','customers'=>$this->customersList(),'products'=>$this->productsList(),'prefillDocType'=>$type,'vatPayer'=>!empty($tax['vat_payer']),'taxProfile'=>$tax]);}
    private function workspaceMailName(int $wid):string{$s=$this->db->prepare('SELECT mail_display_name,name FROM workspaces WHERE id=?');$s->execute([$wid]);$w=$s->fetch()?:[];return trim((string)($w['mail_display_name']?:$w['name']?:'Byznio'));}
    private function workspaceMailAddress(int $wid):?string{ $s=$this->db->prepare('SELECT email_localpart,mail_enabled FROM workspaces WHERE id=?');$s->execute([$wid]);$w=$s->fetch()?:[];$domain=trim((string)($this->saasSettings()['mail_domain']??''));if(empty($w['mail_enabled'])||empty($w['email_localpart'])||$domain==='')return null;return trim((string)$w['email_localpart']).'@'.$domain;}
    private function productsList():array{$s=$this->db->prepare('SELECT * FROM products WHERE workspace_id=? AND active=1 ORDER BY name');$s->execute([Auth::workspaceId()]);return $s->fetchAll();}
    private function documentEmailTemplate(array $d,array $customer,array $company,string $publicUrl):array{
        $type=(string)($d['doc_type']??'invoice');
        $label=['invoice'=>'fakturu','proforma'=>'zálohovou fakturu','offer'=>'nabídku','order'=>'objednávku','credit'=>'dobropis'][$type]??'doklad';
        $subjectLabel=['invoice'=>'Faktura','proforma'=>'Zálohová faktura','offer'=>'Nabídka','order'=>'Objednávka','credit'=>'Dobropis'][$type]??'Doklad';
        $number=(string)($d['doc_number']??'');
        $amount=number_format((float)($d['total_with_vat']??0),2,',',' ').' Kč';
        $due=!empty($d['due_date'])?date('d.m.Y',strtotime((string)$d['due_date'])):'';
        $name=trim((string)($customer['company_name']??'')); if($name==='')$name=trim((string)($customer['first_name']??'').' '.(string)($customer['last_name']??''));
        $lines=[];
        $lines[]='Dobrý den'.($name!==''?' '.$name:'').',';
        $lines[]='';
        if($type==='invoice'){
            $lines[]='v příloze Vám zasíláme fakturu č. '.$number.'.';
            $lines[]='Celková částka k úhradě: '.$amount.'.';
            if($due!=='')$lines[]='Splatnost: '.$due.'.';
        } elseif($type==='proforma'){
            $lines[]='v příloze Vám zasíláme zálohovou fakturu č. '.$number.'.';
            $lines[]='Částka k úhradě: '.$amount.'.';
            if($due!=='')$lines[]='Splatnost: '.$due.'.';
        } elseif($type==='offer'){
            $lines[]='v příloze Vám zasíláme nabídku č. '.$number.'.';
            $lines[]='Nabídku můžete otevřít také online pomocí odkazu níže.';
        } elseif($type==='order'){
            $lines[]='v příloze Vám zasíláme objednávku č. '.$number.'.';
            $lines[]='Objednávku můžete otevřít také online pomocí odkazu níže.';
        } else {
            $lines[]='v příloze Vám zasíláme dobropis č. '.$number.'.';
            $lines[]='Dobropis můžete otevřít také online pomocí odkazu níže.';
        }
        $lines[]='';
        // Zákaznické e-maily nemají obsahovat odkaz/tlačítko „Otevřít v Byzniu“.
        // PDF je hlavní doručený dokument; veřejný odkaz zůstává dostupný jen na vyžádání v aplikaci.
        $lines[]='';
        $lines[]='S pozdravem,';
        $lines[]=(string)($company['name']??'');
        return ['subject'=>$subjectLabel.' č. '.$number.' – '.((string)($company['name']??'Byznio')), 'body'=>implode("\n",$lines), 'label'=>$label];
    }
    public function sendDocumentEmail(int $id):void{
        Auth::require(); Auth::verifyCsrf(); $wid=Auth::workspaceId();
        $s=$this->db->prepare('SELECT d.*,c.email,c.company_name,c.first_name,c.last_name,c.street,c.city,c.zip FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.id=? AND d.workspace_id=?');$s->execute([$id,$wid]);$d=$s->fetch();
        if(!$d)Response::abort(404,'Doklad nenalezen.');
        $to=strtolower(trim((string)($d['email']??''))); if(!filter_var($to,FILTER_VALIDATE_EMAIL))Response::abort(422,'Zákazník nemá platný e-mail.');
        $company=$this->company();$from=$this->workspaceMailAddress($wid); if(!$from)Response::abort(422,'Odesílání e-mailů pro tuto firmu zatím není aktivní.');
        $publicUrl=rtrim(Env::get('APP_URL',''),'/').'/d/'.(string)$d['public_token'];
        $tpl=$this->documentEmailTemplate($d,$d,$company,$publicUrl);
        $subject=trim((string)($_POST['subject']??$tpl['subject']));$body=trim((string)($_POST['body']??$tpl['body']));
        if($subject==='')$subject=$tpl['subject']; if($body==='')$body=$tpl['body'];
        $itemsQ=$this->db->prepare('SELECT * FROM document_items WHERE document_id=? ORDER BY id');$itemsQ->execute([$id]);$items=$itemsQ->fetchAll();
        $pdf=PdfService::invoice($d,$items,$company,$d,$d['doc_type']==='invoice'?$publicUrl.'/qr':null);
        $dir=dirname(__DIR__,2).'/storage/mail';if(!is_dir($dir))@mkdir($dir,0775,true);$file=$dir.'/'.$wid.'_'.$id.'_'.date('YmdHis').'.pdf';file_put_contents($file,$pdf);
        $replyTo=$from; $ok=MailerService::send($to,$subject,$body,$file,$from,$this->workspaceMailName($wid),null,$company['logo_path']??null,$wid,$replyTo);
        if(!$ok)Response::abort(502,'E-mail se nepodařilo odeslat: '.MailerService::lastError());
        $this->db->prepare('INSERT INTO email_messages(workspace_id,customer_id,document_id,direction,from_email,to_email,subject,body,html_body) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$wid,$d['customer_id']?:null,$id,'outbound',$from,$to,$subject,$body,MailerService::htmlForLog($body,$this->workspaceMailName($wid),null,$company['logo_path']??null,$wid)]);
        Response::redirect('/documents?sent='.$id);
    }

    public function documentCancel(int $id):void{Auth::require();Auth::verifyCsrf();$wid=Auth::workspaceId();$s=$this->db->prepare('SELECT * FROM documents WHERE id=? AND workspace_id=?');$s->execute([$id,$wid]);$d=$s->fetch();if(!$d)Response::abort(404,'Doklad nenalezen.');if($d['payment_status']==='paid')Response::abort(422,'Zaplacený doklad nelze stornovat.');$this->db->beginTransaction();try{$items=$this->db->prepare('SELECT warehouse_item_id,quantity FROM document_items WHERE document_id=? AND warehouse_item_id IS NOT NULL');$items->execute([$id]);$up=$this->db->prepare('UPDATE products SET stock=stock+? WHERE id=? AND workspace_id=?');$mv=$this->db->prepare('INSERT INTO stock_movements(workspace_id,product_id,qty,type,note) VALUES(?,?,?,?,?)');foreach($items as $it){$qty=(float)$it['quantity'];$up->execute([$qty,(int)$it['warehouse_item_id'],$wid]);$mv->execute([$wid,(int)$it['warehouse_item_id'],$qty,'cancel','Vrácení skladu při stornu dokladu '.$d['doc_number']]);}$this->db->prepare("UPDATE documents SET status='cancelled',payment_status='cancelled',updated_at=CURRENT_TIMESTAMP WHERE id=? AND workspace_id=?")->execute([$id,$wid]);$this->db->commit();}catch(\Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}$this->audit('cancel','document',$id);Response::redirect('/documents');}
    public function offerStatus(int $id):void{Auth::require();Auth::verifyCsrf();$status=$_POST['status']??'pending';if(!in_array($status,['pending','accepted','rejected'],true))Response::abort(422,'Neplatný stav nabídky.');$this->db->prepare("UPDATE documents SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND workspace_id=? AND doc_type='offer'")->execute([$status,$id,Auth::workspaceId()]);$this->audit('offer_'.$status,'document',$id);Response::redirect('/documents');}
    public function inventoryCount():void{Auth::require();$this->gate();Auth::verifyCsrf();$pid=(int)$_POST['product_id'];$count=(float)$_POST['counted_stock'];$s=$this->db->prepare('SELECT * FROM products WHERE id=? AND workspace_id=?');$s->execute([$pid,Auth::workspaceId()]);$p=$s->fetch();if(!$p)Response::abort(404,'Produkt nenalezen.');$diff=$count-(float)$p['stock'];$this->db->beginTransaction();$this->db->prepare('UPDATE products SET stock=? WHERE id=? AND workspace_id=?')->execute([$count,$pid,Auth::workspaceId()]);$this->db->prepare('INSERT INTO inventory_counts(workspace_id,product_id,expected_stock,counted_stock,difference,note,created_by) VALUES(?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$pid,$p['stock'],$count,$diff,$_POST['note']??null,Auth::id()]);$this->db->commit();Response::redirect('/products');}
    public function documentSave():void{
        Auth::require(); Auth::verifyCsrf(); $wid=Auth::workspaceId();
        $type=$_POST['doc_type']??'invoice';
        if(!in_array($type,['invoice','offer','order','proforma','credit','delivery'],true)) Response::abort(422,'Neplatný typ dokladu.');

        $cid=(int)($_POST['customer_id']??0);
        $this->db->beginTransaction();
        try {
            if($cid<=0 && !empty($_POST['new_customer'])) {
                $company=trim((string)($_POST['new_customer_company']??''));
                $first=trim((string)($_POST['new_customer_first_name']??''));
                $last=trim((string)($_POST['new_customer_last_name']??''));
                $newIco=preg_replace('/\D/','',(string)($_POST['new_customer_ico']??''));
                $newDic=trim((string)($_POST['new_customer_dic']??''));
                $newStreet=trim((string)($_POST['new_customer_street']??''));
                $newCity=trim((string)($_POST['new_customer_city']??''));
                $newZip=trim((string)($_POST['new_customer_zip']??''));
                if(!empty($_POST['new_customer_ares']) && strlen($newIco)===8){ try{$a=AresService::lookup($newIco);if($a){$company=$a['company_name']??$company;$newDic=$a['dic']??$newDic;$newStreet=$a['street']??$newStreet;$newCity=$a['city']??$newCity;$newZip=$a['zip']??$newZip;}}catch(\Throwable $e){} }
                if($company==='' && $first==='' && $last==='') Response::abort(422,'Vyplňte alespoň název nového zákazníka.');
                $this->db->prepare('INSERT INTO customers(workspace_id,type,company_name,first_name,last_name,ico,dic,street,city,zip,email,phone,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1)')->execute([
                    $wid, $company!==''?'company':'person', $company?:null, $first?:null, $last?:null,
                    $newIco?:null, $newDic?:null, $newStreet?:null, $newCity?:null, $newZip?:null,
                    trim((string)($_POST['new_customer_email']??''))?:null, trim((string)($_POST['new_customer_phone']??''))?:null
                ]);
                $cid=(int)$this->db->lastInsertId();
            }
            $cq=$this->db->prepare('SELECT id FROM customers WHERE id=? AND workspace_id=? AND active=1');$cq->execute([$cid,$wid]);
            if(!$cq->fetchColumn()) Response::abort(404,'Zákazník nenalezen. Vyberte zákazníka nebo vytvořte nového přímo zde.');

            $tp=$this->db->prepare('SELECT * FROM tax_profiles WHERE workspace_id=?');$tp->execute([$wid]);$taxProfile=$tp->fetch()?:['vat_payer'=>0];$vatPayer=!empty($taxProfile['vat_payer']);$names=$_POST['item_name']??[]; $qty=$_POST['item_qty']??[]; $prices=$_POST['item_price']??[]; $vat=$_POST['item_vat']??[]; $productIds=$_POST['product_id']??[];
            $sub=0; $vatSum=0; $items=[];
            foreach($names as $i=>$name){
                if(trim($name)==='') continue; $q=(float)($qty[$i]??1); $price=(float)($prices[$i]??0); $vr=$vatPayer?(float)($vat[$i]??0):0;if(!in_array($vr,[0,12,21],true))$vr=0; $productId=(int)($productIds[$i]??0);
                if($productId>0){
                    $ps=$this->db->prepare('SELECT id,name,unit,stock FROM products WHERE id=? AND workspace_id=? AND active=1');$ps->execute([$productId,$wid]);$prod=$ps->fetch();
                    if(!$prod) Response::abort(422,'Skladová položka nebyla nalezena.');
                    if(trim($name)==='') $name=$prod['name'];
                    if(empty($_POST['item_unit'][$i])) $_POST['item_unit'][$i]=$prod['unit']?:'ks';
                }
                if($productId>0 && $type==='invoice'){$stock=(float)$prod['stock'];if($q>$stock)Response::abort(422,'Nedostatek zásoby pro položku '.$prod['name'].'. K dispozici: '.$stock.'.');}$line=round($q*$price,2); $sub+=$line; $vatSum+=round($line*$vr/100,2);
                $items[]=[$name,$q,$_POST['item_unit'][$i]??'ks',$price,$vr,$line,$productId];
            }
            $total=round($sub+$vatSum,2); $num=DocumentService::nextNumber($this->db,$wid,$type); $publicToken=DocumentService::publicToken($this->db);
            $paymentMethod=$_POST['payment_method']??'bank_transfer';
            if(!in_array($paymentMethod,['bank_transfer','cash','card','gopay'],true))$paymentMethod='bank_transfer';
            $paidNow=!empty($_POST['paid_now']) && in_array($type,['invoice','proforma'],true);
            $paymentStatus=$paidNow?'paid':'unpaid';
            $s=$this->db->prepare('INSERT INTO documents(workspace_id,doc_type,doc_number,variable_symbol,customer_id,parent_document_id,status,payment_status,issue_date,due_date,tax_date,payment_method,total_without_vat,total_vat,total_with_vat,currency,cnb_rate,tax_regime,language,created_by,public_token) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $s->execute([$wid,$type,$num,preg_replace('/\D/','',$num),$cid,($type==='credit'?(int)($_POST['parent_document_id']??0)?:null:null),($type==='offer'?'pending':'issued'),$paymentStatus,$_POST['issue_date']??date('Y-m-d'),$_POST['due_date']??date('Y-m-d',strtotime('+14 days')),($_POST['tax_date']??($_POST['issue_date']??date('Y-m-d'))),$paymentMethod,$type==='credit'?-abs($sub):$sub,$type==='credit'?-abs($vatSum):$vatSum,$type==='credit'?-abs($total):$total,strtoupper($_POST['currency']??'CZK'),(float)($_POST['cnb_rate']??1),$_POST['tax_regime']??'standard',in_array($_POST['language']??'cs',['cs','en'],true)?$_POST['language']:'cs',Auth::id(),$publicToken]);
            $id=(int)$this->db->lastInsertId();
            $iStmt=$this->db->prepare('INSERT INTO document_items(document_id,name,quantity,unit,unit_price,vat_rate,line_total,warehouse_item_id) VALUES(?,?,?,?,?,?,?,?)');
            $mStmt=$this->db->prepare('INSERT INTO stock_movements(workspace_id,product_id,qty,type,note) VALUES(?,?,?,?,?)');
            foreach($items as $it){
                $iStmt->execute([$id,$it[0],$it[1],$it[2],$it[3],$it[4],$it[5],$it[6]?:null]);
                if($it[6]>0 && $type==='invoice'){
                    $mStmt->execute([$wid,$it[6],-$it[1],'invoice','Výdej ze skladu při vystavení faktury '.$num]);
                    $this->db->prepare('UPDATE products SET stock=stock-? WHERE id=? AND workspace_id=?')->execute([$it[1],$it[6],$wid]);
                }
            }
            if($paidNow){$this->db->prepare('INSERT INTO payments(workspace_id,document_id,amount,paid_at,method,source) VALUES(?,?,?,?,?,?)')->execute([$wid,$id,$total,date('Y-m-d'),$paymentMethod,'manual']);}
            $this->db->commit();
        } catch(\Throwable $e) { if($this->db->inTransaction()) $this->db->rollBack(); throw $e; }

        $q=$this->db->prepare('SELECT * FROM customers WHERE id=? AND workspace_id=?');$q->execute([$cid,$wid]);$cust=$q->fetch();$from=$this->workspaceMail($wid,$type);
        if($cust&&$cust['email']&&$from){
            $dir=dirname(__DIR__,2).'/storage/mail';if(!is_dir($dir))@mkdir($dir,0775,true);
            $doc=['doc_type'=>$type,'doc_number'=>$num,'variable_symbol'=>preg_replace('/\D/','',$num),'total_without_vat'=>$sub,'total_vat'=>$vatSum,'total_with_vat'=>$total,'issue_date'=>$_POST['issue_date']??date('Y-m-d'),'due_date'=>$_POST['due_date']??date('Y-m-d',strtotime('+14 days')),'payment_method'=>$paymentMethod,'payment_status'=>$paymentStatus];
            try{
                $pdf=PdfService::invoice($doc,array_map(fn($it)=>['name'=>$it[0],'quantity'=>$it[1],'unit'=>$it[2],'unit_price'=>$it[3],'vat_rate'=>$it[4],'line_total'=>$it[5]],$items),$this->company(),$cust,$type==='invoice'?rtrim(Env::get('APP_URL',''),'/').'/d/'.$publicToken.'/qr':null);
                $file=$dir.'/'.$wid.'_'.$id.'.pdf';file_put_contents($file,$pdf);
                [$subject,$body]=$this->documentMailTemplate($type,$num,$total,(string)$doc['due_date'],trim((string)($cust['company_name']??'')));
                $this->queueEmail($wid,$cust['email'],$subject,$body,$file,rtrim(Env::get('APP_URL',''),'/').'/d/'.$publicToken);
            }catch(\Throwable $e){
                [$subject,$body]=$this->documentMailTemplate($type,$num,$total,(string)$doc['due_date'],trim((string)($cust['company_name']??'')));
                $this->queueEmail($wid,$cust['email'],$subject,$body,null,rtrim(Env::get('APP_URL',''),'/').'/d/'.$publicToken);
            }
        }
        Response::redirect('/documents');
    }
    private function nextNumber(string $type):int{$s=$this->db->prepare('SELECT COUNT(*) FROM documents WHERE workspace_id=? AND doc_type=?');$s->execute([Auth::workspaceId(),$type]);return (int)$s->fetchColumn()+1;}
    public function markPaid(int $id):void{Auth::require();Auth::verifyCsrf();$s=$this->db->prepare('SELECT * FROM documents WHERE id=? AND workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$d=$s->fetch();if(!$d)Response::abort(404,'Doklad nenalezen');$amount=(float)($_POST['amount']??$d['total_with_vat']);$this->db->prepare('INSERT INTO payments(workspace_id,document_id,amount,paid_at,method,source) VALUES(?,?,?,?,?,?)')->execute([Auth::workspaceId(),$id,$amount,date('Y-m-d'),'bank','manual']);$s=$this->db->prepare('SELECT COALESCE(SUM(amount),0) FROM payments WHERE document_id=?');$s->execute([$id]);$paid=(float)$s->fetchColumn();$status=$paid>=$d['total_with_vat']-0.01?'paid':'partially_paid';$this->db->prepare('UPDATE documents SET payment_status=? WHERE id=?')->execute([$status,$id]);if($status==='paid'){ $q=$this->db->prepare('SELECT d.doc_number,d.public_token,c.email FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.id=? AND d.workspace_id=?');$q->execute([$id,Auth::workspaceId()]);$x=$q->fetch();if($x&&$x['email']&&$this->workspaceMail(Auth::workspaceId(),'receipt'))$this->queueEmail(Auth::workspaceId(),$x['email'],'Potvrzení úhrady '.$x['doc_number'],'Dobrý den, potvrzujeme přijetí úhrady faktury '.$x['doc_number'].'.',null,rtrim(Env::get('APP_URL',''),'/').'/d/'.$x['public_token']);}Response::redirect('/documents');}
    public function convertToJob(int $id):void{Auth::require();Auth::verifyCsrf();$s=$this->db->prepare('SELECT * FROM documents WHERE id=? AND workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$d=$s->fetch();if(!$d)Response::abort(404,'Doklad nenalezen.');if($d['doc_type']!=='offer' || $d['status']!=='accepted')Response::abort(422,'Na zakázku lze převést pouze schválenou nabídku.');$this->db->prepare('INSERT INTO jobs(workspace_id,customer_id,name,description,budget,status,source_document_id) VALUES(?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$d['customer_id'],'Zakázka '.$d['doc_number'],'Vytvořeno z nabídky.', $d['total_with_vat'],'planned',$id]);Response::redirect('/jobs');}
    private function publicDocumentByToken(string $token):array{
        $token=trim($token);
        if(!preg_match('/^[a-f0-9]{64}$/', $token)) Response::abort(404,'Doklad nenalezen.');
        $s=$this->db->prepare('SELECT d.*,w.name workspace_name,w.ico workspace_ico,w.dic workspace_dic,w.street workspace_street,w.city workspace_city,w.zip workspace_zip,w.email workspace_email,w.phone workspace_phone,w.bank_account FROM documents d JOIN workspaces w ON w.id=d.workspace_id WHERE d.public_token=? LIMIT 1');
        $s->execute([$token]);$d=$s->fetch();if(!$d)Response::abort(404,'Doklad nenalezen.');
        $i=$this->db->prepare('SELECT name,description,quantity,unit,unit_price,vat_rate,line_total FROM document_items WHERE document_id=? ORDER BY id');$i->execute([(int)$d['id']]);$d['_items']=$i->fetchAll();$d['_token']=$token;return $d;
    }
    public function publicDocument(string $token):void{
        $d=$this->publicDocumentByToken($token);
        View::render('public/document',['title'=>($d['doc_type']==='offer'?'Nabídka ':'Faktura ').$d['doc_number'],'document'=>$d,'gopay_connected'=>GoPayService::isConnected((int)$d['workspace_id'])]);
    }
    public function publicOfferRespond(string $token):void{
        $d=$this->publicDocumentByToken($token);if($d['doc_type']!=='offer')Response::abort(422,'Tento doklad není nabídka.');
        $status=$_POST['status']??'';if(!in_array($status,['accepted','rejected'],true))Response::abort(422,'Neplatná odpověď.');
        $this->db->prepare("UPDATE documents SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND public_token=? AND doc_type='offer'")->execute([$status,(int)$d['id'],$token]);
        $this->db->prepare('INSERT INTO audit_log(workspace_id,user_id,action,entity_type,entity_id,metadata_json) VALUES(?,?,?,?,?,?)')->execute([(int)$d['workspace_id'],null,'customer_'.$status,'document',(int)$d['id'],json_encode(['actor'=>'customer','via'=>'public_token'],JSON_UNESCAPED_UNICODE)]);
        Response::redirect('/d/'.$token);
    }
    private function createPublicGoPay(array $d,string $token):void{
        $base=rtrim(Env::get('APP_URL',''),'/');
        $custEmail='';$q=$this->db->prepare('SELECT email FROM customers WHERE id=? AND workspace_id=?');$q->execute([(int)$d['customer_id'],(int)$d['workspace_id']]);$custEmail=(string)($q->fetchColumn()?:'');
        $p=GoPayService::createPayment((int)$d['workspace_id'],[
            'amount'=>(int)round((float)$d['total_with_vat']*100),'currency'=>'CZK','order_number'=>$d['doc_number'],'order_description'=>'Faktura '.$d['doc_number'],
            'items'=>[['name'=>'Faktura '.$d['doc_number'],'amount'=>(int)round((float)$d['total_with_vat']*100),'count'=>1]],
            'callback'=>['return_url'=>$base.'/gopay/callback?doc='.(int)$d['id'].'&token='.rawurlencode($token),'notification_url'=>$base.'/gopay/webhook'],
            'payer'=>['contact'=>['email'=>$custEmail?:Env::get('MAIL_FROM','')]]
        ]);
        $pid=(int)($p['id']??$p['data']['id']??0);if(!$pid)throw new \RuntimeException('GoPay nevrátil ID platby.');
        $this->db->prepare('UPDATE documents SET gopay_payment_id=? WHERE id=? AND workspace_id=?')->execute([$pid,(int)$d['id'],(int)$d['workspace_id']]);
        $url=GoPayService::gatewayUrl($p);if(!$url)throw new \RuntimeException('GoPay nevrátil platební URL.');Response::redirect($url);
    }
    public function publicQr(string $token):void{
        $d=$this->publicDocumentByToken($token);
        if($d['doc_type']!=='invoice') Response::abort(422,'QR platba je dostupná pouze pro faktury.');
        $iban=$this->normalizeIban((string)$d['bank_account']);
        if(!$iban) Response::abort(422,'Firma nemá nastavený platný bankovní účet pro QR platbu.');
        $spayd='SPD*1.0*ACC:'.$iban.'*AM:'.number_format((float)$d['total_with_vat'],2,'.','').'*CC:CZK*X-VS:'.$d['variable_symbol'];
        if(!class_exists('Endroid\QrCode\QrCode')) Response::abort(500,'QR knihovna není nainstalována.');
        $qr=\Endroid\QrCode\QrCode::create($spayd)->setSize(520)->setMargin(14);$result=(new \Endroid\QrCode\Writer\PngWriter())->write($qr);
        header('Content-Type: '.$result->getMimeType());header('Cache-Control: public, max-age=3600');echo $result->getString();exit;
    }

    public function publicPay(string $token):void{
        $d=$this->publicDocumentByToken($token);if($d['doc_type']!=='invoice')Response::abort(422,'Platba je dostupná pouze pro faktury.');if($d['status']==='cancelled')Response::abort(422,'Stornovanou fakturu nelze zaplatit.');
        if($d['payment_status']==='paid')Response::redirect('/d/'.$token);
        try{if(GoPayService::isConnected((int)$d['workspace_id'])){$this->createPublicGoPay($d,$token);return;}
            $iban=$this->normalizeIban((string)$d['bank_account']);if(!$iban)Response::abort(422,'Firma nemá nastavený platný bankovní účet pro QR platbu.');
            $spayd='SPD*1.0*ACC:'.$iban.'*AM:'.number_format((float)$d['total_with_vat'],2,'.','').'*CC:CZK*X-VS:'.$d['variable_symbol'];
            if(!class_exists('Endroid\QrCode\QrCode'))Response::abort(500,'QR knihovna není nainstalována.');
            $qr=\Endroid\QrCode\QrCode::create($spayd)->setSize(360)->setMargin(10);$result=(new \Endroid\QrCode\Writer\PngWriter())->write($qr);
            header('Content-Type: '.$result->getMimeType());header('Content-Disposition: inline; filename="qr-'.$d['doc_number'].'.png"');echo $result->getString();exit;
        }catch(\Throwable $e){Response::abort(502,'Platbu se nepodařilo připravit: '.$e->getMessage());}
    }
    public function pdf(int $id):void{Auth::require();$s=$this->db->prepare('SELECT d.*,c.company_name,c.first_name,c.last_name,c.street,c.city,c.zip,c.ico,c.dic FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.id=? AND d.workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$d=$s->fetch();if(!$d)Response::abort(404,'Doklad nenalezen');$s=$this->db->prepare('SELECT * FROM document_items WHERE document_id=?');$s->execute([$id]);$items=$s->fetchAll();$company=$this->company();$pdf=PdfService::invoice($d,$items,$company,$d,rtrim(Env::get('APP_URL',''),'/').'/d/'.$d['public_token'].'/qr');header('Content-Type: application/pdf');header('Content-Disposition: inline; filename="'.$d['doc_number'].'.pdf"');echo $pdf;exit;}
    private function queueEmail(int $wid,string $to,string $subject,string $body,?string $attachment=null,?string $actionUrl=null):void{$replyTo=$this->workspaceMailAddress($wid);$this->db->prepare('INSERT INTO email_queue(workspace_id,to_email,subject,body,attachment_path,action_url,status,reply_to) VALUES(?,?,?,?,?,?,?,?)')->execute([$wid,$to,$subject,$body,$attachment,$actionUrl,'queued',$replyTo]);}
    private function workspaceMail(int $wid,string $type):?string{ $s=$this->db->prepare('SELECT email_localpart,mail_enabled,mail_invoices,mail_reminders,mail_receipts,mail_offers,mail_orders,mail_proformas,mail_credits FROM workspaces WHERE id=?');$s->execute([$wid]);$w=$s->fetch()?:[];if(empty($w['mail_enabled'])||empty($w['email_localpart']))return null;$flag=['invoice'=>'mail_invoices','reminder'=>'mail_reminders','receipt'=>'mail_receipts','offer'=>'mail_offers','order'=>'mail_orders','proforma'=>'mail_proformas','credit'=>'mail_credits'][$type]??null;if($flag!==null&&!empty($w[$flag])){ $domain=$this->saasSettings()['mail_domain']??'';return trim((string)$w['email_localpart']).'@'.trim((string)$domain);}return null;}
    private function documentMailTemplate(string $type,string $number,float $total,string $dueDate, string $companyName=''):array{
        $totalText=number_format($total,2,',',' ').' Kč';
        $due=$dueDate?date('d.m.Y',strtotime($dueDate)):'neuvedeno';
        $name=$companyName!==''?' pro '.$companyName:'';
        $map=[
          'invoice'=>['Faktura '.$number.' – '.$this->company()['name'],'v příloze Vám zasíláme fakturu č. '.$number.$name.'.\n\nCelková částka k úhradě: '.$totalText.'\nSplatnost: '.$due.'.\n\nFakturu můžete otevřít také online přes odkaz v tomto e-mailu. Pokud jste již úhradu provedli, považujte prosím tuto zprávu za bezpředmětnou.\n\nV případě dotazů nám jednoduše odpovězte na tento e-mail.'],
          'proforma'=>['Zálohová faktura '.$number.' – '.$this->company()['name'],'v příloze Vám zasíláme zálohovou fakturu č. '.$number.$name.'.\n\nČástka zálohy: '.$totalText.'\nSplatnost: '.$due.'.\n\nDoklad můžete otevřít také online přes odkaz v tomto e-mailu.\n\nPokud budete mít k záloze jakýkoli dotaz, odpovězte prosím přímo na tento e-mail.'],
          'offer'=>['Nabídka '.$number.' – '.$this->company()['name'],'v příloze Vám zasíláme nabídku č. '.$number.$name.'.\n\nNabídku si můžete otevřít online a přímo přes ni potvrdit nebo odmítnout její přijetí.\n\nPokud chcete nabídku upravit nebo máte dotazy, jednoduše nám odpovězte na tento e-mail.'],
          'order'=>['Objednávka '.$number.' – '.$this->company()['name'],'v příloze Vám zasíláme objednávku č. '.$number.$name.'.\n\nDoklad můžete otevřít také online přes odkaz v tomto e-mailu.\n\nV případě dotazů nebo změn objednávky nám prosím odpovězte na tento e-mail.'],
          'credit'=>['Dobropis '.$number.' – '.$this->company()['name'],'v příloze Vám zasíláme dobropis č. '.$number.$name.'.\n\nČástka dobropisu: '.$totalText.'.\n\nDoklad můžete otevřít také online přes odkaz v tomto e-mailu.\n\nPokud potřebujete cokoli upřesnit, odpovězte prosím přímo na tento e-mail.'],
        ];
        return $map[$type]??$map['invoice'];
    }
    private function company():array{$s=$this->db->prepare('SELECT * FROM workspaces WHERE id=?');$s->execute([Auth::workspaceId()]);return $s->fetch()?:[];}
    public function jobs():void{Auth::require();$this->gate();$jobs=$this->scope('SELECT j.*,c.company_name FROM jobs j LEFT JOIN customers c ON c.id=j.customer_id WHERE j.workspace_id=? ORDER BY j.created_at DESC');View::render('jobs/index',['title'=>'Zakázky','jobs'=>$jobs]);}
    public function jobForm():void{Auth::require();View::render('jobs/form',['title'=>'Nová zakázka','customers'=>$this->customersList()]);}
    public function jobSave():void{Auth::require();Auth::verifyCsrf();$this->db->prepare('INSERT INTO jobs(workspace_id,customer_id,name,description,location,budget,status,start_date,end_date) VALUES(?,?,?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),(int)$_POST['customer_id'],$_POST['name'],$_POST['description']??null,$_POST['location']??null,(float)($_POST['budget']??0),$_POST['status']??'planned',$_POST['start_date']??null,$_POST['end_date']??null]);Response::redirect('/jobs');}
    public function expenses():void{Auth::require();$rows=$this->scope('SELECT * FROM expenses WHERE workspace_id=? ORDER BY expense_date DESC');View::render('expenses/index',['title'=>'Výdaje','expenses'=>$rows]);}
    public function expenseSave():void{Auth::require();Auth::verifyCsrf();$path=null;if(!empty($_FILES['receipt']['tmp_name'])&&is_uploaded_file($_FILES['receipt']['tmp_name'])){$finfo=new \finfo(FILEINFO_MIME_TYPE);$mime=$finfo->file($_FILES['receipt']['tmp_name']);$ok=['image/jpeg'=>'jpg','image/png'=>'png','application/pdf'=>'pdf'];if(!isset($ok[$mime]))Response::abort(415,'Nepovolený typ souboru.');if((int)$_FILES['receipt']['size']>15*1024*1024)Response::abort(413,'Účtenka nebo faktura je příliš velká. Maximum je 15 MB.');$name=bin2hex(random_bytes(16)).'.'.$ok[$mime];$path='storage/uploads/'.$name;move_uploaded_file($_FILES['receipt']['tmp_name'],dirname(__DIR__,2).'/'.$path);} $supplier=$_POST['supplier']??'';$date=$_POST['expense_date']??date('Y-m-d');$amount=(float)($_POST['amount']??0);$vat=(float)($_POST['vat_amount']??0);$ocr=null;if($path){try{$ocr=OcrService::extract(dirname(__DIR__,2).'/'.$path);if(($ocr['status']??'')==='ok'){ $x=$ocr['data'];$supplier=$x['supplier']??$supplier;$date=$x['date']??$date;$amount=(float)($x['total']??$amount);$vat=(float)($x['vat_amount']??$vat);}}catch(\Throwable $e){$ocr=['status'=>'error','message'=>$e->getMessage()];}}$this->db->prepare('INSERT INTO expenses(workspace_id,supplier,expense_date,amount,vat_amount,category,document_number,receipt_path,note,job_id,ocr_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$supplier,$date,$amount,$vat,$_POST['category']??'Ostatní',$_POST['document_number']??null,$path,$_POST['note']??null,!empty($_POST['job_id'])?(int)$_POST['job_id']:null,$ocr?json_encode($ocr,JSON_UNESCAPED_UNICODE):null]);Response::redirect('/expenses');}
    public function products():void{Auth::require();$this->gate();$rows=$this->productsList();View::render('products/index',['title'=>'Sklad','products'=>$rows]);}
    public function productSave():void{Auth::require();Auth::verifyCsrf();$this->db->prepare('INSERT INTO products(workspace_id,sku,name,unit,purchase_price,sale_price,vat_rate,stock,min_stock,supplier) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$_POST['sku']??null,$_POST['name'],$_POST['unit']??'ks',(float)($_POST['purchase_price']??0),(float)$_POST['sale_price'],(float)($_POST['vat_rate']??21),(float)($_POST['stock']??0),(float)($_POST['min_stock']??0),$_POST['supplier']??null]);Response::redirect('/products');}
    public function bank():void{
        Auth::require();$this->gate();
        $tx=$this->scope('SELECT t.*,d.doc_number,c.company_name,c.first_name,c.last_name FROM bank_transactions t LEFT JOIN documents d ON d.id=t.matched_document_id AND d.workspace_id=t.workspace_id LEFT JOIN customers c ON c.id=d.customer_id AND c.workspace_id=t.workspace_id WHERE t.workspace_id=? ORDER BY t.booked_at DESC,t.id DESC');
        $docs=$this->scope('SELECT d.id,d.doc_number,d.total_with_vat,d.due_date,d.variable_symbol,d.payment_status,c.company_name,c.first_name,c.last_name,COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.document_id=d.id),0) paid FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.workspace_id=? AND d.doc_type IN ("invoice","proforma") AND d.payment_status!="paid" ORDER BY d.due_date IS NULL,d.due_date,d.issue_date DESC');
        View::render('bank/index',['title'=>'Banka','transactions'=>$tx,'matchDocuments'=>$docs]);
    }
    public function bankImport():void{Auth::require();Auth::verifyCsrf();if(empty($_FILES['csv']['tmp_name']))Response::redirect('/bank');$rows=BankCsvParser::parse($_FILES['csv']['tmp_name']);$wid=Auth::workspaceId();$insert=$this->db->prepare('INSERT INTO bank_transactions(workspace_id,bank_account_id,booked_at,amount,currency,counterparty,account_number,variable_symbol,constant_symbol,specific_symbol,message,status,external_id,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$check=$this->db->prepare('SELECT id FROM bank_transactions WHERE workspace_id=? AND external_id=? LIMIT 1');$count=0;foreach($rows as $r){$check->execute([$wid,$r['external_id']]);if($check->fetchColumn())continue;$insert->execute([$wid,(int)($_POST['bank_account_id']??0)?:null,$r['booked_at'],$r['amount'],$r['currency'],$r['counterparty'],$r['account_number'],$r['variable_symbol'],$r['constant_symbol'],$r['specific_symbol'],$r['message'],'unmatched',$r['external_id'],json_encode($r['raw'],JSON_UNESCAPED_UNICODE)]);$id=(int)$this->db->lastInsertId();MatcherService::match($this->db,$wid,$id);$count++;}$_SESSION['bank_import_count']=$count;Response::redirect('/bank');}
    public function bankMatch(int $id):void{Auth::require();Auth::verifyCsrf();$wid=Auth::workspaceId();$doc=(int)($_POST['document_id']??0);$s=$this->db->prepare('SELECT * FROM bank_transactions WHERE id=? AND workspace_id=?');$s->execute([$id,$wid]);$t=$s->fetch();if(!$t)Response::abort(404,'Transakce');$dq=$this->db->prepare('SELECT id FROM documents WHERE id=? AND workspace_id=?');$dq->execute([$doc,$wid]);if(!$dq->fetchColumn())Response::abort(404,'Doklad nenalezen.');$exists=$this->db->prepare('SELECT COUNT(*) FROM payments WHERE bank_transaction_id=? AND workspace_id=?');$exists->execute([$id,$wid]);if(!(int)$exists->fetchColumn())$this->db->prepare('INSERT INTO payments(workspace_id,document_id,amount,paid_at,method,source,bank_transaction_id) VALUES(?,?,?,?,?,?,?)')->execute([$wid,$doc,$t['amount'],$t['booked_at'],'bank','manual',$id]);$this->db->prepare('UPDATE bank_transactions SET matched_document_id=?,status="matched",matched_at=CURRENT_TIMESTAMP WHERE id=? AND workspace_id=?')->execute([$doc,$id,$wid]);DocumentService::refreshPaymentStatus($this->db,$wid,$doc);Response::redirect('/bank');}
    public function calendar():void{
        Auth::require();
        $month=(string)($_GET['month']??date('Y-m'));
        if(!preg_match('/^\d{4}-\d{2}$/',$month))$month=date('Y-m');
        $first=$month.'-01';
        $next=(new \DateTimeImmutable($first))->modify('+1 month')->format('Y-m-01');
        $events=$this->scope('SELECT e.*,c.company_name,j.name job_name,u.name user_name FROM calendar_events e LEFT JOIN customers c ON c.id=e.customer_id LEFT JOIN jobs j ON j.id=e.job_id LEFT JOIN users u ON u.id=e.user_id WHERE e.workspace_id=? AND e.start_at>=? AND e.start_at<? ORDER BY e.start_at',[$first,$next]);
        View::render('calendar/index',['title'=>'Kalendář','events'=>$events,'customers'=>$this->customersList(),'jobs'=>$this->scope('SELECT id,name FROM jobs WHERE workspace_id=? ORDER BY name'),'calendarMonth'=>$month]);
    }
    public function ai():void{
        Auth::require();
        // Nia now lives directly in the app shell. The old full-screen chat is intentionally removed.
        Response::redirect('/');
    }
    public function aiAsk():void{
        Auth::require();Auth::verifyCsrf();$prompt=trim((string)($_POST['prompt']??''));if($prompt==='')Response::json(['ok'=>false,'error'=>'Napište dotaz.'],422);

        // Confirmation is conversational: no second preview/card is needed.
        if(!empty($_SESSION['ai_pending'])){
            if($this->isAiConfirmation($prompt)){
                $a=$_SESSION['ai_pending'];
                try{
                    $result=\App\Services\AiActionService::execute($this->db,$a,(int)Auth::id());
                    unset($_SESSION['ai_pending']);
                    $this->audit('ai_action',$result['entity']??'action',(int)($result['id']??0),$a['payload']??[]);
                    Response::json(['ok'=>true,'answer'=>$result['message']??'Akce byla provedena.','pending'=>null]);
                }catch(\Throwable $e){Response::json(['ok'=>true,'answer'=>'Akci se nepodařilo provést: '.$e->getMessage(),'pending'=>$_SESSION['ai_pending']??null]);}
            }
            if($this->isAiCancellation($prompt)){
                unset($_SESSION['ai_pending']);
                Response::json(['ok'=>true,'answer'=>'Dobře, akci jsem zrušil.','pending'=>null]);
            }
        }

        $wid=Auth::workspaceId();
        $ctx=['today'=>date('Y-m-d'),'workspace'=>$this->company(),
            'customers'=>$this->scope('SELECT id,company_name,first_name,last_name,ico,email,phone FROM customers WHERE workspace_id=? AND active=1 LIMIT 200'),
            'documents'=>$this->scope('SELECT d.id,d.doc_number,d.doc_type,d.total_with_vat,d.due_date,d.customer_id,d.payment_status,c.company_name,c.first_name,c.last_name,c.email FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.workspace_id=? AND d.status<>"cancelled" ORDER BY d.issue_date DESC,d.id DESC LIMIT 200'),
            'overdue'=>$this->scope('SELECT id,doc_number,total_with_vat,due_date,customer_id FROM documents WHERE workspace_id=? AND doc_type="invoice" AND payment_status!="paid" AND due_date<date("now") LIMIT 50'),
            'unpaid'=>$this->scope('SELECT id,doc_number,total_with_vat,due_date,customer_id,payment_status FROM documents WHERE workspace_id=? AND doc_type IN ("invoice","proforma") AND payment_status!="paid" ORDER BY due_date LIMIT 50'),
            'tasks'=>$this->scope('SELECT id,title,due_at,priority,status,customer_id,job_id FROM tasks WHERE workspace_id=? ORDER BY due_at LIMIT 100'),
            'jobs'=>$this->scope('SELECT id,name,status,budget,actual_cost,start_date,end_date,customer_id FROM jobs WHERE workspace_id=? ORDER BY id DESC LIMIT 100'),
            'products'=>$this->scope('SELECT id,name,sku,unit,purchase_price,sale_price,vat_rate,stock,min_stock,supplier FROM products WHERE workspace_id=? AND active=1 ORDER BY name LIMIT 100'),
            'expenses'=>$this->scope('SELECT supplier,expense_date,amount,vat_amount,category,job_id FROM expenses WHERE workspace_id=? ORDER BY expense_date DESC LIMIT 50'),
            'stock_low'=>$this->scope('SELECT id,name,stock,min_stock,purchase_price,sale_price FROM products WHERE workspace_id=? AND active=1 AND stock<=min_stock LIMIT 50'),
            'upcoming_events'=>$this->scope('SELECT id,title,start_at,end_at,type,customer_id,job_id FROM calendar_events WHERE workspace_id=? AND start_at>=datetime("now") ORDER BY start_at LIMIT 50'),
            'recent_payments'=>$this->scope('SELECT p.amount,p.paid_at,p.method,p.source,d.doc_number,d.customer_id FROM payments p JOIN documents d ON d.id=p.document_id WHERE p.workspace_id=? ORDER BY p.paid_at DESC,p.id DESC LIMIT 30')];
        $pending=\App\Services\AiActionService::plan($this->db,$prompt,$ctx);
        if($pending){
            $_SESSION['ai_pending']=$pending;
            $answer=$this->aiConfirmationQuestion($pending);
        } else {
            $answer=AiService::ask($prompt,$ctx);unset($_SESSION['ai_pending']);
        }
        Response::json(['ok'=>true,'answer'=>$answer,'pending'=>$_SESSION['ai_pending']??null]);
    }

    private function isAiConfirmation(string $text):bool{
        $t=mb_strtolower(trim($text));
        return (bool)preg_match('/^(?:ano|jo|jo,? ?chci|ano,? ?chci|jasně|jasne|potvrzuji|potvrď|potvrd|souhlasím|souhlasim|udělej to|udelej to)!?[.!\s]*$/u',$t);
    }
    private function isAiCancellation(string $text):bool{
        $t=mb_strtolower(trim($text));
        return (bool)preg_match('/^(?:ne|nechci|zruš|zrus|zrušit|zrusit|storno|cancel)(?: to| akci)?[.!\s]*$/u',$t);
    }
    private function aiConfirmationQuestion(array $pending):string{
        $p=$pending['payload']??[];$type=$pending['action_type']??'';
        if($type==='send_reminder'){
            $name=trim((string)($p['customer_name']??'zákazník'));$doc=(string)($p['doc_number']??'');$amount=number_format((float)($p['amount']??0),2,',',' ').' Kč';
            return 'Chcete odeslat upomínku '.$name.' k faktuře '.$doc.' ve výši '.$amount.'? Odešle se standardní text upomínky používaný v Byzniu.';
        }
        $labels=['create_customer'=>'zákazníka','create_invoice'=>'fakturu','create_offer'=>'nabídku','create_order'=>'objednávku','create_proforma'=>'zálohovou fakturu','create_credit'=>'dobropis','create_delivery'=>'dodací list','create_task'=>'úkol','complete_task'=>'dokončení úkolu','create_event'=>'událost','create_job'=>'zakázku','create_product'=>'produkt','create_expense'=>'náklad','mark_paid'=>'úhradu','send_invoice'=>'odeslání faktury','cancel_document'=>'storno dokladu'];
        return 'Chcete provést akci: '.($labels[$type]??$type).'? Napište ano, pokud ji mám provést.';
    }
    public function aiCancel():void{Auth::require();Auth::verifyCsrf();unset($_SESSION['ai_pending']);Response::json(['ok'=>true,'message'=>'Návrh byl zrušen.']);}
    public function aiConfirm():void{
        Auth::require();Auth::verifyCsrf();$a=$_SESSION['ai_pending']??null;if(!$a)Response::json(['ok'=>false,'error'=>'Žádná čekající AI akce.'],400);
        try{
            $result=\App\Services\AiActionService::execute($this->db,$a,(int)Auth::id());
            unset($_SESSION['ai_pending']);
            $this->audit('ai_action',$result['entity']??'action',(int)($result['id']??0),$a['payload']??[]);
            Response::json(['ok'=>true,'message'=>$result['message']??'Akce byla provedena.']);
        }catch(\Throwable $e){Response::json(['ok'=>false,'error'=>$e->getMessage()],422);}
    }
    public function settings():void{Auth::requireRole(['owner','admin']);$s=$this->db->prepare('SELECT * FROM workspaces WHERE id=?');$s->execute([Auth::workspaceId()]);$series=$this->db->prepare('SELECT * FROM document_series WHERE workspace_id=? ORDER BY doc_type');$series->execute([Auth::workspaceId()]);View::render('settings/index',['title'=>'Nastavení','workspace'=>$s->fetch(),'series'=>$series->fetchAll(),'mail_domain'=>$this->saasSettings()['mail_domain'],'gopay_connected'=>GoPayService::isConnected(Auth::workspaceId())]);}
    public function settingsSave():void{
        Auth::requireRole(['owner','admin']); Auth::verifyCsrf();
        $local=MailboxService::normalizeLocalpart((string)($_POST['email_localpart']??''));
        if($local==='') $local=$this->makeEmailLocalpart((string)$_POST['name']);
        if($err=MailboxService::validateLocalpart($local,false))Response::abort(422,$err);
        $dup=$this->db->prepare('SELECT id FROM workspaces WHERE lower(email_localpart)=? AND id<>? LIMIT 1');$dup->execute([$local,Auth::workspaceId()]);if($dup->fetchColumn())Response::abort(422,'Tato e-mailová adresa je již obsazená.');
        $rawBank=trim((string)($_POST['bank_account']??''));
        $iban=$rawBank===''?null:$this->normalizeIban($rawBank);
        if($rawBank!=='' && !$iban) Response::abort(422,'Bankovní účet musí být platný IBAN (CZ...) nebo český účet ve formátu číslo/kód banky.');
        $this->db->prepare('UPDATE workspaces SET name=?,email_localpart=?,mail_display_name=?,mail_enabled=?,mail_invoices=?,mail_reminders=?,mail_receipts=?,mail_offers=?,mail_orders=?,mail_proformas=?,mail_credits=?,weekly_report_enabled=?,monthly_report_enabled=?,ico=?,dic=?,street=?,city=?,zip=?,email=?,phone=?,bank_account=? WHERE id=?')->execute([
            $_POST['name'],$local,trim((string)($_POST['mail_display_name']??$_POST['name'])),isset($_POST['mail_enabled'])?1:0,isset($_POST['mail_invoices'])?1:0,isset($_POST['mail_reminders'])?1:0,isset($_POST['mail_receipts'])?1:0,isset($_POST['mail_offers'])?1:0,isset($_POST['mail_orders'])?1:0,isset($_POST['mail_proformas'])?1:0,isset($_POST['mail_credits'])?1:0,isset($_POST['weekly_report_enabled'])?1:0,isset($_POST['monthly_report_enabled'])?1:0,
            $_POST['ico']??null,$_POST['dic']??null,$_POST['street']??null,$_POST['city']??null,$_POST['zip']??null,$_POST['email']??null,$_POST['phone']??null,$iban,Auth::workspaceId()
        ]);
        MailboxService::syncWorkspace($this->db,Auth::workspaceId());
        if(!empty($_FILES['logo']['tmp_name']) && is_uploaded_file($_FILES['logo']['tmp_name'])){
            $f=$_FILES['logo'];
            if((int)$f['size']>2*1024*1024) Response::abort(413,'Logo je příliš velké. Maximum je 2 MB.');
            $fi=new \finfo(FILEINFO_MIME_TYPE); $mime=$fi->file($f['tmp_name']);
            $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/svg+xml'=>'svg'];
            if(!isset($allowed[$mime])) Response::abort(415,'Logo musí být PNG, JPG nebo SVG.');
            if($mime==='image/svg+xml'){
                $svg=(string)@file_get_contents($f['tmp_name']);
                if($svg==='' || preg_match('/<\s*(script|foreignObject)|on[a-z]+\s*=|javascript:/i',$svg)) Response::abort(415,'SVG logo obsahuje nepovolený obsah.');
            }
            $name=bin2hex(random_bytes(20)).'.'.$allowed[$mime];
            $rel='storage/uploads/'.$name; $abs=dirname(__DIR__,2).'/'.$rel;
            if(!move_uploaded_file($f['tmp_name'],$abs)) Response::abort(500,'Logo se nepodařilo uložit.');
            $this->db->prepare('UPDATE workspaces SET logo_path=?,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$rel,Auth::workspaceId()]);
        }
        $seriesTypes=['invoice'=>'FV','offer'=>'CN','order'=>'OBJ','proforma'=>'ZAL','credit'=>'DOB','delivery'=>'DL'];foreach($seriesTypes as $type=>$defaultPrefix){$prefix=trim((string)($_POST['series_prefix_'.$type]??''));$next=max(1,(int)($_POST['series_next_'.$type]??1));if($prefix!==''){$prefix=preg_replace('/[^A-Za-z0-9_-]/','',$prefix);if($prefix==='')$prefix=$defaultPrefix;$this->db->prepare('INSERT INTO document_series(workspace_id,doc_type,prefix,next_number,series_year,year_prefix) VALUES(?,?,?,?,?,?) ON CONFLICT(workspace_id,doc_type) DO UPDATE SET prefix=excluded.prefix,next_number=excluded.next_number,year_prefix=excluded.year_prefix')->execute([Auth::workspaceId(),$type,$prefix,$next,(int)date('Y'),$prefix]);}}
        $goid=trim((string)($_POST['gopay_goid']??''));$gid=trim((string)($_POST['gopay_client_id']??''));$gsecret=trim((string)($_POST['gopay_client_secret']??''));
        if($goid!==''||$gid!==''||$gsecret!==''){
            if($goid===''||$gid===''||$gsecret==='')Response::abort(422,'Pro připojení GoPay vyplňte GOID, Client ID i Client Secret.');
            $enc=[BankTokenService::encrypt($goid),BankTokenService::encrypt($gid),BankTokenService::encrypt($gsecret)];
            $this->db->prepare('INSERT INTO gopay_accounts(workspace_id,goid_encrypted,client_id_encrypted,client_secret_encrypted,active,updated_at) VALUES(?,?,?,?,1,CURRENT_TIMESTAMP) ON CONFLICT(workspace_id) DO UPDATE SET goid_encrypted=excluded.goid_encrypted,client_id_encrypted=excluded.client_id_encrypted,client_secret_encrypted=excluded.client_secret_encrypted,active=1,updated_at=CURRENT_TIMESTAMP')->execute([Auth::workspaceId(),$enc[0],$enc[1],$enc[2]]);
        }elseif(isset($_POST['gopay_disconnect'])){ $this->db->prepare('UPDATE gopay_accounts SET active=0,updated_at=CURRENT_TIMESTAMP WHERE workspace_id=?')->execute([Auth::workspaceId()]); }
        Response::redirect('/settings');
    }
    public function bankSettings():void{
        Auth::require(); $this->gate();
        $s=$this->db->prepare('SELECT * FROM bank_accounts WHERE workspace_id=? AND active=1 ORDER BY id DESC');
        $s->execute([Auth::workspaceId()]);
        $accounts=$s->fetchAll();
        $s=$this->db->prepare('SELECT * FROM bank_connections WHERE workspace_id=? ORDER BY id DESC');
        $s->execute([Auth::workspaceId()]);
        $multi=$s->fetchAll();
        View::render('bank/accounts',['title'=>'Bankovní účty','accounts'=>$accounts,'multi'=>$multi]);
    }
    public function bankConnect():void{
        Auth::require(); $this->gate(); Auth::verifyCsrf();
        if(($_POST['provider']??'fio')!=='fio') Response::abort(422,'Neplatný bankovní provider.');
        $token=trim((string)($_POST['token']??'')); if($token==='') Response::abort(422,'Zadejte Fio API token.');
        $name=trim((string)($_POST['name']??'Fio účet')) ?: 'Fio účet';
        $this->db->prepare('INSERT INTO bank_accounts(workspace_id,name,provider,token_encrypted,read_only,active) VALUES(?,?,?,?,1,1)')->execute([Auth::workspaceId(),$name,'fio',BankTokenService::encrypt($token)]);
        $id=(int)$this->db->lastInsertId();
        try{$rows=FioService::normalize(FioService::movementsFromLast($token));foreach($rows as $r){$q=$this->db->prepare('INSERT OR IGNORE INTO bank_transactions(workspace_id,bank_account_id,booked_at,amount,currency,counterparty,account_number,variable_symbol,constant_symbol,specific_symbol,reference,message,status,external_id,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$q->execute([Auth::workspaceId(),$id,$r['booked_at'],$r['amount'],$r['currency'],$r['counterparty'],$r['account_number'],$r['variable_symbol'],$r['constant_symbol'],$r['specific_symbol'],$r['reference'],$r['message'],'unmatched',$r['external_id'],$r['raw_json']]);if($q->rowCount()){MatcherService::match($this->db,Auth::workspaceId(),(int)$this->db->lastInsertId());}}$this->db->prepare('UPDATE bank_accounts SET last_sync_at=CURRENT_TIMESTAMP,last_error=NULL WHERE id=? AND workspace_id=?')->execute([$id,Auth::workspaceId()]);}catch(\Throwable $e){$this->db->prepare('UPDATE bank_accounts SET last_error=? WHERE id=? AND workspace_id=?')->execute([$e->getMessage(),$id,Auth::workspaceId()]);}
        Response::redirect('/bank/accounts');
    }
    public function bankSync(int $id):void{
        Auth::require(); $this->gate(); Auth::verifyCsrf();
        $s=$this->db->prepare('SELECT * FROM bank_accounts WHERE id=? AND workspace_id=? AND active=1');$s->execute([$id,Auth::workspaceId()]);$a=$s->fetch();if(!$a)Response::abort(404,'Bankovní účet nenalezen.');
        try{$token=BankTokenService::decrypt((string)$a['token_encrypted']);$rows=FioService::normalize(FioService::movementsFromLast($token));foreach($rows as $r){$q=$this->db->prepare('INSERT OR IGNORE INTO bank_transactions(workspace_id,bank_account_id,booked_at,amount,currency,counterparty,account_number,variable_symbol,constant_symbol,specific_symbol,reference,message,status,external_id,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$q->execute([Auth::workspaceId(),$id,$r['booked_at'],$r['amount'],$r['currency'],$r['counterparty'],$r['account_number'],$r['variable_symbol'],$r['constant_symbol'],$r['specific_symbol'],$r['reference'],$r['message'],'unmatched',$r['external_id'],$r['raw_json']]);if($q->rowCount()){MatcherService::match($this->db,Auth::workspaceId(),(int)$this->db->lastInsertId());}}$this->db->prepare('UPDATE bank_accounts SET last_sync_at=CURRENT_TIMESTAMP,last_error=NULL WHERE id=? AND workspace_id=?')->execute([$id,Auth::workspaceId()]);}catch(\Throwable $e){$this->db->prepare('UPDATE bank_accounts SET last_error=? WHERE id=? AND workspace_id=?')->execute([$e->getMessage(),$id,Auth::workspaceId()]);}
        Response::redirect('/bank/accounts');
    }
    public function bankSaltEdgeStart():void{
        Auth::require(); $this->gate(); Auth::verifyCsrf();
        try{$existing=$this->db->prepare('SELECT customer_ref FROM bank_connections WHERE workspace_id=? AND provider="saltedge" AND customer_ref IS NOT NULL LIMIT 1');$existing->execute([Auth::workspaceId()]);$ref=$existing->fetchColumn();if(!$ref){$j=SaltEdgeService::customer('workspace-'.Auth::workspaceId().'-'.bin2hex(random_bytes(4)));$ref=$j['data']['id']??$j['data']['customer_id']??null;if(!$ref)throw new \RuntimeException('Salt Edge customer nebyl vytvořen.');$this->db->prepare('INSERT INTO bank_connections(workspace_id,provider,customer_ref,status) VALUES(?,?,?,?)')->execute([Auth::workspaceId(),'saltedge',(string)$ref,'pending']);}
            $return=rtrim(Env::get('APP_URL',''),'/').'/bank/saltedge/callback'; if($return==='/bank/saltedge/callback') throw new \RuntimeException('APP_URL není nastaven.');
            $j=SaltEdgeService::connectSession((string)$ref,$return,'cz');$url=$j['data']['connect_url']??$j['data']['url']??$j['connect_url']??null;if(!$url)throw new \RuntimeException('Salt Edge nevrátil připojovací URL.');Response::redirect($url);
        }catch(\Throwable $e){Response::redirect('/bank/accounts?error='.rawurlencode('Open Banking: '.$e->getMessage()));}
    }
    public function admin():void{Auth::requireRole(['owner','admin']);Response::redirect('/admin/plans');}
    public function subscription():void{
        Auth::requireRole(['owner','admin']); Auth::verifyCsrf();
        $interval=$_POST['interval']??'month'; if(!in_array($interval,['month','year'],true))Response::abort(422,'Neplatné období předplatného.');
        $settings=$this->saasSettings(); $price=$interval==='year'?(float)$settings['yearly_price_czk']:(float)$settings['monthly_price_czk'];
        $wid=Auth::workspaceId();
        $email=(string)($this->db->query('SELECT email FROM workspaces WHERE id='.(int)$wid)->fetchColumn()?:'');
        try{
            $order='BYZNIO-'.$wid.'-'.date('YmdHis').'-'.bin2hex(random_bytes(3));
            $base=rtrim(Env::get('APP_URL',''),'/'); if($base==='')Response::abort(503,'APP_URL není nastaven.');
            $payment=GoPayService::createSaasSubscription($order,$price,$interval,$base.'/gopay/subscription/callback',$base.'/gopay/subscription/webhook',$email);
            $pid=(int)($payment['id']??0); $url=GoPayService::gatewayUrl($payment);
            if($pid<1||!$url)Response::abort(502,'GoPay nevrátil platební URL.');
            $this->db->prepare('UPDATE subscriptions SET status="pending_payment",plan="all",billing_interval=?,gopay_subscription_payment_id=?,cancel_at_period_end=0,updated_at=CURRENT_TIMESTAMP WHERE workspace_id=?')->execute([$interval,$pid,$wid]);
            Response::redirect($url);
        }catch(\Throwable $e){Response::abort(502,'GoPay předplatné se nepodařilo připravit: '.$e->getMessage());}
    }
    public function bankSaltEdgeCallback():void{
        Auth::require();
        try{$customer=$this->db->prepare('SELECT customer_ref FROM bank_connections WHERE workspace_id=? AND provider="saltedge" LIMIT 1');$customer->execute([Auth::workspaceId()]);$ref=$customer->fetchColumn();if(!$ref)throw new \RuntimeException('Salt Edge customer nebyl nalezen.');$j=SaltEdgeService::connections((string)$ref);$rows=$j['data']??[];foreach($rows as $c){$existing=$this->db->prepare('SELECT id FROM bank_connections WHERE workspace_id=? AND provider="saltedge" AND connection_ref=? LIMIT 1');$existing->execute([Auth::workspaceId(),(string)($c['id']??'')]);$localId=$existing->fetchColumn();
                if($localId){$this->db->prepare('UPDATE bank_connections SET status=?,meta_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND workspace_id=?')->execute([$c['status']??'active',json_encode($c,JSON_UNESCAPED_UNICODE),(int)$localId,Auth::workspaceId()]);}
                else{$this->db->prepare('INSERT INTO bank_connections(workspace_id,provider,customer_ref,connection_ref,status,meta_json) VALUES(?,?,?,?,?,?)')->execute([Auth::workspaceId(),'saltedge',(string)$ref,(string)($c['id']??''),$c['status']??'active',json_encode($c,JSON_UNESCAPED_UNICODE)]);}}Response::redirect('/bank/accounts');}catch(\Throwable $e){Response::redirect('/bank/accounts?error='.rawurlencode('Open Banking: '.$e->getMessage()));}
    }
    public function bankSaltEdgeSync(int $id):void{
        Auth::require();Auth::verifyCsrf();$s=$this->db->prepare('SELECT * FROM bank_connections WHERE id=? AND workspace_id=? AND provider="saltedge"');$s->execute([$id,Auth::workspaceId()]);$c=$s->fetch();if(!$c)Response::abort(404,'Bankovní připojení nenalezeno.');try{
            $ba=$this->db->prepare('SELECT id FROM bank_accounts WHERE workspace_id=? AND provider=? AND external_id=? LIMIT 1');$ba->execute([Auth::workspaceId(),'saltedge',$c['connection_ref']]);$bankId=$ba->fetchColumn();if(!$bankId){$this->db->prepare('INSERT INTO bank_accounts(workspace_id,name,provider,external_id,read_only,active) VALUES(?,?,?,?,1,1)')->execute([Auth::workspaceId(),$c['account_name']?:'Open Banking účet','saltedge',$c['connection_ref']]);$bankId=(int)$this->db->lastInsertId();}
            $acc=SaltEdgeService::accounts($c['connection_ref']);foreach(($acc['data']??[]) as $a){$this->db->prepare('UPDATE bank_connections SET account_ref=?,account_name=?,iban=?,currency=? WHERE id=?')->execute([(string)$a['id'],$a['name']??null,$a['extra']['iban']??null,$a['currency_code']??'CZK',$id]);$tx=SaltEdgeService::transactions($c['connection_ref'],(string)$a['id']);foreach(($tx['data']??[]) as $r){$amount=(float)($r['amount']??0);$date=$r['made_on']??date('Y-m-d');$external=(string)($r['id']??sha1(json_encode($r)));$desc=(string)($r['description']??$r['information']??'');$extra=is_array($r['extra']??null)?$r['extra']:[];$vs=(string)($r['variable_symbol']??$extra['variable_symbol']??'');$acc=(string)($r['account_number']??$extra['account_number']??'');$refTx=(string)($r['end_to_end_id']??$r['reference']??$extra['reference']??'');$ins=$this->db->prepare('INSERT OR IGNORE INTO bank_transactions(workspace_id,bank_account_id,booked_at,amount,currency,counterparty,account_number,variable_symbol,constant_symbol,specific_symbol,reference,message,status,external_id,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$ins->execute([Auth::workspaceId(),$bankId,$date,$amount,$r['currency_code']??'CZK',$desc,$acc,preg_replace('/\D/','',$vs),'','','',$refTx,$desc,'unmatched',$external,json_encode($r,JSON_UNESCAPED_UNICODE)]);if($ins->rowCount()){ $tid=(int)$this->db->lastInsertId();MatcherService::match($this->db,Auth::workspaceId(),$tid);}}}$this->db->prepare('UPDATE bank_connections SET last_sync_at=CURRENT_TIMESTAMP,last_error=NULL,status="active" WHERE id=?')->execute([$id]);$msg='Multi-bank synchronizace dokončena.';}catch(\Throwable $e){$this->db->prepare('UPDATE bank_connections SET last_error=? WHERE id=?')->execute([$e->getMessage(),$id]);$msg='Synchronizace selhala: '.$e->getMessage();}Response::redirect('/bank/accounts');
    }
    public function stockMove():void{Auth::require();Auth::verifyCsrf();$pid=(int)$_POST['product_id'];$qty=(float)$_POST['qty'];if($qty<=0)Response::abort(422,'Množství musí být větší než nula.');$type=$_POST['type']==='out'?'out':'in';$s=$this->db->prepare('SELECT * FROM products WHERE id=? AND workspace_id=?');$s->execute([$pid,Auth::workspaceId()]);$p=$s->fetch();if(!$p)Response::abort(404,'Produkt nenalezen.');if($type==='out'&&(float)$p['stock']<$qty)Response::abort(422,'Nedostatek zásoby.');$delta=$type==='in'?$qty:-$qty;$this->db->beginTransaction();$this->db->prepare('UPDATE products SET stock=stock+? WHERE id=? AND workspace_id=?')->execute([$delta,$pid,Auth::workspaceId()]);$this->db->prepare('INSERT INTO stock_movements(workspace_id,product_id,qty,type,job_id,note) VALUES(?,?,?,?,?,?)')->execute([Auth::workspaceId(),$pid,$qty,$type,$_POST['job_id']?:null,$_POST['note']??null]);$this->db->commit();Response::redirect('/products');}
    public function jobHoursSave():void{Auth::require();Auth::verifyCsrf();$jid=(int)$_POST['job_id'];$hours=(float)($_POST['hours']??0);if($hours<=0)Response::abort(422,'Počet hodin musí být větší než nula.');$q=$this->db->prepare('SELECT id FROM jobs WHERE id=? AND workspace_id=?');$q->execute([$jid,Auth::workspaceId()]);if(!$q->fetchColumn())Response::abort(404,'Zakázka nenalezena.');$this->db->prepare('INSERT INTO job_hours(workspace_id,job_id,user_id,hours,rate,work_date,note) VALUES(?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$jid,Auth::id(),$hours,(float)($_POST['rate']??0),$_POST['work_date']??date('Y-m-d'),$_POST['note']??null]);$this->db->prepare('UPDATE jobs SET actual_cost=COALESCE((SELECT SUM(hours*rate) FROM job_hours WHERE job_id=?),0)+COALESCE((SELECT SUM(qty*unit_cost) FROM job_materials WHERE job_id=?),0) WHERE id=? AND workspace_id=?')->execute([$jid,$jid,$jid,Auth::workspaceId()]);Response::redirect('/jobs');}
    public function recurring():void{Auth::require();$rows=$this->scope('SELECT r.*,c.company_name,c.first_name,c.last_name FROM recurring_invoices r LEFT JOIN customers c ON c.id=r.customer_id WHERE r.workspace_id=? ORDER BY next_run');View::render('recurring/index',['title'=>'Opakované faktury','rows'=>$rows,'customers'=>$this->customersList()]);}
    public function recurringSave():void{Auth::require();Auth::verifyCsrf();$cid=(int)$_POST['customer_id'];$cq=$this->db->prepare('SELECT id FROM customers WHERE id=? AND workspace_id=? AND active=1');$cq->execute([$cid,Auth::workspaceId()]);if(!$cq->fetchColumn())Response::abort(404,'Zákazník nenalezen.');$interval=$_POST['interval_type']??'month';if(!in_array($interval,['month','quarter','year'],true))Response::abort(422,'Neplatný interval.');$iv=max(1,(int)($_POST['interval_value']??1));$tp=$this->db->prepare('SELECT vat_payer FROM tax_profiles WHERE workspace_id=?');$tp->execute([Auth::workspaceId()]);$payer=(bool)$tp->fetchColumn();$rate=$payer?(float)($_POST['vat_rate']??0):0;if(!in_array($rate,[0,12,21],true))$rate=0;$tpl=['items'=>[['name'=>trim((string)($_POST['item_name']??'')),'quantity'=>(float)$_POST['quantity'],'unit'=>$_POST['unit']??'ks','unit_price'=>(float)$_POST['unit_price'],'vat_rate'=>$rate]]];if($tpl['items'][0]['name']===''||$tpl['items'][0]['quantity']<=0)Response::abort(422,'Vyplňte název a kladné množství.');$this->db->prepare('INSERT INTO recurring_invoices(workspace_id,customer_id,interval_type,interval_value,next_run,send_email,template_json) VALUES(?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$cid,$interval,$iv,$_POST['next_run']??date('Y-m-d'),!empty($_POST['send_email']),json_encode($tpl,JSON_UNESCAPED_UNICODE)]);Response::redirect('/recurring');}
    public function tax():void{
        Auth::require();$wid=Auth::workspaceId();
        $s=$this->db->prepare('SELECT * FROM tax_profiles WHERE workspace_id=?');$s->execute([$wid]);$profile=$s->fetch()?:['year'=>(int)date('Y'),'vat_payer'=>0,'income_tax_method'=>'actual'];
        $year=max(2000,(int)($_GET['year']??$profile['year']??date('Y')));
        $estimate=TaxService::calculate($this->db,$wid,$year,$profile);
        View::render('tax/index',['title'=>'Daně a odvody','estimate'=>$estimate,'profile'=>$profile,'year'=>$year]);
    }
    public function taxSave():void{Auth::require();Auth::verifyCsrf();$this->db->prepare('INSERT INTO tax_profiles(workspace_id,vat_payer,income_tax_method,social_rate,health_rate,flat_regime,flat_monthly_tax,flat_social_monthly,flat_health_monthly,tax_credit,expense_lump_rate,year) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(workspace_id) DO UPDATE SET vat_payer=excluded.vat_payer,income_tax_method=excluded.income_tax_method,social_rate=excluded.social_rate,health_rate=excluded.health_rate,flat_regime=excluded.flat_regime,flat_monthly_tax=excluded.flat_monthly_tax,flat_social_monthly=excluded.flat_social_monthly,flat_health_monthly=excluded.flat_health_monthly,tax_credit=excluded.tax_credit,expense_lump_rate=excluded.expense_lump_rate,year=excluded.year,updated_at=CURRENT_TIMESTAMP')->execute([Auth::workspaceId(),!empty($_POST['vat_payer'])?'1':'0',$_POST['income_tax_method']??'actual',(float)($_POST['social_rate']??0),(float)($_POST['health_rate']??0),!empty($_POST['flat_regime'])?'1':'0',(float)($_POST['flat_monthly_tax']??0),(float)($_POST['flat_social_monthly']??0),(float)($_POST['flat_health_monthly']??0),(float)($_POST['tax_credit']??0),(float)($_POST['expense_lump_rate']??0.6),(int)($_POST['year']??date('Y'))]);Response::redirect('/tax');}
    public function gdprExport():void{Auth::requireRole(['owner','admin']);Auth::verifyCsrf();$wid=Auth::workspaceId();$data=[];$s=$this->db->prepare('SELECT * FROM workspaces WHERE id=?');$s->execute([$wid]);$data['workspace']=$s->fetch()?:[];foreach(['users','customers','documents','document_items','payments','jobs','job_hours','job_materials','expenses','products','stock_movements','bank_accounts','bank_transactions','calendar_events','documents_files','tasks','customer_communications','audit_log'] as $table){$s=$this->db->prepare("SELECT * FROM $table WHERE workspace_id=?");$s->execute([$wid]);$data[$table]=$s->fetchAll();}header('Content-Type: application/json; charset=UTF-8');header('Content-Disposition: attachment; filename="byznio-data-'.date('Y-m-d').'.json"');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);exit;}
    public function export():void{
        Auth::require();$this->gate();
        $type=$_GET['type']??'invoices';
        $map=['invoices'=>['Doklady','SELECT d.doc_number,c.company_name,d.doc_type,d.issue_date,d.due_date,d.payment_status,d.total_with_vat FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.workspace_id=? ORDER BY d.issue_date DESC'],'expenses'=>['Výdaje','SELECT supplier,expense_date,amount,vat_amount,category,document_number,note FROM expenses WHERE workspace_id=? ORDER BY expense_date DESC'],'payments'=>['Platby','SELECT p.paid_at,p.amount,p.method,p.source,d.doc_number,c.company_name FROM payments p LEFT JOIN documents d ON d.id=p.document_id LEFT JOIN customers c ON c.id=d.customer_id WHERE p.workspace_id=? ORDER BY p.paid_at DESC']];
        if(!isset($map[$type]))$type='invoices';
        $format=strtolower((string)($_GET['format']??''));
        if($format==='xlsx'){$rows=$this->exportRows($map[$type][1]);$this->sendXlsx($map[$type][0],$rows,$type);}
        if($format==='pdf'){$rows=$this->exportRows($map[$type][1]);$this->sendPdf($map[$type][0],$rows,$type);}
        View::render('export/index',['title'=>'Exporty','type'=>$type,'exportTitle'=>$map[$type][0]]);
    }
    private function exportRows(string $sql):array{$s=$this->db->prepare($sql);$s->execute([Auth::workspaceId()]);return $s->fetchAll(\PDO::FETCH_ASSOC);}
    private function sendXlsx(string $title,array $rows,string $type):void{
        $headers=$rows?array_keys($rows[0]):[];$sheetRows=[];$sheetRows[]=$headers;foreach($rows as $r)$sheetRows[]=array_values($r);
        $esc=fn($v)=>htmlspecialchars((string)$v,ENT_XML1|ENT_QUOTES,'UTF-8');
        $xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
        foreach($sheetRows as $ri=>$row){$rn=$ri+1;$xml.='<row r="'.$rn.'">';foreach($row as $ci=>$v){$col='';$n=$ci+1;while($n){$rem=($n-1)%26;$col=chr(65+$rem).$col;$n=intdiv($n-1,26);} $xml.='<c r="'.$col.$rn.'" t="inlineStr"><is><t>'.$esc($v).'</t></is></c>';}$xml.='</row>';}
        $xml.='</sheetData></worksheet>';
        $files=['[Content_Types].xml'=>'<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>','_rels/.rels'=>'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>','xl/_rels/workbook.xml.rels'=>'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>','xl/workbook.xml'=>'<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="'.$esc(substr(preg_replace('/[\\\/:\*\?\[\]]/','',$title),0,31)).'" sheetId="1" r:id="rId1"/></sheets></workbook>','xl/worksheets/sheet1.xml'=>$xml];
        $tmp=tempnam(sys_get_temp_dir(),'byznio_xlsx_');$this->writeZipPackage($tmp,$files);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header('Content-Disposition: attachment; filename="'.$type.'-'.date('Y-m-d').'.xlsx"');readfile($tmp);@unlink($tmp);exit;
    }
    private function writeZipPackage(string $path,array $files):void{
        $out='';$central='';$offset=0;$now=getdate();$dosTime=(($now['hours']&31)<<11)|(($now['minutes']&63)<<5)|intdiv($now['seconds'],2);$dosDate=(($now['year']-1980)<<9)|($now['mon']<<5)|$now['mday'];
        foreach($files as $name=>$data){$name=(string)$name;$raw=(string)$data;$comp=gzdeflate($raw,9);$crc=crc32($raw);if($crc<0)$crc+=4294967296;$nlen=strlen($name);$clen=strlen($comp);$ulen=strlen($raw);$out.=pack('VvvvvvVVVvv',0x04034b50,20,0,8,$dosTime,$dosDate,$crc,$clen,$ulen,$nlen,0).$name.$comp;$central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,8,$dosTime,$dosDate,$crc,$clen,$ulen,$nlen,0,0,0,0,0,$offset);$offset=strlen($out);}
        $out.=$central.pack('VvvvvVVv',0x06054b50,0,0,count($files),count($files),strlen($central),$offset-strlen($central),0);file_put_contents($path,$out);
    }
    private function sendPdf(string $title,array $rows,string $type):void{
        if(!class_exists('Dompdf\Dompdf'))Response::abort(500,'PDF export není na serveru dostupný.');
        $html='<html><head><meta charset="utf-8"><style>body{font-family:DejaVu Sans;font-size:10px;color:#10213f}h1{font-size:18px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #dce3ed;padding:6px;text-align:left}th{background:#eef4fb}</style></head><body><h1>Byznio – '.htmlspecialchars($title,ENT_QUOTES,'UTF-8').'</h1><p>Exportováno '.date('d.m.Y H:i').'</p><table><tr>';foreach(array_keys($rows[0]??[]) as $h)$html.='<th>'.htmlspecialchars((string)$h,ENT_QUOTES,'UTF-8').'</th>'; $html.='</tr>';foreach($rows as $r){$html.='<tr>';foreach($r as $v)$html.='<td>'.nl2br(htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8')).'</td>'; $html.='</tr>';} $html.='</table></body></html>';
        $dompdf=new \Dompdf\Dompdf(['enable_remote'=>false]);$dompdf->loadHtml($html,'UTF-8');$dompdf->setPaper('A4','landscape');$dompdf->render();$dompdf->stream($type.'-'.date('Y-m-d').'.pdf',['Attachment'=>true]);exit;
    }
    public function exportCsv():void{$_GET['format']='xlsx';$this->export();}
    public function users():void{Auth::requireRole(['owner','admin']);$users=$this->scope('SELECT id,name,email,role,active,last_login_at FROM users WHERE workspace_id=? ORDER BY name');$roles=$this->scope('SELECT id,name,permissions_json FROM custom_roles WHERE workspace_id=? ORDER BY name');View::render('admin/users',['title'=>'Uživatelé','users'=>$users,'roles'=>$roles]);}
    public function customRoleSave():void{Auth::requireRole(['owner','admin']);Auth::verifyCsrf();$name=trim((string)($_POST['role_name']??''));$permissions=json_decode((string)($_POST['role_permissions']??'{}'),true);if($name===''||mb_strlen($name)>80)Response::abort(422,'Zadejte název vlastní role do 80 znaků.');if(!is_array($permissions))Response::abort(422,'Oprávnění musí být platný JSON objekt.');$this->db->prepare('INSERT INTO custom_roles(workspace_id,name,permissions_json) VALUES(?,?,?) ON CONFLICT(workspace_id,name) DO UPDATE SET permissions_json=excluded.permissions_json')->execute([Auth::workspaceId(),$name,json_encode($permissions,JSON_UNESCAPED_UNICODE)]);Response::redirect('/admin/users');}
    public function userSave():void{Auth::requireRole(['owner','admin']);Auth::verifyCsrf();$pass=$_POST['password']??'';if(strlen($pass)<10)Response::abort(422,'Heslo musí mít alespoň 10 znaků.');$role=$_POST['role']??'employee';$allowed=['employee','accountant','admin'];$cr=$this->db->prepare('SELECT name FROM custom_roles WHERE workspace_id=?');$cr->execute([Auth::workspaceId()]);$allowed=array_merge($allowed,array_column($cr->fetchAll(),'name'));if(!in_array($role,$allowed,true))$role='employee';$permissions=[];if(!empty($_POST['permissions_json'])){$permissions=json_decode((string)$_POST['permissions_json'],true);if(!is_array($permissions))Response::abort(422,'permissions_json musí být platný JSON objekt.');}$this->db->prepare('INSERT INTO users(workspace_id,name,email,password_hash,role,permissions_json) VALUES(?,?,?,?,?,?)')->execute([Auth::workspaceId(),trim($_POST['name']),strtolower(trim($_POST['email'])),password_hash($pass,PASSWORD_DEFAULT),$role,$permissions?json_encode($permissions,JSON_UNESCAPED_UNICODE):null]);Response::redirect('/admin/users');}

    private function can(string $permission): bool {
        $u=Auth::user(); if(!$u) return false; if(in_array($u['role'],['owner','admin'],true)) return true;
        $p=json_decode($u['permissions_json']??'{}',true)?:[]; return !empty($p[$permission]);
    }
    private function audit(string $action,string $entity,int $id=0,array $meta=[]): void {
        $this->db->prepare('INSERT INTO audit_log(workspace_id,user_id,action,entity_type,entity_id,metadata_json) VALUES(?,?,?,?,?,?)')
            ->execute([Auth::workspaceId(),Auth::id(),$action,$entity,$id,json_encode($meta,JSON_UNESCAPED_UNICODE)]);
    }
    private function gate(): void { $s=$this->db->prepare('SELECT status,trial_ends_at,free_until FROM subscriptions WHERE workspace_id=?');$s->execute([Auth::workspaceId()]);$sub=$s->fetch()?:[];$active=in_array((string)($sub['status']??''),['trial','active','free'],true)&&((empty($sub['trial_ends_at'])||$sub['trial_ends_at']>=date('Y-m-d H:i:s'))&&(empty($sub['free_until'])||$sub['free_until']>=date('Y-m-d H:i:s')));if(!$active)Response::abort(402,'Předplatné není aktivní.'); }
    private function saasSettings():array{$r=$this->db->query('SELECT * FROM saas_settings WHERE id=1')->fetch();return $r?:['monthly_price_czk'=>300,'yearly_price_czk'=>3240,'trial_days'=>14,'mail_domain'=>'byznio.cz'];}
    private function makeEmailLocalpart(string $name):string{$base=strtolower(iconv('UTF-8','ASCII//TRANSLIT',$name)?:$name);$base=trim((string)preg_replace('/[^a-z0-9]+/','-',$base),'-');$base=$base?:'firma';$c=$base;$i=2;while(true){$q=$this->db->prepare('SELECT COUNT(*) FROM workspaces WHERE email_localpart=?');$q->execute([$c]);if(!(int)$q->fetchColumn())return $c;$c=$base.'-'.$i++;}}
    public function customerEdit(int $id):void{Auth::require();$s=$this->db->prepare('SELECT * FROM customers WHERE id=? AND workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$c=$s->fetch();if(!$c)Response::abort(404,'Zákazník nenalezen.');View::render('customers/form',['title'=>'Upravit zákazníka','customer'=>$c]);}
    public function customerUpdate(int $id):void{Auth::require();Auth::verifyCsrf();$d=$_POST;$this->db->prepare('UPDATE customers SET type=?,company_name=?,first_name=?,last_name=?,ico=?,dic=?,street=?,city=?,zip=?,delivery_street=?,delivery_city=?,delivery_zip=?,email=?,phone=?,web=?,note=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND workspace_id=?')->execute([$d['type']??'company',$d['company_name']??null,$d['first_name']??null,$d['last_name']??null,$d['ico']??null,$d['dic']??null,$d['street']??null,$d['city']??null,$d['zip']??null,$d['delivery_street']??null,$d['delivery_city']??null,$d['delivery_zip']??null,$d['email']??null,$d['phone']??null,$d['web']??null,$d['note']??null,$id,Auth::workspaceId()]);$this->audit('update','customer',$id);Response::redirect('/customers/'.$id);}
    public function customerDetail(int $id):void{Auth::require();$s=$this->db->prepare('SELECT * FROM customers WHERE id=? AND workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$c=$s->fetch();if(!$c)Response::abort(404,'Zákazník nenalezen.');$q=$this->db->prepare('SELECT * FROM documents WHERE workspace_id=? AND customer_id=? ORDER BY issue_date DESC');$q->execute([Auth::workspaceId(),$id]);$docs=$q->fetchAll();$q=$this->db->prepare('SELECT * FROM jobs WHERE workspace_id=? AND customer_id=? ORDER BY created_at DESC');$q->execute([Auth::workspaceId(),$id]);$jobs=$q->fetchAll();$q=$this->db->prepare('SELECT e.*,j.name job_name FROM expenses e LEFT JOIN jobs j ON j.id=e.job_id WHERE e.workspace_id=? AND (e.supplier LIKE ? OR e.job_id IN (SELECT id FROM jobs WHERE customer_id=?)) ORDER BY e.expense_date DESC');$q->execute([Auth::workspaceId(),'%'.($c['company_name']??$c['last_name']??'').'%',$id]);$expenses=$q->fetchAll();View::render('customers/detail',['title'=>'Zákazník','customer'=>$c,'documents'=>$docs,'jobs'=>$jobs,'expenses'=>$expenses]);}
    public function jobEdit(int $id):void{Auth::require();$s=$this->db->prepare('SELECT * FROM jobs WHERE id=? AND workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$j=$s->fetch();if(!$j)Response::abort(404,'Zakázka nenalezena.');View::render('jobs/form',['title'=>'Upravit zakázku','customers'=>$this->customersList(),'job'=>$j]);}
    public function jobUpdate(int $id):void{Auth::require();Auth::verifyCsrf();$this->db->prepare('UPDATE jobs SET customer_id=?,name=?,description=?,location=?,budget=?,status=?,start_date=?,end_date=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND workspace_id=?')->execute([(int)$_POST['customer_id'],$_POST['name'],$_POST['description']??null,$_POST['location']??null,(float)($_POST['budget']??0),$_POST['status']??'planned',$_POST['start_date']??null,$_POST['end_date']??null,$_POST['notes']??null,$id,Auth::workspaceId()]);$this->audit('update','job',$id);Response::redirect('/jobs/'.$id);}
    public function jobDetail(int $id):void{Auth::require();$s=$this->db->prepare('SELECT j.*,c.company_name,c.first_name,c.last_name FROM jobs j LEFT JOIN customers c ON c.id=j.customer_id WHERE j.id=? AND j.workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$j=$s->fetch();if(!$j)Response::abort(404,'Zakázka nenalezena.');$q=$this->db->prepare('SELECT h.*,u.name user_name FROM job_hours h LEFT JOIN users u ON u.id=h.user_id WHERE h.workspace_id=? AND h.job_id=? ORDER BY h.work_date DESC');$q->execute([Auth::workspaceId(),$id]);$hours=$q->fetchAll();$q=$this->db->prepare('SELECT jm.*,p.name,p.unit FROM job_materials jm JOIN products p ON p.id=jm.product_id WHERE jm.workspace_id=? AND jm.job_id=?');$q->execute([Auth::workspaceId(),$id]);$materials=$q->fetchAll();$q=$this->db->prepare('SELECT * FROM documents WHERE workspace_id=? AND (id=? OR parent_document_id=?) ORDER BY issue_date DESC');$q->execute([Auth::workspaceId(),(int)($j['source_document_id']??0),$id]);$docs=$q->fetchAll();$q=$this->db->prepare('SELECT * FROM products WHERE workspace_id=? AND active=1 ORDER BY name');$q->execute([Auth::workspaceId()]);$products=$q->fetchAll();$profit=(float)$j['budget']-(float)$j['actual_cost'];$margin=(float)$j['budget']>0?$profit/(float)$j['budget']*100:0;View::render('jobs/detail',['title'=>'Zakázka','job'=>$j,'hours'=>$hours,'materials'=>$materials,'docs'=>$docs,'products'=>$products,'profit'=>$profit,'margin'=>$margin]);}
    public function jobMaterialSave(int $id):void{Auth::require();Auth::verifyCsrf();$jq=$this->db->prepare('SELECT id FROM jobs WHERE id=? AND workspace_id=?');$jq->execute([$id,Auth::workspaceId()]);if(!$jq->fetchColumn())Response::abort(404,'Zakázka nenalezena.');$q=$this->db->prepare('SELECT * FROM products WHERE id=? AND workspace_id=?');$q->execute([(int)$_POST['product_id'],Auth::workspaceId()]);$p=$q->fetch();if(!$p)Response::abort(404,'Produkt nenalezen.');$qty=(float)$_POST['qty'];if($qty<=0||$p['stock']<$qty)Response::abort(422,'Nedostatek zásoby.');$this->db->beginTransaction();$this->db->prepare('INSERT INTO job_materials(workspace_id,job_id,product_id,qty,unit_cost) VALUES(?,?,?,?,?)')->execute([Auth::workspaceId(),$id,$p['id'],$qty,$p['purchase_price']]);$this->db->prepare('UPDATE products SET stock=stock-? WHERE id=? AND workspace_id=?')->execute([$qty,$p['id'],Auth::workspaceId()]);$this->db->prepare('INSERT INTO stock_movements(workspace_id,product_id,qty,type,job_id,note) VALUES(?,?,?,?,?,?)')->execute([Auth::workspaceId(),$p['id'],$qty,'out',$id,'Výdej na zakázku']);$this->db->prepare('UPDATE jobs SET actual_cost=COALESCE((SELECT SUM(hours*rate) FROM job_hours WHERE job_id=?),0)+COALESCE((SELECT SUM(qty*unit_cost) FROM job_materials WHERE job_id=?),0) WHERE id=? AND workspace_id=?')->execute([$id,$id,$id,Auth::workspaceId()]);$this->db->commit();Response::redirect('/jobs/'.$id);}
    public function jobInvoice(int $id):void{Auth::require();Auth::verifyCsrf();$q=$this->db->prepare('SELECT * FROM jobs WHERE id=? AND workspace_id=?');$q->execute([$id,Auth::workspaceId()]);$j=$q->fetch();if(!$j)Response::abort(404,'Zakázka nenalezena.');$items=[];$q=$this->db->prepare('SELECT SUM(hours) h, AVG(rate) rate FROM job_hours WHERE job_id=?');$q->execute([$id]);$h=$q->fetch();if(($h['h']??0)>0)$items[]=['name'=>'Práce – '.$j['name'],'quantity'=>(float)$h['h'],'unit'=>'hod','unit_price'=>(float)$h['rate'],'vat_rate'=>0];$q=$this->db->prepare('SELECT jm.qty,p.name,p.sale_price,p.vat_rate FROM job_materials jm JOIN products p ON p.id=jm.product_id WHERE jm.job_id=?');$q->execute([$id]);foreach($q as $m)$items[]=['name'=>$m['name'],'quantity'=>$m['qty'],'unit'=>'ks','unit_price'=>$m['sale_price'],'vat_rate'=>$m['vat_rate']];if(!$items)$tp=$this->db->prepare('SELECT vat_payer FROM tax_profiles WHERE workspace_id=?');$tp->execute([Auth::workspaceId()]);$payer=(bool)$tp->fetchColumn();$tp2=$this->db->prepare('SELECT default_vat_rate FROM tax_profiles WHERE workspace_id=?');$tp2->execute([Auth::workspaceId()]);$defaultRate=$payer?(float)($tp2->fetchColumn()?:21):0;$items[]=['name'=>'Zakázka '.$j['name'],'quantity'=>1,'unit'=>'ks','unit_price'=>(float)$j['budget'],'vat_rate'=>$defaultRate];$sub=$vat=0;foreach($items as $it){$line=round($it['quantity']*$it['unit_price'],2);$sub+=$line;$vat+=round($line*$it['vat_rate']/100,2);}$n=DocumentService::nextNumber($this->db,Auth::workspaceId(),'invoice');$publicToken=DocumentService::publicToken($this->db);$this->db->prepare('INSERT INTO documents(workspace_id,doc_type,doc_number,variable_symbol,customer_id,parent_document_id,status,payment_status,issue_date,due_date,total_without_vat,total_vat,total_with_vat,created_by,public_token) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),'invoice',$n,preg_replace('/\D/','',$n),$j['customer_id'],(int)($j['source_document_id']??0)?:null,'issued','unpaid',date('Y-m-d'),date('Y-m-d',strtotime('+14 days')),$sub,$vat,$sub+$vat,Auth::id(),$publicToken]);$did=(int)$this->db->lastInsertId();$st=$this->db->prepare('INSERT INTO document_items(document_id,name,quantity,unit,unit_price,vat_rate,line_total) VALUES(?,?,?,?,?,?,?)');foreach($items as $it)$st->execute([$did,$it['name'],$it['quantity'],$it['unit'],$it['unit_price'],$it['vat_rate'],round($it['quantity']*$it['unit_price'],2)]);$this->audit('create','invoice',$did,['job_id'=>$id]);Response::redirect('/documents');}
    public function productEdit(int $id):void{Auth::require();$s=$this->db->prepare('SELECT * FROM products WHERE id=? AND workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$p=$s->fetch();if(!$p)Response::abort(404,'Produkt nenalezen.');View::render('products/edit',['title'=>'Upravit produkt','product'=>$p]);}
    public function productUpdate(int $id):void{Auth::require();Auth::verifyCsrf();$this->db->prepare('UPDATE products SET sku=?,name=?,unit=?,purchase_price=?,sale_price=?,vat_rate=?,stock=?,min_stock=?,supplier=? WHERE id=? AND workspace_id=?')->execute([$_POST['sku']??null,$_POST['name'],$_POST['unit']??'ks',(float)$_POST['purchase_price'],(float)$_POST['sale_price'],(float)$_POST['vat_rate'],(float)$_POST['stock'],(float)$_POST['min_stock'],$_POST['supplier']??null,$id,Auth::workspaceId()]);Response::redirect('/products');}
    public function calendarSave():void{Auth::require();Auth::verifyCsrf();$cid=!empty($_POST['customer_id'])?(int)$_POST['customer_id']:null;$jid=!empty($_POST['job_id'])?(int)$_POST['job_id']:null;$uid=!empty($_POST['user_id'])?(int)$_POST['user_id']:Auth::id();$this->db->prepare('INSERT INTO calendar_events(workspace_id,title,start_at,end_at,type,note,customer_id,job_id,user_id) VALUES(?,?,?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$_POST['title'],$_POST['start_at'],$_POST['end_at']??null,$_POST['type']??'event',$_POST['note']??null,$cid,$jid,$uid]);Response::redirect('/calendar');}
    public function documentsFiles():void{Auth::require();$q=trim($_GET['q']??'');$sql='SELECT f.*,d.doc_number,c.company_name,j.name job_name FROM documents_files f LEFT JOIN documents d ON f.entity_type="document" AND f.entity_id=d.id LEFT JOIN customers c ON d.customer_id=c.id LEFT JOIN jobs j ON f.entity_type="job" AND f.entity_id=j.id WHERE f.workspace_id=?';$p=[Auth::workspaceId()];if($q){$sql.=' AND (f.file_name LIKE ? OR c.company_name LIKE ? OR j.name LIKE ? OR d.doc_number LIKE ?)';$l="%$q%";array_push($p,$l,$l,$l,$l);} $sql.=' ORDER BY f.created_at DESC';$s=$this->db->prepare($sql);$s->execute($p);View::render('documents/files',['title'=>'Dokumenty','files'=>$s->fetchAll(),'q'=>$q]);}
    public function fileUpload():void{Auth::require();Auth::verifyCsrf();if(empty($_FILES['file']['tmp_name']))Response::abort(422,'Soubor chybí.');$f=$_FILES['file'];$fi=new \finfo(FILEINFO_MIME_TYPE);$mime=$fi->file($f['tmp_name']);$allowed=['image/jpeg','image/png','application/pdf','text/plain','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.openxmlformats-officedocument.wordprocessingml.document'];if(!in_array($mime,$allowed,true))Response::abort(415,'Typ souboru není povolen.');if($f['size']>15*1024*1024)Response::abort(413,'Soubor je příliš velký.');$name=bin2hex(random_bytes(20));$path=dirname(__DIR__,2).'/storage/uploads/'.$name;$dest='storage/uploads/'.$name;move_uploaded_file($f['tmp_name'],$path);$this->db->prepare('INSERT INTO documents_files(workspace_id,entity_type,entity_id,file_name,storage_path,mime_type,size) VALUES(?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$_POST['entity_type']??'general',(int)($_POST['entity_id']??0),basename($f['name']),$dest,$mime,(int)$f['size']]);Response::redirect('/documents/files');}
    public function fileDownload(int $id):void{Auth::require();$s=$this->db->prepare('SELECT * FROM documents_files WHERE id=? AND workspace_id=?');$s->execute([$id,Auth::workspaceId()]);$f=$s->fetch();if(!$f)Response::abort(404,'Soubor nenalezen.');$path=dirname(__DIR__,2).'/'.$f['storage_path'];if(!is_file($path))Response::abort(404,'Soubor chybí.');header('Content-Type: '.$f['mime_type']);header('Content-Disposition: attachment; filename="'.basename($f['file_name']).'"');readfile($path);exit;}
    public function reminders():void{Auth::require();$now=date('Y-m-d');$rows=$this->scope('SELECT d.*,c.email,c.company_name,c.first_name,c.last_name,w.mail_enabled,w.mail_reminders FROM documents d LEFT JOIN customers c ON c.id=d.customer_id JOIN workspaces w ON w.id=d.workspace_id WHERE d.workspace_id=? AND d.doc_type="invoice" AND d.payment_status!="paid" AND d.due_date IS NOT NULL AND d.due_date<date("now") ORDER BY d.due_date');View::render('settings/reminders',['title'=>'Upomínky','rows'=>$rows]);}
    public function runReminders():void{Auth::requireRole(['owner','admin']);Auth::verifyCsrf();$count=0;$rows=$this->scope('SELECT d.*,c.email,c.company_name,c.first_name,c.last_name,w.mail_enabled,w.mail_reminders FROM documents d LEFT JOIN customers c ON c.id=d.customer_id JOIN workspaces w ON w.id=d.workspace_id WHERE d.workspace_id=? AND d.doc_type="invoice" AND d.payment_status!="paid" AND d.due_date IS NOT NULL AND c.email IS NOT NULL');foreach($rows as $d){$days=(int)floor((strtotime(date('Y-m-d'))-strtotime($d['due_date']))/86400);$send=in_array($days,[3,7],true) && !empty($d['mail_enabled']) && !empty($d['mail_reminders']);if($send){$ded=$this->db->prepare('SELECT COUNT(*) FROM reminder_log WHERE workspace_id=? AND document_id=? AND days_offset=?');$ded->execute([Auth::workspaceId(),$d['id'],$days]);if((int)$ded->fetchColumn())continue;$subject=$days<0?'Blíží se splatnost faktury '.$d['doc_number']:'Upomínka k faktuře '.$d['doc_number'];$body=$days<0?'Dobrý den, připomínáme blížící se splatnost faktury '.$d['doc_number'].' ve výši '.number_format($d['total_with_vat'],2,',',' ').' Kč.':'Dobrý den, faktura '.$d['doc_number'].' je po splatnosti '.$days.' dní. Prosíme o kontrolu úhrady.';$this->db->prepare('INSERT INTO email_queue(workspace_id,to_email,subject,body,action_url,status,scheduled_at) VALUES(?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$d['email'],$subject,$body,null,'queued',date('Y-m-d H:i:s')]);$this->db->prepare('INSERT OR IGNORE INTO reminder_log(workspace_id,document_id,days_offset) VALUES(?,?,?)')->execute([Auth::workspaceId(),$d['id'],$days]);$count++;}}Response::redirect('/reminders?generated='.$count);}
    public function tasks():void{Auth::require();$rows=$this->scope('SELECT * FROM tasks WHERE workspace_id=? ORDER BY due_at IS NULL,due_at');View::render('tasks/index',['title'=>'Úkoly','tasks'=>$rows]);}
    public function taskSave():void{Auth::require();Auth::verifyCsrf();$this->db->prepare('INSERT INTO tasks(workspace_id,title,description,due_at,priority,status,customer_id,job_id,assigned_user_id) VALUES(?,?,?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$_POST['title'],$_POST['description']??null,$_POST['due_at']??null,$_POST['priority']??'normal','open',!empty($_POST['customer_id'])?(int)$_POST['customer_id']:null,!empty($_POST['job_id'])?(int)$_POST['job_id']:null,!empty($_POST['assigned_user_id'])?(int)$_POST['assigned_user_id']:Auth::id()]);Response::redirect('/tasks');}
    public function taskDone(int $id):void{Auth::require();Auth::verifyCsrf();$this->db->prepare('UPDATE tasks SET status="done",completed_at=CURRENT_TIMESTAMP WHERE id=? AND workspace_id=?')->execute([$id,Auth::workspaceId()]);Response::redirect('/tasks');}
    public function apiKeys():void{Auth::require();Response::redirect('/settings');}
    public function apiKeyCreateWeb():void{Auth::requirePermission('api');$this->gate();Auth::verifyCsrf();$raw='pk_live_'.bin2hex(random_bytes(24));$this->db->prepare('INSERT INTO api_keys(user_id,name,key_hash) VALUES(?,?,?)')->execute([Auth::id(),$_POST['name']??'API klíč',hash('sha256',$raw)]);View::render('settings/api-keys',['title'=>'API klíče','keys'=>$this->scope('SELECT id,name,last_used_at,created_at FROM api_keys WHERE user_id=? ORDER BY created_at DESC',[Auth::id()]),'new_key'=>$raw]);}
    public function backup():void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Tato funkce je určena pouze pro interní správu Byznia.');Auth::verifyCsrf();try{$r=BackupService::run($this->db);$keep=max(1,(int)Env::get('BACKUP_RETENTION_DAYS','30'));foreach(glob(dirname(__DIR__,2).'/storage/backups/*.gz')?:[] as $f)if(filemtime($f)<time()-$keep*86400)@unlink($f);View::render('admin/system',['title'=>'Záloha vytvořena','backup'=>$r]);}catch(\Throwable $e){Response::abort(500,'Zálohu se nepodařilo vytvořit: '.$e->getMessage());}}
    public function adminSystem():void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');$s=$this->db->query('SELECT last_automatic_backup_at FROM saas_settings WHERE id=1')->fetch();View::render('admin/system',['title'=>'SaaS systém','last_automatic_backup_at'=>$s['last_automatic_backup_at']??null]);}
    public function adminPlans():void{Auth::requireRole(['owner','admin']);$sub=$this->db->prepare('SELECT * FROM subscriptions WHERE workspace_id=?');$sub->execute([Auth::workspaceId()]);View::render('admin/plans',['title'=>'Předplatné','subscription'=>$sub->fetch(),'settings'=>$this->saasSettings(),'superAdmin'=>$this->isSuperAdmin()]);}
    public function subscriptionCancel():void{
        Auth::requireRole(['owner','admin']);Auth::verifyCsrf();$s=$this->db->prepare('SELECT gopay_subscription_payment_id,status,cancel_at_period_end FROM subscriptions WHERE workspace_id=?');$s->execute([Auth::workspaceId()]);$sub=$s->fetch()?:[];
        $parent=(int)($sub['gopay_subscription_payment_id']??0);
        if($parent<1)Response::abort(422,'Aktivní GoPay předplatné nebylo nalezeno.');
        if(!empty($sub['cancel_at_period_end']))Response::redirect('/admin/plans');
        try{GoPayService::voidSaasRecurrence($parent);$this->db->prepare('UPDATE subscriptions SET cancel_at_period_end=1,updated_at=CURRENT_TIMESTAMP WHERE workspace_id=?')->execute([Auth::workspaceId()]);}catch(\Throwable $e){Response::abort(502,'Předplatné se nepodařilo zrušit: '.$e->getMessage());}Response::redirect('/admin/plans');
    }
    public function billingPortal():void{Response::redirect('/admin/plans');}

    public function goPaySubscriptionCallback():void{
        $id=(int)($_GET['id']??0);
        if($id>0){try{$this->processGoPaySubscriptionPayment($id);}catch(\Throwable $e){}}
        Response::redirect('/admin/plans');
    }
    public function goPaySubscriptionWebhook():void{
        $raw=(string)file_get_contents('php://input');$j=json_decode($raw,true)?:[];
        $id=(int)($_GET['id']??$_POST['id']??($j['id']??($j['payment']['id']??0)));
        if($id<1){http_response_code(400);echo 'missing payment id';return;}
        try{$ok=$this->processGoPaySubscriptionPayment($id);http_response_code($ok?200:202);echo $ok?'ok':'pending';}catch(\Throwable $e){http_response_code(500);echo 'error';}
    }
    private function processGoPaySubscriptionPayment(int $id):bool{
        $p=GoPayService::getSaasPayment($id);$state=(string)($p['state']??'');$parent=(int)($p['parent_id']??0);
        $q=$this->db->prepare('SELECT * FROM subscriptions WHERE gopay_subscription_payment_id=? LIMIT 1');$q->execute([$parent>0?$parent:$id]);$sub=$q->fetch();
        if(!$sub)return false;
        $wid=(int)$sub['workspace_id'];
        $this->db->prepare('INSERT OR IGNORE INTO gopay_subscription_payments(payment_id,workspace_id,parent_payment_id,state,amount,created_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)')->execute([$id,$wid,$parent?:null,$state,(float)($p['amount']??0)/100]);
        if(!in_array($state,['PAID','AUTHORIZED'],true))return false;
        $check=$this->db->prepare('SELECT COUNT(*) FROM gopay_subscription_payments WHERE payment_id=? AND paid_at IS NOT NULL');$check->execute([$id]);
        if((int)$check->fetchColumn()>0)return true;
        $interval=in_array($sub['billing_interval'],['month','year'],true)?$sub['billing_interval']:'month';
        $base=new \DateTimeImmutable('now',new \DateTimeZone('Europe/Prague'));
        if(!empty($sub['current_period_end'])){try{$candidate=new \DateTimeImmutable($sub['current_period_end'],new \DateTimeZone('Europe/Prague'));if($candidate>$base)$base=$candidate;}catch(\Throwable $e){}}
        $end=$interval==='year'?$base->modify('+1 year'):$base->modify('+1 month');
        $this->db->prepare('UPDATE gopay_subscription_payments SET state=?,paid_at=CURRENT_TIMESTAMP WHERE payment_id=?')->execute([$state,$id]);
        $this->db->prepare('UPDATE subscriptions SET status="active",plan="all",current_period_end=?,cancel_at_period_end=0,updated_at=CURRENT_TIMESTAMP WHERE workspace_id=?')->execute([$end->format('Y-m-d H:i:s'),$wid]);
        $this->db->prepare('UPDATE workspaces SET plan="all",status="active" WHERE id=?')->execute([$wid]);
        return true;
    }

    public function saasBillingSave():void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');Auth::verifyCsrf();$m=max(1,(float)str_replace(',','.',$_POST['monthly_price_czk']??300));$y=max(1,(float)str_replace(',','.',$_POST['yearly_price_czk']??3240));$t=max(0,(int)($_POST['trial_days']??14));$d=preg_replace('/[^a-z0-9.-]/i','',strtolower(trim($_POST['mail_domain']??'nasystem.cz')));if(!$d)Response::abort(422,'Neplatná mailová doména.');$this->db->prepare('UPDATE saas_settings SET monthly_price_czk=?,yearly_price_czk=?,trial_days=?,mail_domain=?,updated_at=CURRENT_TIMESTAMP WHERE id=1')->execute([$m,$y,$t,$d]);Response::redirect('/admin/plans');}
    public function grantFree():void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');Auth::verifyCsrf();$wid=(int)$_POST['workspace_id'];$until=$_POST['free_until']??'';if(!$until)Response::abort(422,'Zadejte datum.');$this->db->prepare('UPDATE subscriptions SET status="free",plan="all",free_until=?,updated_at=CURRENT_TIMESTAMP WHERE workspace_id=?')->execute([$until.' 23:59:59',$wid]);$this->db->prepare('UPDATE workspaces SET plan="all",status="active" WHERE id=?')->execute([$wid]);Response::redirect('/admin/billing');}
    public function adminBilling():void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');$rows=$this->db->query('SELECT w.id,w.name,w.email_localpart,s.status,s.billing_interval,s.current_period_end,s.free_until FROM workspaces w LEFT JOIN subscriptions s ON s.workspace_id=w.id ORDER BY w.id DESC')->fetchAll();View::render('admin/billing',['title'=>'SaaS předplatné','settings'=>$this->saasSettings(),'workspaces'=>$rows]);}
    public function setPlan():void{Auth::requireRole(['owner','admin']);Auth::verifyCsrf();Response::abort(410,'Ruční změna tarifu je zakázána. Tarif se mění pouze přes aktivní GoPay předplatné.');}
    private function normalizeIban(string $value):?string{
        $v=strtoupper(preg_replace('/\s+/', '', trim($value)));
        if($v==='') return null;
        if(preg_match('/^CZ[0-9]{22}$/',$v)){
            $check=substr($v,2,2); $bban=substr($v,4); $num=$bban.'1235'.$check; $rem=0;
            for($i=0,$n=strlen($num);$i<$n;$i++) $rem=(($rem*10)+(int)$num[$i])%97;
            return $rem===1?$v:null;
        }
        if(preg_match('/^(?:(\d{1,10})-)?(\d{1,10})\/(\d{4})$/',$v,$m)){
            $prefix=str_pad($m[1]??'',6,'0',STR_PAD_LEFT); $account=str_pad($m[2],10,'0',STR_PAD_LEFT); $bban=$m[3].$prefix.$account;
            $num=$bban.'123500'; $rem=0;
            for($i=0,$n=strlen($num);$i<$n;$i++) $rem=(($rem*10)+(int)$num[$i])%97;
            return 'CZ'.str_pad((string)(98-$rem),2,'0',STR_PAD_LEFT).$bban;
        }
        return null;
    }

    public function qr(int $id):void{
        Auth::require();
        $s=$this->db->prepare('SELECT d.*,w.bank_account FROM documents d JOIN workspaces w ON w.id=d.workspace_id WHERE d.id=? AND d.workspace_id=?');
        $s->execute([$id,Auth::workspaceId()]); $d=$s->fetch();
        if(!$d) Response::abort(404,'Doklad nenalezen.');
        $iban=$this->normalizeIban((string)$d['bank_account']);
        if(!$iban) Response::abort(422,'Ve firmě není nastaven platný IBAN ani český účet ve formátu číslo/kód banky.');
        $spayd='SPD*1.0*ACC:'.$iban.'*AM:'.number_format((float)$d['total_with_vat'],2,'.','').'*CC:CZK*X-VS:'.$d['variable_symbol'];
        if(!class_exists('Endroid\QrCode\QrCode')) Response::abort(500,'QR knihovna není nainstalována. Spusťte composer install.');
        $qr=\Endroid\QrCode\QrCode::create($spayd)->setSize(360)->setMargin(10);
        $writer=new \Endroid\QrCode\Writer\PngWriter(); $result=$writer->write($qr);
        header('Content-Type: '.$result->getMimeType()); echo $result->getString(); exit;
    }

    public function goPayLink(int $id):void{
        Auth::require(); Auth::verifyCsrf();
        $s=$this->db->prepare('SELECT d.*,c.email FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.id=? AND d.workspace_id=?');
        $s->execute([$id,Auth::workspaceId()]); $d=$s->fetch();
        if(!$d) Response::abort(404,'Faktura nenalezena.');
        try{
            $base=rtrim(Env::get('APP_URL',''),'/');
            $p=GoPayService::createPayment(Auth::workspaceId(),[
                'amount'=>(int)round($d['total_with_vat']*100),
                'currency'=>'CZK',
                'order_number'=>$d['doc_number'],
                'order_description'=>'Faktura '.$d['doc_number'],
                'items'=>[['name'=>'Faktura '.$d['doc_number'],'amount'=>(int)round($d['total_with_vat']*100),'count'=>1]],
                'callback'=>[
                    'return_url'=>$base.'/gopay/callback?doc='.(int)$d['id'],
                    'notification_url'=>$base.'/gopay/webhook'
                ],
                'payer'=>['contact'=>['email'=>$d['email']??Env::get('MAIL_FROM','')]]
            ]);
            $pid=(int)($p['id']??$p['data']['id']??0);
            if(!$pid) throw new \RuntimeException('GoPay nevrátil ID platby.');
            $this->db->prepare('UPDATE documents SET gopay_payment_id=? WHERE id=? AND workspace_id=?')->execute([$pid,(int)$d['id'],Auth::workspaceId()]);
            $url=GoPayService::gatewayUrl($p);
            if(!$url) throw new \RuntimeException('GoPay nevrátil platební URL.');
            Response::redirect($url);
        }catch(\Throwable $e){Response::abort(502,'GoPay: '.$e->getMessage());}
    }

    private function processGoPayPayment(int $paymentId):bool{
        if($paymentId<=0) return false;
        $q=$this->db->prepare('SELECT * FROM documents WHERE gopay_payment_id=? LIMIT 1');$q->execute([$paymentId]);$d=$q->fetch();
        if(!$d) return false;
        $p=GoPayService::getPayment((int)$d['workspace_id'],$paymentId);
        $status=$p['state']??$p['data']['state']??null;
        if(!in_array($status,['PAID','AUTHORIZED'],true)) return false;
        $exists=$this->db->prepare("SELECT id FROM payments WHERE document_id=? AND source='gopay' LIMIT 1");
        $exists->execute([(int)$d['id']]);
        if(!$exists->fetchColumn()){
            $this->db->prepare('INSERT INTO payments(workspace_id,document_id,amount,paid_at,method,source) VALUES(?,?,?,?,?,?)')
                ->execute([(int)$d['workspace_id'],(int)$d['id'],(float)$d['total_with_vat'],date('Y-m-d'),'gopay','gopay']);
        }
        if((int)($d['gopay_payment_id']??0)!==$paymentId){
            $this->db->prepare('UPDATE documents SET gopay_payment_id=? WHERE id=?')->execute([$paymentId,(int)$d['id']]);
        }
        DocumentService::refreshPaymentStatus($this->db,(int)$d['workspace_id'],(int)$d['id']);
        return true;
    }

    public function goPayCallback():void{
        $id=(int)($_GET['id']??0);
        if(!$id){
            $docId=(int)($_GET['doc']??0);
            if($docId){
                $q=$this->db->prepare('SELECT gopay_payment_id FROM documents WHERE id=? LIMIT 1');
                $q->execute([$docId]); $id=(int)$q->fetchColumn();
            }
        }
        try{$this->processGoPayPayment($id);}catch(\Throwable $e){}
        $token=trim((string)($_GET['token']??''));
        if($token!=='') Response::redirect('/d/'.$token);
        if(Auth::check()) Response::redirect('/documents');
        Response::redirect('/login');
    }

    public function goPayWebhook():void{
        $raw=(string)file_get_contents('php://input'); $j=json_decode($raw,true);
        $id=(int)($_GET['id']??$_POST['id']??($j['id']??($j['payment']['id']??0)));
        if(!$id){
            http_response_code(400); header('Content-Type: application/json');
            echo json_encode(['ok'=>false,'error'=>'missing payment id']); return;
        }
        try{
            $ok=$this->processGoPayPayment($id);
            http_response_code($ok?200:202); header('Content-Type: application/json');
            echo json_encode(['ok'=>$ok]);
        }catch(\Throwable $e){
            http_response_code(500); header('Content-Type: application/json');
            echo json_encode(['ok'=>false]);
        }
    }

    public function brevoInbound():void{
        try{
            $payload=json_decode((string)file_get_contents('php://input'),true)?:[];
            $result=InboundMailService::handleBrevoWebhook($this->db,$payload);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok'=>true]+$result,JSON_UNESCAPED_UNICODE);
        }catch(\Throwable $e){
            if(http_response_code()===401) return;
            error_log('Brevo inbound: '.$e->getMessage());
            http_response_code(400);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok'=>false,'error'=>'invalid inbound webhook']);
        }
        exit;
    }

    public function postmarkInbound(string $secret):void{
        $expected=trim((string)Env::get('POSTMARK_INBOUND_SECRET',''));if($expected===''||!hash_equals($expected,$secret)){http_response_code(404);exit;}
        $payload=json_decode((string)file_get_contents('php://input'),true)?:[];$to=[];foreach(($payload['ToFull']??[]) as $a){if(!empty($a['Email']))$to[]=strtolower(trim($a['Email']));}if(!$to&&!empty($payload['To']))$to=[strtolower(trim((string)$payload['To']))];
        $from=strtolower(trim((string)($payload['FromFull']['Email']??$payload['From']??'')));$subject=trim((string)($payload['Subject']??''));$body=(string)($payload['StrippedTextReply']??$payload['TextBody']??'');$html=(string)($payload['HtmlBody']??'');$messageId=trim((string)($payload['MessageID']??''));if($from===''||!$to){http_response_code(422);echo 'invalid';exit;}
        foreach($to as $recipient){$local=strtolower((string)strstr($recipient,'@',true));if($local==='')continue;$q=$this->db->prepare('SELECT id FROM workspaces WHERE lower(email_localpart)=? LIMIT 1');$q->execute([$local]);$wid=(int)$q->fetchColumn();if(!$wid)continue;$cq=$this->db->prepare('SELECT id FROM customers WHERE workspace_id=? AND lower(email)=? LIMIT 1');$cq->execute([$wid,$from]);$customerId=(int)($cq->fetchColumn()?:0);$docId=0;if(preg_match('/(?:faktura|invoice|fv)\s*#?\s*([A-Za-z0-9_-]+)/iu',$subject,$mm)){$dq=$this->db->prepare('SELECT id FROM documents WHERE workspace_id=? AND doc_number=? LIMIT 1');$dq->execute([$wid,$mm[1]]);$docId=(int)($dq->fetchColumn()?:0);}
            $this->db->prepare('INSERT INTO email_messages(workspace_id,customer_id,document_id,direction,from_email,to_email,subject,body,html_body,message_id) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute([$wid,$customerId?:null,$docId?:null,'inbound',$from,$recipient,$subject,$body,$html,$messageId?:null]);if($customerId)$this->db->prepare('INSERT INTO customer_communications(workspace_id,customer_id,channel,direction,subject,message,created_by) VALUES(?,?,?,?,?,?,NULL)')->execute([$wid,$customerId,'email','inbound',$subject,$body]);}
        header('Content-Type: application/json');echo json_encode(['ok'=>true]);exit;
    }

    public function mailbox():void{
        Auth::require(); $wid=Auth::workspaceId(); $mailbox=MailboxService::ensureWorkspace($this->db,$wid);
        $q=$this->db->prepare('SELECT * FROM email_mailboxes WHERE id=? AND workspace_id=? AND active=1');$q->execute([$mailbox,$wid]);$box=$q->fetch();
        if(!$box)Response::abort(403,'E-mailová schránka není aktivní.');
        $q=$this->db->prepare('SELECT m.*, (SELECT COUNT(*) FROM mailbox_attachments a WHERE a.message_id=m.id) attachment_count FROM mailbox_messages m WHERE m.mailbox_id=? ORDER BY m.created_at DESC LIMIT 100');$q->execute([$mailbox]);
        View::render('mail/index',['title'=>'E-mail','mailbox'=>$box,'rows'=>$q->fetchAll()]);
    }
    public function mailboxMessage(int $id):void{
        Auth::require();$wid=Auth::workspaceId();$mid=MailboxService::ensureWorkspace($this->db,$wid);$q=$this->db->prepare('SELECT m.*,b.localpart,b.display_name FROM mailbox_messages m JOIN email_mailboxes b ON b.id=m.mailbox_id WHERE m.id=? AND b.workspace_id=? LIMIT 1');$q->execute([$id,$wid]);$msg=$q->fetch();if(!$msg)Response::abort(404,'E-mail nenalezen.');$a=$this->db->prepare('SELECT * FROM mailbox_attachments WHERE message_id=? ORDER BY id');$a->execute([$id]);View::render('mail/message',['title'=>'E-mail','message'=>$msg,'attachments'=>$a->fetchAll(),'mailbox_id'=>$mid]);
    }
    public function mailboxSend():void{
        Auth::require();Auth::verifyCsrf();$wid=Auth::workspaceId();$mid=MailboxService::ensureWorkspace($this->db,$wid);$q=$this->db->prepare('SELECT * FROM email_mailboxes WHERE id=? AND workspace_id=? AND active=1');$q->execute([$mid,$wid]);$box=$q->fetch();if(!$box)Response::abort(403,'Schránka není aktivní.');
        $to=strtolower(trim((string)($_POST['to']??'')));$subject=trim((string)($_POST['subject']??''));$body=trim((string)($_POST['body']??''));if(!filter_var($to,FILTER_VALIDATE_EMAIL))Response::abort(422,'Zadejte platný e-mail příjemce.');if($subject==='')Response::abort(422,'Předmět nesmí být prázdný.');if($body==='')Response::abort(422,'Zpráva nesmí být prázdná.');
        $files=[];$dir=dirname(__DIR__,2).'/storage/mailbox/'.$wid;if(!is_dir($dir))@mkdir($dir,0775,true);foreach((array)($_FILES['attachments']['tmp_name']??[]) as $i=>$tmp){if(!is_uploaded_file($tmp))continue;$size=(int)($_FILES['attachments']['size'][$i]??0);if($size>15*1024*1024)Response::abort(413,'Jedna příloha může mít nejvýše 15 MB.');$orig=basename((string)($_FILES['attachments']['name'][$i]??'priloha'));$safe=preg_replace('/[^a-zA-Z0-9._-]+/','_', $orig)?:'priloha';$path=$dir.'/'.bin2hex(random_bytes(16)).'_'.$safe;if(!move_uploaded_file($tmp,$path))Response::abort(500,'Přílohu se nepodařilo uložit.');$files[]=['path'=>$path,'name'=>$orig,'mime'=>(string)($_FILES['attachments']['type'][$i]??'application/octet-stream')];}
        $from=MailboxService::address($box['localpart']);$name=(string)$box['display_name'];$ok=MailerService::sendMailbox($to,$subject,$body,$files,$from,$name,null);if(!$ok)Response::abort(502,'E-mail se nepodařilo odeslat: '.MailerService::lastError());
        $msgid='<'.bin2hex(random_bytes(12)).'@'.MailboxService::domain().'>';$this->db->prepare('INSERT INTO mailbox_messages(mailbox_id,direction,from_email,to_email,subject,body,message_id) VALUES(?,?,?,?,?,?,?)')->execute([$mid,'outbound',$from,$to,$subject,$body,$msgid]);$msgId=(int)$this->db->lastInsertId();$cq=$this->db->prepare('SELECT id FROM customers WHERE workspace_id=? AND lower(email)=? LIMIT 1');$cq->execute([$wid,$to]);$customerId=(int)($cq->fetchColumn()?:0);if($customerId)$this->db->prepare('INSERT INTO customer_communications(workspace_id,customer_id,channel,direction,subject,message,created_by) VALUES(?,?,?,?,?,?,?)')->execute([$wid,$customerId,'email','outbound',$subject,$body,Auth::id()]);$ia=$this->db->prepare('INSERT INTO mailbox_attachments(message_id,filename,mime,size,path) VALUES(?,?,?,?,?)');foreach($files as $f)$ia->execute([$msgId,$f['name'],$f['mime'],@filesize($f['path'])?:0,$f['path']]);Response::redirect('/mail/'.$msgId);
    }
    public function mailboxReply(int $id):void{
        Auth::require();Auth::verifyCsrf();$wid=Auth::workspaceId();$mid=MailboxService::ensureWorkspace($this->db,$wid);$q=$this->db->prepare('SELECT m.*,b.localpart,b.display_name FROM mailbox_messages m JOIN email_mailboxes b ON b.id=m.mailbox_id WHERE m.id=? AND b.workspace_id=? LIMIT 1');$q->execute([$id,$wid]);$orig=$q->fetch();if(!$orig)Response::abort(404,'E-mail nenalezen.');$to=strtolower(trim((string)$orig['from_email']));if(!filter_var($to,FILTER_VALIDATE_EMAIL))Response::abort(422,'Původní odesílatel nemá platný e-mail.');$subject=trim((string)($_POST['subject']??''));if($subject==='')$subject=(str_starts_with(mb_strtolower((string)$orig['subject']),'re:')?(string)$orig['subject']:'Re: '.(string)$orig['subject']);$body=trim((string)($_POST['body']??''));if($body==='')Response::abort(422,'Zpráva nesmí být prázdná.');$from=MailboxService::address($orig['localpart']);$ok=MailerService::sendMailbox($to,$subject,$body,[],$from,(string)$orig['display_name'],(string)($orig['message_id']??''));if(!$ok)Response::abort(502,'Odpověď se nepodařilo odeslat: '.MailerService::lastError());$msgid='<'.bin2hex(random_bytes(12)).'@'.MailboxService::domain().'>';$this->db->prepare('INSERT INTO mailbox_messages(mailbox_id,direction,from_email,to_email,subject,body,message_id,in_reply_to) VALUES(?,?,?,?,?,?,?,?)')->execute([$mid,'outbound',$from,$to,$subject,$body,$msgid,$orig['message_id']??null]);$cq=$this->db->prepare('SELECT id FROM customers WHERE workspace_id=? AND lower(email)=? LIMIT 1');$cq->execute([$wid,$to]);$customerId=(int)($cq->fetchColumn()?:0);if($customerId)$this->db->prepare('INSERT INTO customer_communications(workspace_id,customer_id,channel,direction,subject,message,created_by) VALUES(?,?,?,?,?,?,?)')->execute([$wid,$customerId,'email','outbound',$subject,$body,Auth::id()]);Response::redirect('/mail/'.$this->db->lastInsertId());
    }
    public function mailboxAttachment(int $id):void{
        Auth::require();$wid=Auth::workspaceId();$q=$this->db->prepare('SELECT a.* FROM mailbox_attachments a JOIN mailbox_messages m ON m.id=a.message_id JOIN email_mailboxes b ON b.id=m.mailbox_id WHERE a.id=? AND b.workspace_id=?');$q->execute([$id,$wid]);$a=$q->fetch();if(!$a&&$this->isSuperAdmin()){$q=$this->db->prepare('SELECT * FROM mailbox_attachments WHERE id=?');$q->execute([$id]);$a=$q->fetch();}if(!$a||!is_file($a['path']))Response::abort(404,'Příloha nenalezena.');header('Content-Type: '.($a['mime']?:'application/octet-stream'));header('Content-Length: '.filesize($a['path']));header('Content-Disposition: attachment; filename="'.str_replace('"','',basename($a['filename'])).'"');readfile($a['path']);exit;
    }
    public function adminMailboxes():void{
        Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');$rows=$this->db->query('SELECT b.*,w.name workspace_name FROM email_mailboxes b LEFT JOIN workspaces w ON w.id=b.workspace_id ORDER BY b.is_system DESC,b.localpart')->fetchAll();$ws=$this->db->query('SELECT id,name,email_localpart FROM workspaces ORDER BY name')->fetchAll();View::render('admin/mailboxes',['title'=>'E-mailové schránky','rows'=>$rows,'workspaces'=>$ws,'reserved'=>MailboxService::reserved(),'domain'=>MailboxService::domain()]);
    }
    public function adminMailboxMessage(int $id,int $mid):void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');$q=$this->db->prepare('SELECT m.*,b.localpart,b.display_name FROM mailbox_messages m JOIN email_mailboxes b ON b.id=m.mailbox_id WHERE b.id=? AND m.id=?');$q->execute([$id,$mid]);$msg=$q->fetch();if(!$msg)Response::abort(404,'E-mail nenalezen.');$a=$this->db->prepare('SELECT * FROM mailbox_attachments WHERE message_id=? ORDER BY id');$a->execute([$mid]);View::render('admin/mailbox-message',['title'=>'E-mail','message'=>$msg,'attachments'=>$a->fetchAll(),'mailbox_id'=>$id,'domain'=>MailboxService::domain()]);}
    public function adminMailboxSend(int $id):void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');Auth::verifyCsrf();$q=$this->db->prepare('SELECT * FROM email_mailboxes WHERE id=? AND active=1');$q->execute([$id]);$box=$q->fetch();if(!$box)Response::abort(404,'Schránka nenalezena.');$to=strtolower(trim((string)($_POST['to']??'')));$subject=trim((string)($_POST['subject']??''));$body=trim((string)($_POST['body']??''));if(!filter_var($to,FILTER_VALIDATE_EMAIL))Response::abort(422,'Zadejte platný e-mail příjemce.');if($subject===''||$body==='')Response::abort(422,'Předmět i zpráva jsou povinné.');$from=MailboxService::address($box['localpart']);$ok=MailerService::sendMailbox($to,$subject,$body,[],$from,(string)$box['display_name']);if(!$ok)Response::abort(502,'E-mail se nepodařilo odeslat: '.MailerService::lastError());$this->db->prepare('INSERT INTO mailbox_messages(mailbox_id,direction,from_email,to_email,subject,body,message_id) VALUES(?,?,?,?,?,?,?)')->execute([$id,'outbound',$from,$to,$subject,$body,'<'.bin2hex(random_bytes(12)).'@'.MailboxService::domain().'>']);Response::redirect('/admin/mailboxes/'.$id);}
    public function adminMailboxReply(int $id,int $mid):void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');Auth::verifyCsrf();$q=$this->db->prepare('SELECT m.*,b.localpart,b.display_name FROM mailbox_messages m JOIN email_mailboxes b ON b.id=m.mailbox_id WHERE b.id=? AND m.id=?');$q->execute([$id,$mid]);$orig=$q->fetch();if(!$orig)Response::abort(404,'E-mail nenalezen.');$to=strtolower(trim((string)$orig['from_email']));$subject=trim((string)($_POST['subject']??''));$body=trim((string)($_POST['body']??''));if(!filter_var($to,FILTER_VALIDATE_EMAIL)||$subject===''||$body==='')Response::abort(422,'Příjemce, předmět i zpráva jsou povinné.');$from=MailboxService::address($orig['localpart']);$ok=MailerService::sendMailbox($to,$subject,$body,[],$from,(string)$orig['display_name'],(string)($orig['message_id']??''));if(!$ok)Response::abort(502,'Odpověď se nepodařilo odeslat: '.MailerService::lastError());$this->db->prepare('INSERT INTO mailbox_messages(mailbox_id,direction,from_email,to_email,subject,body,message_id,in_reply_to) VALUES(?,?,?,?,?,?,?,?)')->execute([$id,'outbound',$from,$to,$subject,$body,'<'.bin2hex(random_bytes(12)).'@'.MailboxService::domain().'>',$orig['message_id']??null]);Response::redirect('/admin/mailboxes/'.$id.'/message/'.$mid);}
    public function adminMailboxView(int $id):void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');$q=$this->db->prepare('SELECT * FROM email_mailboxes WHERE id=? LIMIT 1');$q->execute([$id]);$box=$q->fetch();if(!$box)Response::abort(404,'Schránka nenalezena.');$q=$this->db->prepare('SELECT m.*, (SELECT COUNT(*) FROM mailbox_attachments a WHERE a.message_id=m.id) attachment_count FROM mailbox_messages m WHERE m.mailbox_id=? ORDER BY m.created_at DESC LIMIT 100');$q->execute([$id]);View::render('admin/mailbox-view',['title'=>'Schránka '.$box['localpart'],'mailbox'=>$box,'rows'=>$q->fetchAll(),'domain'=>MailboxService::domain()]);}
    public function adminMailboxSave():void{
        Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');Auth::verifyCsrf();$local=MailboxService::normalizeLocalpart((string)($_POST['localpart']??''));$system=!empty($_POST['is_system']);if($err=MailboxService::validateLocalpart($local,$system))Response::abort(422,$err);$workspaceId=(int)($_POST['workspace_id']??0)?:null;if(!$system&&!$workspaceId)Response::abort(422,'U zákaznické schránky vyberte firmu.');if($workspaceId){$q=$this->db->prepare('SELECT id FROM workspaces WHERE id=?');$q->execute([$workspaceId]);if(!$q->fetchColumn())Response::abort(404,'Firma nenalezena.');}$password=(string)($_POST['password']??'');if($password!==''&&strlen($password)<10)Response::abort(422,'Heslo schránky musí mít alespoň 10 znaků.');$name=trim((string)($_POST['display_name']??''));if($name==='')$name=$system?'Byznio':(($this->db->query('SELECT name FROM workspaces WHERE id='.(int)$workspaceId)->fetchColumn())?:$local);$q=$this->db->prepare('SELECT id,workspace_id FROM email_mailboxes WHERE lower(localpart)=? LIMIT 1');$q->execute([$local]);$existing=$q->fetch();if($existing && (!$workspaceId || (int)$existing['workspace_id']!=$workspaceId))Response::abort(422,'Tato e-mailová adresa už existuje.');$hash=$password!==''?password_hash($password,PASSWORD_DEFAULT):null;if($existing){$this->db->prepare('UPDATE email_mailboxes SET localpart=?,display_name=?,password_hash=COALESCE(?,password_hash),active=1,is_system=?,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$local,$name,$hash,$system?1:0,(int)$existing['id']]);}else{$this->db->prepare('INSERT INTO email_mailboxes(workspace_id,localpart,display_name,password_hash,active,is_system) VALUES(?,?,?,?,1,?)')->execute([$workspaceId,$local,$name,$hash,$system?1:0]);}if($workspaceId){$this->db->prepare('UPDATE workspaces SET email_localpart=?,mail_display_name=?,mail_enabled=1 WHERE id=?')->execute([$local,$name,$workspaceId]);}Response::redirect('/admin/mailboxes');
    }
    public function adminMailboxToggle(int $id):void{Auth::require();if(!$this->isSuperAdmin())Response::abort(403,'Pouze Super Admin.');Auth::verifyCsrf();$this->db->prepare('UPDATE email_mailboxes SET active=CASE active WHEN 1 THEN 0 ELSE 1 END,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$id]);$q=$this->db->prepare('SELECT workspace_id,active FROM email_mailboxes WHERE id=?');$q->execute([$id]);$b=$q->fetch();if($b&&$b['workspace_id'])$this->db->prepare('UPDATE workspaces SET mail_enabled=? WHERE id=?')->execute([(int)$b['active'],(int)$b['workspace_id']]);Response::redirect('/admin/mailboxes');}
    public function communication():void{Auth::require();$rows=$this->scope('SELECT m.*,c.company_name,c.first_name,c.last_name,d.doc_number FROM email_messages m LEFT JOIN customers c ON c.id=m.customer_id LEFT JOIN documents d ON d.id=m.document_id WHERE m.workspace_id=? ORDER BY m.created_at DESC LIMIT 100');View::render('communication/index',['title'=>'Komunikace','rows'=>$rows]);}

    public function communicationSave(int $id):void{Auth::require();Auth::verifyCsrf();$s=$this->db->prepare('SELECT id FROM customers WHERE id=? AND workspace_id=?');$s->execute([$id,Auth::workspaceId()]);if(!$s->fetchColumn())Response::abort(404,'Zákazník nenalezen.');$this->db->prepare('INSERT INTO customer_communications(workspace_id,customer_id,channel,direction,subject,message,created_by) VALUES(?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$id,$_POST['channel']??'note','internal',$_POST['subject']??null,$_POST['message']??null,Auth::id()]);Response::redirect('/customers/'.$id);}
    public function automation():void{Auth::requireRole(['owner','admin']);$rows=$this->scope('SELECT * FROM automation_rules WHERE workspace_id=? ORDER BY created_at DESC');$runs=$this->scope('SELECT r.*,a.name FROM automation_runs r LEFT JOIN automation_rules a ON a.id=r.rule_id WHERE r.workspace_id=? ORDER BY r.created_at DESC LIMIT 30');View::render('automation/index',['title'=>'Automatizace','rules'=>$rows,'runs'=>$runs]);}
    public function automationSave():void{Auth::requireRole(['owner','admin']);Auth::verifyCsrf();$this->db->prepare('INSERT INTO automation_rules(workspace_id,name,trigger_type,action_type,config_json,active) VALUES(?,?,?,?,?,1)')->execute([Auth::workspaceId(),$_POST['name'],$_POST['trigger_type'],$_POST['action_type'],json_encode(['days'=>(int)($_POST['days']??0)],JSON_UNESCAPED_UNICODE)]);Response::redirect('/automation');}
    private function xml(string $v):string{return htmlspecialchars($v,ENT_XML1|ENT_QUOTES,'UTF-8');}
    private function uuidV4():string{$d=random_bytes(16);$d[6]=chr((ord($d[6])&0x0f)|0x40);$d[8]=chr((ord($d[8])&0x3f)|0x80);return vsprintf('%s%s-%s-%s-%s-%s%s%s',str_split(bin2hex($d),4));}
    private function isdocPartyXml(array $x,int $fallbackId):string{
        $name=trim((string)($x['company_name']??''));if($name==='')$name=trim((string)($x['first_name']??'').' '.(string)($x['last_name']??''));if($name==='')$name='Subjekt '.$fallbackId;
        $ico=trim((string)($x['ico']??''));$pid=$ico!==''?$ico:'SUBJEKT-'.$fallbackId;
        $street=trim((string)($x['street']??''));$building='-';if(preg_match('/^(.*?)[ ,]+(\d+[A-Za-z0-9\/-]*)$/u',$street,$m)){$street=trim($m[1]);$building=trim($m[2]);}if($street==='')$street='-';
        $city=trim((string)($x['city']??''))?:'-';$zip=trim((string)($x['zip']??''))?:'-';$country=trim((string)($x['country']??''))?:'Česká republika';
        $out='<Party><PartyIdentification><ID>'.$this->xml($pid).'</ID></PartyIdentification><PartyName><Name>'.$this->xml($name).'</Name></PartyName><PostalAddress><StreetName>'.$this->xml($street).'</StreetName><BuildingNumber>'.$this->xml($building).'</BuildingNumber><CityName>'.$this->xml($city).'</CityName><PostalZone>'.$this->xml($zip).'</PostalZone><Country><Name>'.$this->xml($country).'</Name><IdentificationCode>CZ</IdentificationCode></Country></PostalAddress>';
        if(!empty($x['dic']))$out.='<PartyTaxScheme><CompanyID>'.$this->xml((string)$x['dic']).'</CompanyID><TaxScheme>VAT</TaxScheme></PartyTaxScheme>';
        if(!empty($x['email']))$out.='<Contact><ElectronicMail>'.$this->xml((string)$x['email']).'</ElectronicMail></Contact>';
        return $out.'</Party>';
    }
    private function isdocBic(string $iban):?string{static $map=['0100'=>'KOMBCZPP','0300'=>'CEKOCZPP','0600'=>'AGBACZPP','0710'=>'CNBACZPP','0800'=>'GIBACZPX','2010'=>'FIOBCZPP','2020'=>'BOTKCZPP','2060'=>'CITFCZPP','2070'=>'MPUBCZPP','2600'=>'CITFCZPX','2700'=>'BACXCZPP','3030'=>'AIRACZPP','3500'=>'INGBCZPP','4000'=>'EXPNCZPP','5500'=>'RZBCCZPP','6000'=>'PMBPCZPP','6100'=>'EQBKCZPP','6200'=>'COBACZP1','6300'=>'EGBACZPP','6700'=>'SUBACZPP','6800'=>'VBOECZ2X','7910'=>'DEUTCZPX','7940'=>'SPWTCZ21','7950'=>'POPOCZP1','7960'=>'FICHCZP1','7970'=>'MPUBCZPP','7980'=>'WITSCZPP'];$code=substr($iban,4,4);return $map[$code]??null;}
    public function isdoc(int $id):void{
        Auth::require();$wid=Auth::workspaceId();
        $s=$this->db->prepare('SELECT d.*,c.company_name,c.first_name,c.last_name,c.street,c.city,c.zip,c.country,c.ico,c.dic,c.email FROM documents d LEFT JOIN customers c ON c.id=d.customer_id WHERE d.id=? AND d.workspace_id=?');$s->execute([$id,$wid]);$d=$s->fetch();if(!$d)Response::abort(404,'Doklad nenalezen.');
        $company=$this->company();$q=$this->db->prepare('SELECT * FROM document_items WHERE document_id=? ORDER BY id');$q->execute([$id]);$items=$q->fetchAll();
        $fmt=static fn($n)=>number_format((float)$n,2,'.','');$uuid=$this->uuidV4();$issue=$d['issue_date']?:date('Y-m-d');$taxDate=$d['tax_date']?:$issue;$vatApplicable=(float)$d['total_vat']>0?'true':'false';
        $groups=[];foreach($items as $it){$rate=(float)$it['vat_rate'];$line=round((float)$it['quantity']*(float)$it['unit_price'],2);$tax=round($line*$rate/100,2);$g=(string)$rate;if(!isset($groups[$g]))$groups[$g]=['base'=>0,'tax'=>0];$groups[$g]['base']+=$line;$groups[$g]['tax']+=$tax;}
        if(!$groups)$groups=['0'=>['base'=>(float)$d['total_without_vat'],'tax'=>(float)$d['total_vat']]];
        $xml='<?xml version="1.0" encoding="UTF-8"?><Invoice version="6.0.2" xmlns="http://isdoc.cz/namespace/2013"><DocumentType>1</DocumentType><ID>'.$this->xml((string)$d['doc_number']).'</ID><UUID>'.$uuid.'</UUID><IssueDate>'.$this->xml($issue).'</IssueDate><TaxPointDate>'.$this->xml($taxDate).'</TaxPointDate><VATApplicable>'.$vatApplicable.'</VATApplicable><ElectronicPossibilityAgreementReference languageID="cs">Souhlas s elektronickou fakturací</ElectronicPossibilityAgreementReference><LocalCurrencyCode>CZK</LocalCurrencyCode><CurrRate>1</CurrRate><RefCurrRate>1</RefCurrRate><AccountingSupplierParty>'.$this->isdocPartyXml($company,(int)$wid).'</AccountingSupplierParty><AccountingCustomerParty>'.$this->isdocPartyXml($d,$id).'</AccountingCustomerParty><InvoiceLines>';
        $lineNo=1;foreach($items as $it){$qty=(float)$it['quantity'];$unit=(float)$it['unit_price'];$rate=(float)$it['vat_rate'];$base=round($qty*$unit,2);$tax=round($base*$rate/100,2);$gross=round($base+$tax,2);$xml.='<InvoiceLine><ID>L'.$lineNo++.'</ID><InvoicedQuantity unitCode="'.$this->xml((string)($it['unit']?:'ks')).'">'.$fmt($qty).'</InvoicedQuantity><LineExtensionAmount>'.$fmt($base).'</LineExtensionAmount><LineExtensionTaxAmount>'.$fmt($tax).'</LineExtensionTaxAmount><UnitPrice>'.$fmt($unit).'</UnitPrice><UnitPriceTaxInclusive>'.$fmt($qty>0?$gross/$qty:0).'</UnitPriceTaxInclusive><ClassifiedTaxCategory><Percent>'.$fmt($rate).'</Percent><VATCalculationMethod>0</VATCalculationMethod><VATApplicable>'.$vatApplicable.'</VATApplicable></ClassifiedTaxCategory><Item><Description>'.$this->xml((string)$it['name']).'</Description></Item></InvoiceLine>';}
        $xml.='</InvoiceLines><TaxTotal>';
        foreach($groups as $rate=>$g){$base=round($g['base'],2);$tax=round($g['tax'],2);$inclusive=round($base+$tax,2);$xml.='<TaxSubTotal><TaxableAmount>'.$fmt($base).'</TaxableAmount><TaxAmount>'.$fmt($tax).'</TaxAmount><TaxInclusiveAmount>'.$fmt($inclusive).'</TaxInclusiveAmount><AlreadyClaimedTaxableAmount>0</AlreadyClaimedTaxableAmount><AlreadyClaimedTaxAmount>0</AlreadyClaimedTaxAmount><AlreadyClaimedTaxInclusiveAmount>0</AlreadyClaimedTaxInclusiveAmount><DifferenceTaxableAmount>'.$fmt($base).'</DifferenceTaxableAmount><DifferenceTaxAmount>'.$fmt($tax).'</DifferenceTaxAmount><DifferenceTaxInclusiveAmount>'.$fmt($inclusive).'</DifferenceTaxInclusiveAmount><TaxCategory><Percent>'.$fmt($rate).'</Percent><TaxScheme>VAT</TaxScheme><VATApplicable>'.$vatApplicable.'</VATApplicable></TaxCategory></TaxSubTotal>';}
        $xml.='<TaxAmount>'.$fmt((float)$d['total_vat']).'</TaxAmount></TaxTotal>';
        $total=(float)$d['total_with_vat'];$base=(float)$d['total_without_vat'];$xml.='<LegalMonetaryTotal><TaxExclusiveAmount>'.$fmt($base).'</TaxExclusiveAmount><TaxInclusiveAmount>'.$fmt($total).'</TaxInclusiveAmount><AlreadyClaimedTaxExclusiveAmount>0</AlreadyClaimedTaxExclusiveAmount><AlreadyClaimedTaxInclusiveAmount>0</AlreadyClaimedTaxInclusiveAmount><DifferenceTaxExclusiveAmount>'.$fmt($base).'</DifferenceTaxExclusiveAmount><DifferenceTaxInclusiveAmount>'.$fmt($total).'</DifferenceTaxInclusiveAmount><PaidDepositsAmount>0</PaidDepositsAmount><PayableAmount>'.$fmt($total).'</PayableAmount></LegalMonetaryTotal>';
        $iban=$this->normalizeIban((string)($company['bank_account']??''));if($iban){$bic=$this->isdocBic($iban);if($bic){$bankCode=substr($iban,4,4);$accountId=ltrim(substr($iban,8), '0')?:'0';$xml.='<PaymentMeans><Payment partialPayment="true"><PaidAmount>'.$fmt($total).'</PaidAmount><PaymentMeansCode>42</PaymentMeansCode><Details><PaymentDueDate>'.$this->xml((string)($d['due_date']?:$issue)).'</PaymentDueDate><ID>'.$this->xml($accountId).'</ID><BankCode>'.$this->xml($bankCode).'</BankCode><Name>'.$this->xml((string)($company['name']??'Bankovní účet')).'</Name><IBAN>'.$this->xml($iban).'</IBAN><BIC>'.$this->xml($bic).'</BIC><VariableSymbol>'.$this->xml((string)($d['variable_symbol']??'' )).'</VariableSymbol></Details></Payment></PaymentMeans>';}}
        $xml.='</Invoice>';
        $dom=new \DOMDocument('1.0','UTF-8');$dom->preserveWhiteSpace=false;$dom->formatOutput=true;if(!$dom->loadXML($xml,LIBXML_NONET|LIBXML_NOBLANKS))Response::abort(500,'ISDOC XML se nepodařilo vytvořit.');$xml=$dom->saveXML();
        header('Content-Type: application/xml; charset=UTF-8');header('Content-Disposition: attachment; filename="'.$d['doc_number'].'.isdoc"');echo $xml;exit;
    }

    public function documentEdit(int $id):void{
        Auth::require();$wid=Auth::workspaceId();$q=$this->db->prepare('SELECT * FROM documents WHERE id=? AND workspace_id=?');$q->execute([$id,$wid]);$d=$q->fetch();if(!$d)Response::abort(404,'Doklad nenalezen.');if($d['payment_status']==='paid')Response::abort(422,'Zaplacený doklad nelze upravovat.');$i=$this->db->prepare('SELECT * FROM document_items WHERE document_id=? ORDER BY id');$i->execute([$id]);$tp=$this->db->prepare('SELECT * FROM tax_profiles WHERE workspace_id=?');$tp->execute([$wid]);View::render('documents/edit',['title'=>'Upravit doklad','document'=>$d,'items'=>$i->fetchAll(),'customers'=>$this->customersList(),'products'=>$this->productsList(),'vatPayer'=>!empty(($tp->fetch()['vat_payer']??0))]);
    }
    public function documentUpdate(int $id):void{
        Auth::require();Auth::verifyCsrf();$wid=Auth::workspaceId();$q=$this->db->prepare('SELECT * FROM documents WHERE id=? AND workspace_id=?');$q->execute([$id,$wid]);$d=$q->fetch();if(!$d)Response::abort(404,'Doklad nenalezen.');if($d['payment_status']==='paid')Response::abort(422,'Zaplacený doklad nelze upravovat.');
        $this->db->beginTransaction();try{
            $old=$this->db->prepare('SELECT warehouse_item_id,quantity FROM document_items WHERE document_id=? AND warehouse_item_id IS NOT NULL');$old->execute([$id]);$restore=$this->db->prepare('UPDATE products SET stock=stock+? WHERE id=? AND workspace_id=?');$mv=$this->db->prepare('INSERT INTO stock_movements(workspace_id,product_id,qty,type,note) VALUES(?,?,?,?,?)');foreach($old as $r){$restore->execute([(float)$r['quantity'],(int)$r['warehouse_item_id'],$wid]);$mv->execute([$wid,(int)$r['warehouse_item_id'],(float)$r['quantity'],'edit','Vrácení skladu před úpravou dokladu '.$d['doc_number']]);}
            $this->db->prepare('DELETE FROM document_items WHERE document_id=?')->execute([$id]);$tp=$this->db->prepare('SELECT vat_payer FROM tax_profiles WHERE workspace_id=?');$tp->execute([$wid]);$payer=(bool)$tp->fetchColumn();$names=$_POST['item_name']??[];$qty=$_POST['item_qty']??[];$prices=$_POST['item_price']??[];$rates=$_POST['item_vat']??[];$pids=$_POST['product_id']??[];$sub=0;$vat=0;$st=$this->db->prepare('INSERT INTO document_items(document_id,name,quantity,unit,unit_price,vat_rate,line_total,warehouse_item_id) VALUES(?,?,?,?,?,?,?,?)');foreach($names as $i=>$name){$name=trim((string)$name);if($name==='')continue;$qv=max(0,(float)($qty[$i]??1));$price=(float)($prices[$i]??0);$rate=$payer?(float)($rates[$i]??0):0;if(!in_array($rate,[0,12,21],true))$rate=0;$pid=(int)($pids[$i]??0);if($pid){$ps=$this->db->prepare('SELECT * FROM products WHERE id=? AND workspace_id=? AND active=1');$ps->execute([$pid,$wid]);$prod=$ps->fetch();if(!$prod)Response::abort(422,'Produkt nenalezen.');if($qv>(float)$prod['stock'])Response::abort(422,'Nedostatek zásoby pro '.$prod['name'].'.');$name=$prod['name'];}$line=round($qv*$price,2);$sub+=$line;$vat+=round($line*$rate/100,2);$st->execute([$id,$name,$qv,$_POST['item_unit'][$i]??'ks',$price,$rate,$line,$pid?:null]);if($pid&&$d['doc_type']==='invoice'){$this->db->prepare('UPDATE products SET stock=stock-? WHERE id=? AND workspace_id=?')->execute([$qv,$pid,$wid]);$mv->execute([$wid,$pid,-$qv,'edit','Výdej skladu po úpravě dokladu '.$d['doc_number']]);}}
            $this->db->prepare('UPDATE documents SET issue_date=?,due_date=?,tax_date=?,total_without_vat=?,total_vat=?,total_with_vat=?,currency=?,cnb_rate=?,tax_regime=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND workspace_id=?')->execute([$_POST['issue_date']??$d['issue_date'],$_POST['due_date']??$d['due_date'],$_POST['tax_date']??($_POST['issue_date']??$d['issue_date']),$sub,$vat,$sub+$vat,strtoupper($_POST['currency']??$d['currency']??'CZK'),(float)($_POST['cnb_rate']??$d['cnb_rate']??1),$_POST['tax_regime']??$d['tax_regime']??'standard',$id,$wid]);$this->db->commit();
        }catch(\Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}Response::redirect('/documents');
    }
    public function documentDuplicate(int $id):void{
        Auth::require();Auth::verifyCsrf();$wid=Auth::workspaceId();$q=$this->db->prepare('SELECT * FROM documents WHERE id=? AND workspace_id=?');$q->execute([$id,$wid]);$d=$q->fetch();if(!$d)Response::abort(404,'Doklad nenalezen.');$newType=$d['doc_type'];$num=DocumentService::nextNumber($this->db,$wid,$newType);$token=DocumentService::publicToken($this->db);$this->db->prepare('INSERT INTO documents(workspace_id,doc_type,doc_number,variable_symbol,customer_id,status,payment_status,issue_date,due_date,tax_date,payment_method,total_without_vat,total_vat,total_with_vat,currency,cnb_rate,tax_regime,language,created_by,public_token) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$wid,$newType,$num,preg_replace('/\D/','',$num),$d['customer_id'],'issued','unpaid',date('Y-m-d'),date('Y-m-d',strtotime('+14 days')),date('Y-m-d'),$d['payment_method'],$d['total_without_vat'],$d['total_vat'],$d['total_with_vat'],$d['currency']??'CZK',$d['cnb_rate']??1,$d['tax_regime']??'standard',$d['language']??'cs',Auth::id(),$token]);$new=(int)$this->db->lastInsertId();$i=$this->db->prepare('SELECT * FROM document_items WHERE document_id=?');$i->execute([$id]);$st=$this->db->prepare('INSERT INTO document_items(document_id,name,description,quantity,unit,unit_price,vat_rate,line_total,warehouse_item_id) VALUES(?,?,?,?,?,?,?,?,?)');foreach($i as $r)$st->execute([$new,$r['name'],$r['description'],$r['quantity'],$r['unit'],$r['unit_price'],$r['vat_rate'],$r['line_total'],null]);Response::redirect('/documents/'.$new.'/edit');
    }
    public function convertProforma(int $id):void{
        Auth::require();Auth::verifyCsrf();$wid=Auth::workspaceId();$q=$this->db->prepare('SELECT * FROM documents WHERE id=? AND workspace_id=?');$q->execute([$id,$wid]);$d=$q->fetch();if(!$d||$d['doc_type']!=='proforma')Response::abort(404,'Zálohová faktura nenalezena.');$paid=DocumentService::paid($this->db,$wid,$id);$num=DocumentService::nextNumber($this->db,$wid,'invoice');$token=DocumentService::publicToken($this->db);$remaining=max(0,(float)$d['total_with_vat']-$paid);$ratio=((float)$d['total_with_vat'])>0?$remaining/(float)$d['total_with_vat']:1;$sub=round((float)$d['total_without_vat']*$ratio,2);$vat=round((float)$d['total_vat']*$ratio,2);$this->db->beginTransaction();$this->db->prepare('INSERT INTO documents(workspace_id,doc_type,doc_number,variable_symbol,customer_id,parent_document_id,status,payment_status,issue_date,due_date,tax_date,payment_method,total_without_vat,total_vat,total_with_vat,advance_applied,public_token,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$wid,'invoice',$num,preg_replace('/\D/','',$num),$d['customer_id'],$id,'issued',$paid>=$d['total_with_vat']-0.01?'paid':'unpaid',date('Y-m-d'),date('Y-m-d',strtotime('+14 days')),date('Y-m-d'),$d['payment_method'],$sub,$vat,$sub+$vat,-$paid,$token,Auth::id()]);$new=(int)$this->db->lastInsertId();$i=$this->db->prepare('SELECT * FROM document_items WHERE document_id=?');$i->execute([$id]);$st=$this->db->prepare('INSERT INTO document_items(document_id,name,quantity,unit,unit_price,vat_rate,line_total,warehouse_item_id) VALUES(?,?,?,?,?,?,?,?)');foreach($i as $r){$line=round((float)$r['line_total']*$ratio,2);$st->execute([$new,$r['name'],$r['quantity'],$r['unit'],$r['unit_price'],$r['vat_rate'],$line,$r['warehouse_item_id']]);}$this->db->prepare('INSERT INTO document_chain(workspace_id,from_document_id,to_document_id,relation) VALUES(?,?,?,?)')->execute([$wid,$id,$new,'advance_to_invoice']);$this->db->commit();Response::redirect('/documents/'.$new.'/edit');
    }
    public function accountingExport():void{
        Auth::require();$wid=Auth::workspaceId();$from=$_GET['from']??date('Y-m-01');$to=$_GET['to']??date('Y-m-d');$type=$_GET['type']??'csv';if($type==='zip'){$f=AccountingExportService::package($this->db,$wid,$from,$to,dirname(__DIR__,2));header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="'.basename($f).'"');readfile($f);exit;}if($type==='pohoda'){$x=AccountingExportService::pohodaXml($this->db,$wid,$from,$to);header('Content-Type: application/xml; charset=UTF-8');header('Content-Disposition: attachment; filename="pohoda_'.$from.'_'.$to.'.xml"');echo $x;exit;}$csv=AccountingExportService::csv($this->db,$wid,$from,$to);header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="byznio_'.$from.'_'.$to.'.csv"');echo "\xEF\xBB\xBF".$csv;exit;
    }
    public function receivedInvoices():void{Auth::require();$rows=$this->scope('SELECT * FROM received_invoices WHERE workspace_id=? ORDER BY due_date IS NULL,due_date DESC,id DESC');View::render('received/index',['title'=>'Přijaté faktury','rows'=>$rows]);}
    public function receivedInvoiceSave():void{Auth::require();Auth::verifyCsrf();$d=$_POST;$wid=Auth::workspaceId();$this->db->prepare('INSERT INTO received_invoices(workspace_id,supplier,ico,dic,document_number,variable_symbol,issue_date,due_date,currency,cnb_rate,amount_without_vat,vat_amount,total_amount,payment_status,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$wid,trim($d['supplier']??''),trim($d['ico']??''),trim($d['dic']??''),trim($d['document_number']??''),trim($d['variable_symbol']??''),$d['issue_date']??null,$d['due_date']??null,strtoupper($d['currency']??'CZK'),(float)($d['cnb_rate']??1),(float)($d['amount_without_vat']??0),(float)($d['vat_amount']??0),(float)($d['total_amount']??0),$d['payment_status']??'unpaid',trim($d['note']??'')]);Response::redirect('/received-invoices');}
    public function isdocImport():void{Auth::require();Auth::verifyCsrf();if(empty($_FILES['isdoc']['tmp_name']))Response::abort(422,'Nahrajte ISDOC soubor.');$xml=@simplexml_load_file($_FILES['isdoc']['tmp_name']);if(!$xml)Response::abort(422,'ISDOC není validní XML.');$val=function(string $name)use($xml){$n=$xml->xpath('//*[local-name()="'.$name.'"]');return $n&&isset($n[0])?trim((string)$n[0]):'';};$id=$val('ID');$issue=$val('IssueDate')?:date('Y-m-d');$due=$val('DueDate')?:date('Y-m-d',strtotime('+14 days'));$total=(float)str_replace(',','.',$val('PayableAmount'));$name=$val('CompanyName')?:$val('PartyName');$this->db->prepare('INSERT INTO received_invoices(workspace_id,supplier,document_number,issue_date,due_date,total_amount,payment_status,note) VALUES(?,?,?,?,?,?,?,?)')->execute([Auth::workspaceId(),$name,$id,$issue,$due,$total,'unpaid','Importováno z ISDOC']);Response::redirect('/received-invoices');}
    public function accountantShare():void{Auth::require();Auth::verifyCsrf();if(!Auth::can('admin')&&!Auth::can('accountant'))Response::abort(403,'Nemáte oprávnění.');$token=bin2hex(random_bytes(24));$hash=hash('sha256',$token);$this->db->prepare('INSERT INTO accountant_shares(workspace_id,user_id,token_hash,expires_at) VALUES(?,?,?,?)')->execute([Auth::workspaceId(),Auth::id(),$hash,date('Y-m-d H:i:s',strtotime('+30 days'))]);$url=rtrim(Env::get('APP_URL',''),'/').'/accountant/'.$token;View::render('accountant/share',['title'=>'Přístup pro účetní','url'=>$url]);}
    public function comgateLink():void{Auth::require();Auth::verifyCsrf();$merchant=trim((string)($_POST['merchant']??''));$secret=trim((string)($_POST['secret']??''));if($merchant===''||$secret==='')Response::abort(422,'Doplňte Comgate údaje.');$enc=base64_encode(hash_hmac('sha256',$secret,Env::get('APP_KEY',''),true).'|'.$secret);$this->db->prepare('INSERT INTO comgate_accounts(workspace_id,merchant,secret_encrypted,active) VALUES(?,?,?,1) ON CONFLICT(workspace_id) DO UPDATE SET merchant=excluded.merchant,secret_encrypted=excluded.secret_encrypted,active=1')->execute([Auth::workspaceId(),$merchant,$enc]);Response::redirect('/settings?saved=comgate');}
    public function cnbRate():void{Auth::require();$currency=strtoupper($_GET['currency']??'EUR');$date=$_GET['date']??date('Y-m-d');$s=$this->db->prepare('SELECT rate FROM currency_rates WHERE currency=? AND rate_date=?');$s->execute([$currency,$date]);$rate=$s->fetchColumn();if($rate===false)$rate=CnbRateService::get($this->db,$currency,$date);if($rate===null)$rate=1;Response::json(['currency'=>$currency,'date'=>$date,'rate'=>(float)$rate]);}
    public function accountantPortal(string $token):void{ $hash=hash('sha256',trim($token));$q=$this->db->prepare('SELECT a.*,w.name workspace_name FROM accountant_shares a JOIN workspaces w ON w.id=a.workspace_id WHERE a.token_hash=? AND a.active=1 AND (a.expires_at IS NULL OR a.expires_at>CURRENT_TIMESTAMP)');$q->execute([$hash]);$share=$q->fetch();if(!$share)Response::abort(404,'Přístup pro účetní je neplatný nebo vypršel.');$wid=(int)$share['workspace_id'];$docs=$this->db->prepare('SELECT doc_number,doc_type,issue_date,due_date,total_with_vat,payment_status FROM documents WHERE workspace_id=? AND status<>"cancelled" ORDER BY issue_date DESC LIMIT 100');$docs->execute([$wid]);$received=$this->db->prepare('SELECT supplier,document_number,issue_date,due_date,total_amount,payment_status FROM received_invoices WHERE workspace_id=? ORDER BY issue_date DESC LIMIT 100');$received->execute([$wid]);View::renderStandalone('accountant/portal',['title'=>'Účetní portál','workspace'=>$share['workspace_name'],'documents'=>$docs->fetchAll(),'received'=>$received->fetchAll()]);}
    public function convertDocumentType(int $id,string $target):void{Auth::require();Auth::verifyCsrf();$wid=Auth::workspaceId();$allowed=['offer'=>'order','order'=>'invoice'];$q=$this->db->prepare('SELECT * FROM documents WHERE id=? AND workspace_id=?');$q->execute([$id,$wid]);$d=$q->fetch();if(!$d||($allowed[$d['doc_type']]??null)!==$target)Response::abort(422,'Tento převod není povolen.');$num=DocumentService::nextNumber($this->db,$wid,$target);$token=DocumentService::publicToken($this->db);$this->db->beginTransaction();$this->db->prepare('INSERT INTO documents(workspace_id,doc_type,doc_number,variable_symbol,customer_id,parent_document_id,status,payment_status,issue_date,due_date,tax_date,payment_method,total_without_vat,total_vat,total_with_vat,currency,cnb_rate,tax_regime,language,created_by,public_token) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$wid,$target,$num,preg_replace('/\D/','',$num),$d['customer_id'],$id,'issued','unpaid',date('Y-m-d'),date('Y-m-d',strtotime('+14 days')),date('Y-m-d'),$d['payment_method'],$d['total_without_vat'],$d['total_vat'],$d['total_with_vat'],$d['currency']??'CZK',$d['cnb_rate']??1,$d['tax_regime']??'standard',$d['language']??'cs',Auth::id(),$token]);$new=(int)$this->db->lastInsertId();$i=$this->db->prepare('SELECT * FROM document_items WHERE document_id=?');$i->execute([$id]);$st=$this->db->prepare('INSERT INTO document_items(document_id,name,description,quantity,unit,unit_price,vat_rate,line_total,warehouse_item_id) VALUES(?,?,?,?,?,?,?,?,?)');foreach($i as $r)$st->execute([$new,$r['name'],$r['description'],$r['quantity'],$r['unit'],$r['unit_price'],$r['vat_rate'],$r['line_total'],$target==='invoice'?$r['warehouse_item_id']:null]);$this->db->prepare('INSERT INTO document_chain(workspace_id,from_document_id,to_document_id,relation) VALUES(?,?,?,?)')->execute([$wid,$id,$new,$d['doc_type'].'_to_'.$target]);$this->db->commit();Response::redirect('/documents/'.$new.'/edit');}
    public function emailPreview(string $type='general'):void{Auth::requireRole(['owner','admin']);$types=['invoice','reminder','payment','verification','report','general'];if(!in_array($type,$types,true))$type='general';$data=['company'=>'Byznio','logo'=>rtrim(Env::get('APP_URL',''),'/').'/assets/byznio-logo.svg','title'=>['invoice'=>'Faktura FV-2026-00001','reminder'=>'Blíží se splatnost','payment'=>'Platba přijata','verification'=>'Ověření e-mailu','report'=>'Týdenní přehled','general'=>'Zpráva z Byznia'][$type],'intro'=>'Ukázkový obsah e-mailu pro kontrolu vzhledu.','action_url'=>rtrim(Env::get('APP_URL',''),'/').'/documents','action_text'=>'Otevřít v Byzniu','details'=>['Doklad'=>'FV-2026-00001','Částka'=>'12 100 Kč','Splatnost'=>'30. 9. 2026']];$r=EmailTemplateService::render($type,$data);echo $r['html'];exit;}

}

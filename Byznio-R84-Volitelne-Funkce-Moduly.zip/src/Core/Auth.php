<?php
namespace App\Core;
use App\Config\Modules;
final class Auth {
    private static ?array $user=null;
    public static function boot(): void {
        if(session_status()!==PHP_SESSION_ACTIVE){
            session_name('podnikatel_sid');
            session_set_cookie_params(['httponly'=>true,'secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'samesite'=>'Lax']);
            session_start();
        }
        if(isset($_SESSION['user_id'])){
            $s=Database::pdo()->prepare('SELECT * FROM users WHERE id=? AND active=1'); $s->execute([$_SESSION['user_id']]);
            self::$user=$s->fetch() ?: null;
        }
    }
    public static function user(): ?array{return self::$user;}
    public static function id(): ?int{return self::$user?(int)self::$user['id']:null;}
    public static function workspaceId(): ?int {
        if(!self::$user)return null;
        $base=(int)self::$user['workspace_id'];
        $current=(int)($_SESSION['current_workspace_id']??0);
        if($current>0){
            try{$s=Database::pdo()->prepare('SELECT 1 FROM workspace_members WHERE workspace_id=? AND user_id=? LIMIT 1');$s->execute([$current,(int)self::$user['id']]);if($s->fetchColumn())return $current;}catch(\Throwable $e){}
        }
        return $base;
    }
    public static function switchWorkspace(int $workspaceId): void {
        self::require();
        $s=Database::pdo()->prepare('SELECT 1 FROM workspace_members WHERE workspace_id=? AND user_id=? LIMIT 1');
        $s->execute([$workspaceId,self::id()]);
        if(!$s->fetchColumn())Response::abort(403,'K této firmě nemáte přístup.');
        $_SESSION['current_workspace_id']=$workspaceId;
    }
    public static function resetWorkspace(): void { if(self::$user) $_SESSION['current_workspace_id']=(int)self::$user['workspace_id']; }
    public static function workspaceRole(): string {
        if(!self::$user)return '';
        $s=Database::pdo()->prepare('SELECT role FROM workspace_members WHERE workspace_id=? AND user_id=? LIMIT 1');$s->execute([self::workspaceId(),self::id()]);
        return (string)($s->fetchColumn()?:self::$user['role']);
    }
    public static function check(): bool{return self::$user!==null;}
    public static function require(): void {
        if(!self::check()){Response::redirect('/login');}
        $uri=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';
        $moduleMap=[
            '/documents/files'=>'documents','/received-invoices'=>'received_invoices','/communication'=>'communication','/reports'=>'reports','/mail'=>'mail',
            '/customers'=>'crm','/documents'=>'invoicing','/jobs'=>'jobs','/expenses'=>'expenses','/products'=>'inventory','/bank'=>'bank','/calendar'=>'calendar',
            '/recurring'=>'recurring','/tax'=>'tax','/tasks'=>'tasks','/contracts'=>'contracts','/reminders'=>'reminders','/automation'=>'automation','/export'=>'export'
        ];
        foreach($moduleMap as $prefix=>$module){if($uri===$prefix||str_starts_with($uri,$prefix.'/')){if(!self::moduleEnabled($module))Response::abort(403,'Tato funkce není pro tuto firmu aktivní. Zapněte ji v Nastavení → Funkce a moduly.');break;}}
        $map=[
            '/customers'=>'crm','/documents'=>'invoicing','/documents/files'=>'documents','/jobs'=>'jobs','/expenses'=>'expenses','/products'=>'inventory',
            '/bank'=>'bank','/calendar'=>'calendar','/tasks'=>'tasks','/ai'=>'ai','/recurring'=>'invoicing','/tax'=>'tax',
            '/automation'=>'automation','/settings/api-keys'=>'api','/admin/users'=>'team','/admin'=>'admin','/reminders'=>'invoicing'
        ];
        foreach($map as $prefix=>$permission){if($uri===$prefix||str_starts_with($uri,$prefix.'/')){if(!self::can($permission))Response::abort(403,'Nedostatečné oprávnění.');break;}}
    }
    public static function moduleEnabled(string $module): bool {
        if(!self::$user)return false;
        $s=Database::pdo()->prepare('SELECT modules_json,business_type FROM workspaces WHERE id=? LIMIT 1');
        $s->execute([self::workspaceId()]); $workspace=$s->fetch();
        if(!$workspace)return false;
        return in_array($module,Modules::fromWorkspace($workspace),true);
    }
    public static function modules(): array {
        if(!self::$user)return [];
        $s=Database::pdo()->prepare('SELECT * FROM workspaces WHERE id=? LIMIT 1');$s->execute([self::workspaceId()]);$workspace=$s->fetch();
        return $workspace?Modules::fromWorkspace($workspace):[];
    }
    public static function can(string $permission): bool {
        if(!self::$user)return false;
        if(in_array(self::workspaceRole(),['owner','admin'],true))return true;
        $raw=self::$user['permissions_json']??'';
        if($raw!==''){
            $p=json_decode($raw,true); if(is_array($p)&&array_key_exists($permission,$p))return (bool)$p[$permission];
        }
        if(!in_array(self::$user['role'],['employee','accountant','owner','admin'],true)){
            $s=Database::pdo()->prepare('SELECT permissions_json FROM custom_roles WHERE workspace_id=? AND name=? LIMIT 1');$s->execute([(int)self::$user['workspace_id'],(string)self::$user['role']]);$custom=$s->fetchColumn();if($custom!==false){$p=json_decode((string)$custom,true);if(is_array($p)&&array_key_exists($permission,$p))return (bool)$p[$permission];}
        }
        $defaults=[
            'crm'=>true,'invoicing'=>true,'jobs'=>true,'expenses'=>true,'inventory'=>true,'bank'=>false,
            'calendar'=>true,'tasks'=>true,'ai'=>false,'tax'=>false,'automation'=>false,'api'=>false,'documents'=>true,'team'=>false,'admin'=>false
        ];
        if(self::$user['role']==='accountant')$defaults=array_merge($defaults,['bank'=>true,'tax'=>true,'api'=>true]);
        return (bool)($defaults[$permission]??false);
    }
    public static function requirePermission(string $permission): void {self::require(); if(!self::can($permission))Response::abort(403,'Nedostatečné oprávnění: '.$permission.'.');}
    public static function requireRole(array $roles): void {self::require(); if(!in_array(self::workspaceRole(),$roles,true)) Response::abort(403,'Nedostatečné oprávnění.');}
    public static function login(array $u): void {session_regenerate_id(true); $_SESSION['user_id']=(int)$u['id']; self::$user=$u;}
    public static function logout(): void {$_SESSION=[]; if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>$p['samesite']??'Lax']);} session_destroy(); self::$user=null;}
    public static function csrf(): string {if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf'];}
    public static function verifyCsrf(): void {if(!hash_equals($_SESSION['csrf']??'',$_POST['_csrf']??'')) Response::abort(419,'Neplatný CSRF token.');}
}

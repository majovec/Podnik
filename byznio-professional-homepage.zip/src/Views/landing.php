<?php
$monthly = (float)($settings['monthly_price_czk'] ?? 300);
$yearly  = (float)($settings['yearly_price_czk'] ?? 3000);
$trial   = (int)($settings['trial_days'] ?? 14);
?>
<!doctype html>
<html lang="cs">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0b1020">
<meta name="description" content="Byznio – váš podnik na jednom místě. CRM, zakázky, faktury, banky, sklad, daně a AI asistent.">
<title>Byznio — Váš podnik na jednom místě.</title>
<style>
:root{--bg:#080d1d;--bg2:#172554;--text:#f8fafc;--muted:#c4cede;--line:#ffffff1f;--accent:#635bff;--max:1180px}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--text);background:var(--bg);line-height:1.5}a{color:inherit;text-decoration:none}.wrap{max-width:var(--max);margin:auto;padding:0 24px}
.hero{min-height:100vh;background:radial-gradient(circle at 80% 15%,#635bff44,transparent 32%),linear-gradient(135deg,#080d1d,#13204b 58%,#30206b)}
.nav{height:82px;display:flex;align-items:center;justify-content:space-between;position:relative}.brand{display:flex;align-items:center;gap:11px;font-size:28px;font-weight:900;letter-spacing:-.04em}.brand img{width:42px;height:42px}.links{display:flex;align-items:center;gap:25px;color:#d9dfec;font-weight:650}.links a:hover{color:#fff}.cta{background:#fff;color:#111827!important;padding:12px 18px;border-radius:12px;font-weight:850}.hamb{display:none;background:none;border:0;color:#fff;font-size:30px}.mobile{display:none;position:absolute;z-index:20;top:72px;left:0;right:0;background:#10182f;border:1px solid var(--line);border-radius:16px;padding:10px;box-shadow:0 20px 50px #0008}.mobile.open{display:block}.mobile a{display:block;padding:13px}
.heroGrid{display:grid;grid-template-columns:1.12fr .88fr;gap:70px;align-items:center;padding:95px 0 105px}.eyebrow{text-transform:uppercase;letter-spacing:.12em;font-size:14px;font-weight:850;color:#aeb7ff}.hero h1{font-size:clamp(48px,7vw,82px);line-height:.99;letter-spacing:-.055em;margin:18px 0 26px}.lead{font-size:21px;color:var(--muted);max-width:720px}.buttons{display:flex;gap:13px;flex-wrap:wrap;margin-top:30px}.btn{display:inline-flex;align-items:center;justify-content:center;padding:15px 22px;border-radius:13px;font-weight:850}.primary{background:var(--accent);box-shadow:0 15px 35px #635bff55}.secondary{border:1px solid var(--line);background:#ffffff0d}
.preview{background:#ffffff0b;border:1px solid var(--line);border-radius:25px;padding:25px;backdrop-filter:blur(18px);box-shadow:0 25px 80px #0005}.topline,.row{display:flex;justify-content:space-between;gap:15px}.green{width:10px;height:10px;border-radius:50%;background:#6ee7b7}.number{font-size:38px;font-weight:900}.bar{height:9px;background:#ffffff12;border-radius:9px;margin:12px 0 20px;overflow:hidden}.bar i{display:block;width:72%;height:100%;background:linear-gradient(90deg,#635bff,#8b7cff)}.row{padding:13px 0;border-bottom:1px solid var(--line)}
.section{padding:95px 0}.light{background:#f7f9fc;color:#101828}.title{max-width:750px;margin-bottom:42px}.title h2{font-size:clamp(35px,5vw,55px);line-height:1.05;letter-spacing:-.045em;margin:12px 0}.title p{font-size:19px;color:#667085}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.card{background:#fff;border:1px solid #e4e7ec;border-radius:20px;padding:25px}.icon{width:44px;height:44px;border-radius:13px;background:#eef0ff;color:#554cff;display:grid;place-items:center;font-weight:900;margin-bottom:18px}.card h3{margin:0 0 8px;font-size:21px}.card p{margin:0;color:#667085}
.steps{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}.step{border:1px solid #e4e7ec;border-radius:18px;padding:22px;background:#fff}.step b{color:#635bff}.step h3{margin:8px 0}.step p{color:#667085}
.pricing{display:grid;grid-template-columns:1fr 410px;gap:50px;align-items:center}.pricebox{background:#fff;color:#101828;border-radius:24px;padding:30px;box-shadow:0 20px 70px #10182818}.price{font-size:52px;font-weight:950;letter-spacing:-.05em}.price small{font-size:17px;color:#667085}.checks{padding:0;list-style:none}.checks li{padding:8px 0}.checks li:before{content:"✓";color:#635bff;font-weight:900;margin-right:10px}
.faq{max-width:850px}.faq details{border-bottom:1px solid var(--line);padding:20px 0}.faq summary{cursor:pointer;font-size:19px;font-weight:800}.faq p{color:var(--muted)}
.contact{background:linear-gradient(135deg,#151c42,#2b2168);border:1px solid var(--line);border-radius:28px;padding:48px;display:flex;justify-content:space-between;align-items:center;gap:30px}.contact h2{font-size:clamp(35px,5vw,52px);margin:8px 0}.contact p{color:var(--muted)}
footer{border-top:1px solid var(--line);padding:42px 0;color:#aeb8cb}.foot{display:flex;justify-content:space-between;gap:30px}.footlinks{display:flex;gap:22px;flex-wrap:wrap}
@media(max-width:850px){.wrap{padding:0 20px}.links{display:none}.hamb{display:block}.heroGrid{grid-template-columns:1fr;padding:70px 0 85px;gap:45px}.hero h1{font-size:clamp(46px,13vw,68px)}.cards{grid-template-columns:1fr}.steps{grid-template-columns:1fr 1fr}.pricing{grid-template-columns:1fr}.contact{display:block;padding:34px 26px}.contact .btn{margin-top:22px}.foot{flex-direction:column}}
@media(max-width:520px){.section{padding:70px 0}.buttons,.btn{width:100%}.steps{grid-template-columns:1fr}.preview{padding:20px}.price{font-size:45px}}
</style>
</head>
<body>
<section class="hero" id="top">
<div class="wrap">
<header class="nav">
<a class="brand" href="#top"><img src="/assets/byznio-mark.svg" alt="Byznio"><span>Byznio</span></a>
<nav class="links" aria-label="Hlavní navigace">
<a href="#funkce">Funkce</a><a href="#jak">Jak to funguje</a><a href="#cenik">Ceník</a><a href="#faq">FAQ</a><a href="#kontakt">Kontakt</a><a href="/login">Přihlásit</a><a class="cta" href="/register">Začít zdarma</a>
</nav>
<button class="hamb" type="button" aria-label="Menu" aria-expanded="false" onclick="const n=document.getElementById('mobile');n.classList.toggle('open');this.setAttribute('aria-expanded',n.classList.contains('open'))">☰</button>
<div class="mobile" id="mobile">
<a href="#funkce">Funkce</a><a href="#jak">Jak to funguje</a><a href="#cenik">Ceník</a><a href="#faq">FAQ</a><a href="#kontakt">Kontakt</a><a href="/login">Přihlásit</a><a href="/register"><strong>Začít zdarma</strong></a>
</div>
</header>
<div class="heroGrid">
<div>
<div class="eyebrow">Administrativa pro podnikatele</div>
<h1>Vy podnikáte.<br>Administrativu udělá Byznio.</h1>
<p class="lead">CRM, zakázky, faktury, banky, automatické párování plateb, sklad, daně a AI asistent v jednom moderním SaaS.</p>
<div class="buttons"><a class="btn primary" href="/register">Vyzkoušet <?= $trial ?> dní zdarma</a><a class="btn secondary" href="#funkce">Prohlédnout funkce ↓</a></div>
</div>
<div class="preview"><div class="topline"><strong>Finanční přehled</strong><span class="green"></span></div><div style="color:#aeb8cb;margin-top:22px">Příjem tento měsíc</div><div class="number">128 450 Kč</div><div class="bar"><i></i></div><div class="row"><span>Uhrazené faktury</span><strong>42 800 Kč</strong></div><div class="row"><span>Čeká na úhradu</span><strong>18 650 Kč</strong></div><div class="row"><span>Aktivní zakázky</span><strong>12</strong></div></div>
</div>
</div>
</section>

<section class="section light" id="funkce"><div class="wrap"><div class="title"><div class="eyebrow" style="color:#635bff">Vše na jednom místě</div><h2>Méně přepisování. Více času na podnikání.</h2><p>Byznio propojuje každodenní administrativu do jednoho pracovního toku.</p></div>
<div class="cards">
<?php foreach([['C','CRM','Zákazníci, kontakty a kompletní historie na jednom místě.'],['Z','Zakázky','Rozpočty, práce, materiál, hodiny a ziskovost zakázek.'],['F','Fakturace','Faktury, nabídky, zálohy, dobropisy, PDF, QR a ISDOC.'],['B','Banka','Příchozí transakce a automatické párování plateb.'],['AI','AI asistent','OCR, návrhy a pomoc s administrativou. Citlivé akce potvrdíte.'],['D','Daně','Průběžný přehled příjmů, výdajů a daňových podkladů.']] as $x): ?>
<article class="card"><div class="icon"><?=View::e($x[0])?></div><h3><?=View::e($x[1])?></h3><p><?=View::e($x[2])?></p></article>
<?php endforeach; ?>
</div></div></section>

<section class="section" id="jak"><div class="wrap"><div class="title"><div class="eyebrow">Jednoduchý workflow</div><h2>Od zákazníka až po zaplacenou fakturu.</h2><p>Data se mezi jednotlivými částmi systému znovu nepřepisují.</p></div>
<div class="steps">
<div class="step"><b>01</b><h3>Zákazník</h3><p>Založíte kontakt a máte historii na jednom místě.</p></div>
<div class="step"><b>02</b><h3>Zakázka</h3><p>Naplánujete práci, materiál, hodiny a rozpočet.</p></div>
<div class="step"><b>03</b><h3>Faktura</h3><p>Z podkladů připravíte fakturu a odešlete ji.</p></div>
<div class="step"><b>04</b><h3>Platba</h3><p>Byznio pomůže příchozí platbu přiřadit a označit jako uhrazenou.</p></div>
</div></div></section>

<section class="section light" id="cenik"><div class="wrap"><div class="pricing"><div class="title"><div class="eyebrow" style="color:#635bff">Jednoduché předplatné</div><h2>Všechny funkce. Jeden tarif.</h2><p>Žádné rozdělování funkcí do několika tarifů. Aktuální cenu a délku zkoušky řídí nastavení služby.</p></div>
<div class="pricebox"><div style="color:#667085">Byznio</div><div class="price"><?=number_format($monthly,0,',',' ')?> Kč <small>/ měsíc</small></div><div style="color:#667085">Roční platba <?=number_format($yearly,0,',',' ')?> Kč</div><ul class="checks"><li>CRM, zakázky a fakturace</li><li>Banky a párování plateb</li><li>Sklad, OCR, daně a automatizace</li><li>AI asistent a API</li></ul><a class="btn primary" style="width:100%" href="/register">Vyzkoušet <?=$trial?> dní zdarma</a></div>
</div></div></section>

<section class="section" id="faq"><div class="wrap"><div class="title"><div class="eyebrow">Časté otázky</div><h2>Co potřebujete vědět před startem.</h2></div><div class="faq">
<details><summary>Je Byznio vhodné i pro OSVČ?</summary><p>Ano. Je navržené pro OSVČ, freelancery a malé firmy.</p></details>
<details><summary>Musím něco instalovat?</summary><p>Ne. Byznio je webová aplikace dostupná z počítače i telefonu.</p></details>
<details><summary>Co umí bankovní propojení?</summary><p>Načítá transakce a pomáhá s jejich párováním. Citlivé údaje bankovnictví ani karty do Byznia nepatří.</p></details>
<details><summary>Rozhoduje AI sama o penězích?</summary><p>Ne. Důležité nebo nevratné finanční akce mají vyžadovat vaše potvrzení.</p></details>
<details><summary>Jak dlouho trvá zkušební období?</summary><p>Aktuální délka zkoušky je <?=$trial?> dní a řídí se nastavením služby.</p></details>
</div></div></section>

<section class="section" id="kontakt"><div class="wrap"><div class="contact"><div><div class="eyebrow">Kontakt</div><h2>Máte otázku?</h2><p>Napište nám. Rádi pomůžeme s Byzniem, účtem nebo nasazením.</p></div><a class="btn primary" href="mailto:info@byznio.cz">info@byznio.cz</a></div></div></section>

<footer><div class="wrap foot"><div><a class="brand" href="#top"><img src="/assets/byznio-mark.svg" alt="Byznio"><span>Byznio</span></a><div style="margin-top:10px">Váš podnik na jednom místě.</div></div><div class="footlinks"><a href="#funkce">Funkce</a><a href="#cenik">Ceník</a><a href="#faq">FAQ</a><a href="#kontakt">Kontakt</a><a href="/login">Přihlášení</a><a href="/register">Registrace</a></div></div><div class="wrap" style="margin-top:28px;font-size:14px">© <?=date('Y')?> Byznio. Všechna práva vyhrazena.</div></footer>
<script>document.querySelectorAll('#mobile a').forEach(a=>a.addEventListener('click',()=>document.getElementById('mobile').classList.remove('open')));</script>
</body></html>

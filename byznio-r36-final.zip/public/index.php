<?php
declare(strict_types=1);
require dirname(__DIR__).'/vendor/autoload.php';
require dirname(__DIR__).'/src/bootstrap.php';
\App\Core\Kernel::handle();

<?php
$step=max(1,min(7,(int)($step??1)));
$steps=[
  1=>['title'=>'Nejdřív nastavíme firmu','text'=>'Začneme údaji firmy. Zadej IČO a Byznio se pokusí doplnit dostupné údaje z ARES.','target'=>null],
  2=>['title'=>'Tady jsou tvoji zákazníci','text'=>'V CRM najdeš kontakty, komunikaci, doklady i zakázky každého zákazníka.','target'=>'customers'],
  3=>['title'=>'Tady vznikají doklady','text'=>'Faktury, nabídky, objednávky, dobropisy i veřejné odkazy pro zákazníky máš na jednom místě.','target'=>'documents'],
  4=>['title'=>'Zakázky drží práci pohromadě','text'=>'U zakázky uvidíš rozpočet, práci, materiál, náklady a výsledek.','target'=>'jobs'],
  5=>['title'=>'Banka a párování plateb','text'=>'Tady se načtou transakce a Byznio může pomáhat s párováním plateb k fakturám.','target'=>'bank'],
  6=>['title'=>'Kalendář a úkoly','text'=>'Termíny a úkoly máš přímo v aplikaci, takže důležité věci nezůstanou jen v hlavě.','target'=>'calendar'],
  7=>['title'=>'A kdykoli mě zavoláš','text'=>'Jsem tvoje Nia. Zůstanu s tebou i po průvodci a můžeme spolu řešit běžnou práci v Byzniu.','target'=>'nia'],
];
$current=$steps[$step];
$tourRoutes=[2=>'/customers?tour=2&next=3',3=>'/documents?tour=3&next=4',4=>'/jobs?tour=4&next=5',5=>'/bank?tour=5&next=6',6=>'/calendar?tour=6&next=7'];
$messages=[
  'Ahoj! Já jsem Nia. Provedu tě Byzniem krok za krokem.',
  'Teď ti ukážu skutečné prostředí aplikace. Nemusíš nic hledat.',
  'Každý krok můžeš kdykoli zopakovat. Já zůstanu po ruce i potom.',
];
?>
<style>
.nia-onboard{max-width:1180px;margin:0 auto}.onboard-shell{background:linear-gradient(135deg,#f7fbff 0%,#eef5ff 52%,#f5f0ff 100%);border:1px solid #dce7f5;border-radius:30px;overflow:hidden;box-shadow:0 18px 55px rgba(16,33,63,.08)}
.onboard-top{padding:24px 28px 18px;border-bottom:1px solid rgba(220,231,245,.9);background:rgba(255,255,255,.72);backdrop-filter:blur(12px)}.onboard-topline{display:flex;justify-content:space-between;gap:18px;align-items:center}.onboard-kicker{font-size:12px;font-weight:850;letter-spacing:.08em;text-transform:uppercase;color:#5d6f8c}.onboard-title{margin:5px 0 0;font-size:27px;letter-spacing:-.035em}.tour-skip{border:0;background:transparent;color:#65738b;font-weight:800;cursor:pointer;padding:9px}.tour-skip:hover{color:#21385d}.progress{height:8px;background:#e7edf6;border-radius:99px;overflow:hidden;margin-top:18px}.progress span{display:block;height:100%;width:calc((<?=($step)?> / 7) * 100%);background:linear-gradient(90deg,#1677ee,#5946e8);border-radius:99px;transition:width .35s ease}
.onboard-grid{display:grid;grid-template-columns:minmax(0,1.02fr) minmax(380px,.98fr);gap:0;min-height:620px}.nia-stage{position:relative;display:flex;align-items:flex-end;justify-content:center;padding:36px 30px 0;min-height:620px;overflow:hidden;background:radial-gradient(circle at 50% 38%,rgba(91,70,232,.15),transparent 42%),radial-gradient(circle at 40% 85%,rgba(22,119,238,.13),transparent 48%)}.nia-stage:before{content:"";position:absolute;width:440px;height:440px;border-radius:50%;background:rgba(255,255,255,.56);filter:blur(2px);box-shadow:0 30px 80px rgba(22,119,238,.12)}.nia-floor{position:absolute;bottom:20px;width:min(470px,88%);height:54px;border-radius:50%;background:radial-gradient(ellipse,rgba(26,54,96,.20),rgba(26,54,96,0) 68%);filter:blur(5px)}.nia-image{position:relative;z-index:2;width:min(470px,78%);height:auto;max-height:570px;object-fit:contain;object-position:center bottom;filter:drop-shadow(0 24px 32px rgba(17,31,60,.20));animation:niaFloat 4.8s ease-in-out infinite,niaEnter .7s cubic-bezier(.2,.8,.2,1) both;transform-origin:50% 90%}.nia-image.talking{animation:niaTalk .55s ease-in-out infinite alternate}.nia-image.thinking{animation:niaThink 1.4s ease-in-out infinite}.nia-orbit{position:absolute;z-index:1;width:360px;height:360px;border:1px solid rgba(89,70,232,.15);border-radius:50%;animation:orbit 12s linear infinite}.nia-orbit:before,.nia-orbit:after{content:"";position:absolute;width:9px;height:9px;border-radius:50%;background:#5b46e8;box-shadow:0 0 0 7px rgba(91,70,232,.10)}.nia-orbit:before{top:24px;left:64px}.nia-orbit:after{right:44px;bottom:68px;background:#1677ee}
.nia-caption{position:absolute;z-index:4;left:28px;top:28px;display:flex;align-items:center;gap:9px;padding:9px 13px;border-radius:999px;background:rgba(255,255,255,.88);border:1px solid rgba(220,231,245,.95);box-shadow:0 10px 24px rgba(16,33,63,.08);font-weight:850;color:#1b3154}.nia-dot{width:9px;height:9px;border-radius:50%;background:#22b779;box-shadow:0 0 0 5px rgba(34,183,121,.12)}
.nia-bubble{position:absolute;z-index:5;left:50%;bottom:28px;transform:translateX(-50%);width:min(500px,88%);background:#fff;border:1px solid #dce6f2;border-radius:23px;padding:17px 20px;box-shadow:0 18px 45px rgba(16,33,63,.14);line-height:1.5}.nia-bubble:after{content:"";position:absolute;left:50%;bottom:-10px;width:19px;height:19px;background:#fff;border-right:1px solid #dce6f2;border-bottom:1px solid #dce6f2;transform:translateX(-50%) rotate(45deg)}.nia-bubble strong{display:block;font-size:15px;color:#5946e8;margin-bottom:4px}.nia-bubble span{display:block;color:#263b5d;font-size:15px}
.onboard-panel{background:rgba(255,255,255,.9);padding:42px 38px;display:flex;flex-direction:column;justify-content:center}.step-number{display:inline-flex;align-items:center;gap:8px;color:#5946e8;font-weight:850;font-size:12px;text-transform:uppercase;letter-spacing:.08em}.step-number:before{content:"";width:8px;height:8px;border-radius:50%;background:#5946e8;box-shadow:0 0 0 5px rgba(89,70,232,.10)}.onboard-panel h1{font-size:38px;line-height:1.08;letter-spacing:-.045em;margin:12px 0 12px}.onboard-panel>p{font-size:16px;color:#64738a;line-height:1.65;margin:0 0 22px}.company-form{display:grid;gap:16px}.field label{font-size:13px;font-weight:800;color:#233958}.field input{min-height:50px}.company-check{display:flex;align-items:center;gap:9px;color:#5d6d84;font-size:13px}.company-check input{width:17px;height:17px}.tour-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}.tour-actions .btn{width:auto}.feature-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px;margin-top:20px}.feature{padding:14px;border:1px solid #e1e8f2;border-radius:15px;background:#fbfdff}.feature b{display:block;font-size:13px;margin-bottom:4px}.feature span{font-size:12px;color:#6a788e;line-height:1.45}.guide-tip{margin-top:18px;padding:14px 15px;border-radius:15px;background:#f4f7ff;border:1px solid #dfe7f8;color:#4f6280;font-size:13px;line-height:1.5}.step-dots{display:flex;gap:7px;margin-top:20px}.step-dot{width:31px;height:7px;border:0;border-radius:99px;background:#e3eaf3;cursor:pointer;padding:0}.step-dot.active{background:linear-gradient(90deg,#1677ee,#5946e8)}.mobile-note{display:none}
@keyframes niaFloat{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-8px) rotate(.35deg)}}@keyframes niaEnter{from{opacity:0;transform:translateY(28px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}@keyframes niaTalk{from{transform:translateY(-2px) rotate(-.4deg)}to{transform:translateY(-8px) rotate(.4deg)}}@keyframes niaThink{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-5px) rotate(-.6deg)}}@keyframes orbit{to{transform:rotate(360deg)}}
@media(max-width:900px){.onboard-grid{grid-template-columns:1fr}.nia-stage{min-height:450px;height:450px;padding-top:25px}.nia-image{width:min(330px,70%);max-height:390px}.nia-orbit{width:270px;height:270px}.onboard-panel{padding:30px 26px 34px}.onboard-panel h1{font-size:31px}.onboard-top{padding:20px}.onboard-topline{align-items:flex-start}.nia-bubble{bottom:18px}.mobile-note{display:block;margin-top:13px;color:#718097;font-size:12px}}
@media(max-width:560px){.onboard-shell{border-radius:22px}.onboard-topline{gap:8px}.onboard-title{font-size:22px}.tour-skip{font-size:12px;padding:7px 0}.nia-stage{min-height:380px;height:380px;padding:12px 12px 0}.nia-image{width:72%;max-height:330px}.nia-stage:before{width:300px;height:300px}.nia-orbit{width:235px;height:235px}.nia-caption{left:14px;top:14px;font-size:12px}.nia-bubble{width:calc(100% - 24px);bottom:12px;padding:13px 15px;border-radius:18px}.nia-bubble span{font-size:13px}.onboard-panel{padding:25px 18px 28px}.onboard-panel h1{font-size:28px}.onboard-panel>p{font-size:14px}.feature-grid{grid-template-columns:1fr}.tour-actions .btn{width:100%}.step-dots{justify-content:center}.step-dot{width:27px}}
@media(prefers-reduced-motion:reduce){.nia-image,.nia-orbit{animation:none}.progress span{transition:none}}
</style>
<div class="nia-onboard">
<div class="onboard-shell">
  <div class="onboard-top">
    <div class="onboard-topline"><div><div class="onboard-kicker">Průvodce Byzniem · krok <?=$step?> ze 7</div><div class="onboard-title">Začínáme s Byzniem</div></div><form method="post" action="/uvod/skip"><input type="hidden" name="_csrf" value="<?=App\Core\Auth::csrf()?>"><button class="tour-skip" type="submit">Přeskočit průvodce</button></form></div>
    <div class="progress"><span></span></div>
  </div>
  <div class="onboard-grid">
    <section class="nia-stage" aria-label="Nia, průvodkyně Byznia">
      <div class="nia-caption"><span class="nia-dot"></span>Nia · online</div><div class="nia-orbit" aria-hidden="true"></div><div class="nia-floor" aria-hidden="true"></div>
      <button type="button" id="niaOnboardCharacter" style="border:0;background:none;padding:0;margin:0;cursor:pointer;display:flex;align-items:flex-end;justify-content:center;position:relative;z-index:2" aria-label="Klikni na Niu pro další tip"><img class="nia-image" id="niaImage" src="/assets/nia.png" alt="Nia, AI průvodkyně Byznia"></button>
      <div class="nia-bubble"><strong>Nia</strong><span id="niaMessage"><?=View::e($messages[($step-1)%count($messages)])?></span></div>
    </section>
    <section class="onboard-panel">
      <div class="step-number">Krok <?=$step?> · <?=$step===1?'nastavení firmy':'rychlá orientace'?></div>
      <h1><?=View::e($current['title'])?></h1>
      <p><?=View::e($current['text'])?></p>
      <?php if($step===1): ?>
        <form class="form company-form" method="post" action="/uvod/company">
          <input type="hidden" name="_csrf" value="<?=App\Core\Auth::csrf()?>">
          <div class="field"><label>IČO</label><input name="ico" value="<?=View::e($workspace['ico']??'')?>" inputmode="numeric" placeholder="12345678"></div>
          <label class="company-check"><input type="checkbox" name="ares" value="1" checked> Doplnit dostupné údaje z ARES</label>
          <div class="row"><div class="field"><label>DIČ</label><input name="dic" value="<?=View::e($workspace['dic']??'')?>"></div><div class="field"><label>PSČ</label><input name="zip" value="<?=View::e($workspace['zip']??'')?>"></div></div>
          <div class="row"><div class="field"><label>Ulice</label><input name="street" value="<?=View::e($workspace['street']??'')?>"></div><div class="field"><label>Město</label><input name="city" value="<?=View::e($workspace['city']??'')?>"></div></div>
          <div class="tour-actions"><button class="btn primary" type="submit">Uložit a pokračovat →</button></div>
        </form>
      <?php elseif($step===7): ?>
        <div class="guide-tip"><strong>Tip od Nii</strong><br>Po dokončení průvodce mě najdeš vpravo dole. Můžeš mi napsat, co potřebuješ, a u důležitých akcí ti vždy ukážu návrh k potvrzení.</div>
        <div class="tour-actions"><form method="post" action="/uvod/complete"><input type="hidden" name="_csrf" value="<?=App\Core\Auth::csrf()?>"><button class="btn primary" type="submit">Dokončit a otevřít Byznio →</button></form><a class="btn" href="/uvod?step=6">← Zpět</a></div>
      <?php else: ?>
        <div class="feature-grid"><div class="feature"><b>Propojené workflow</b><span>Zákazník → nabídka → zakázka → faktura → banka → platba.</span></div><div class="feature"><b>Automatizace</b><span>Upomínky, opakované faktury, párování a reporty.</span></div><div class="feature"><b>Finance</b><span>Výdaje, cashflow, sklad a daňové podklady.</span></div><div class="feature"><b>Nia</b><span>Pomoc s přehledem, návrhy a bezpečným potvrzením akcí.</span></div></div>
        <div class="tour-actions"><a class="btn primary" href="<?=$tourRoutes[$step]??('/uvod?step='.($step+1))?>">Ukázat skutečnou obrazovku →</a><a class="btn" href="/uvod?step=<?=$step-1?>">← Zpět</a></div>
        <div class="mobile-note">Na mobilu tě zvýrazněná část aplikace automaticky posune do záběru.</div>
      <?php endif; ?>
      <div class="step-dots" aria-label="Kroky průvodce"><?php for($i=1;$i<=7;$i++): ?><button type="button" class="step-dot <?=$i===$step?'active':''?>" data-step="<?=$i?>" aria-label="Krok <?=$i?>"></button><?php endfor; ?></div>
    </section>
  </div>
</div>
</div>
<script>
(function(){
 const img=document.getElementById('niaImage'), char=document.getElementById('niaOnboardCharacter'), msg=document.getElementById('niaMessage');
 const messages=[<?=json_encode($messages[0],JSON_UNESCAPED_UNICODE)?>,<?=json_encode($messages[1],JSON_UNESCAPED_UNICODE)?>,<?=json_encode($messages[2],JSON_UNESCAPED_UNICODE)?>];let n=0;
 if(char){char.addEventListener('click',()=>{n=(n+1)%messages.length;img.classList.add('talking');msg.textContent=messages[n];setTimeout(()=>img.classList.remove('talking'),1100);});}
 document.querySelectorAll('.step-dot').forEach(b=>b.addEventListener('click',()=>{location.href='/uvod?step='+b.dataset.step;}));
})();
</script>
<script>
(function(){
 const target=<?=json_encode($current['target'],JSON_UNESCAPED_UNICODE)?>; if(!target)return;
 const sel=target==='nia'?'#niaFab':'[data-guide="'+target+'"]'; const el=document.querySelector(sel); if(!el)return;
 const guide=document.createElement('div');guide.className='nia-guide';guide.id='onboardSpot';document.body.appendChild(guide);
 const note=document.createElement('div');note.className='nia-guide-note';note.setAttribute('role','dialog');note.innerHTML='<strong>Nia · krok <?=$step?> z 7</strong><div><?=htmlspecialchars($current['title'],ENT_QUOTES,'UTF-8')?></div><p><?=htmlspecialchars($current['text'],ENT_QUOTES,'UTF-8')?></p>';document.body.appendChild(note);
 function place(){const r=el.getBoundingClientRect(); if(r.bottom<0||r.top>innerHeight){el.scrollIntoView({behavior:'smooth',block:'center'});setTimeout(place,260);return;} guide.style.left=Math.max(5,r.left-5)+'px';guide.style.top=Math.max(5,r.top-5)+'px';guide.style.width=Math.min(r.width+10,innerWidth-10)+'px';guide.style.height=Math.min(r.height+10,innerHeight-10)+'px';note.style.left=Math.min(Math.max(12,r.left),Math.max(12,innerWidth-332))+'px';note.style.top=Math.min(Math.max(72,r.bottom+12),Math.max(72,innerHeight-185))+'px';guide.classList.add('show');note.classList.add('show');}
 place();addEventListener('resize',place);addEventListener('scroll',place,{passive:true});
})();
</script>
